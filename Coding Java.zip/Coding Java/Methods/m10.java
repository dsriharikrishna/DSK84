//10.Write a program to print the Given Name(String) for n number of times by using Method ?
import java.util.Scanner;

class Main{
    
    public static void main(String[]args){
        
        Scanner obj = new Scanner(System.in);
        int n = obj.nextInt();
        display(n);
    }
    
    public static void display(int N){
        
        //Write your code here.
        if(N<=0)
            System.out.print("Invalid Input");
        else
            for(int i=1; i<=N;i++)
            {
                System.out.println("cvcorp");
            }
    }
}