/*
2.Write a program to print the even numbers by using Method between the Given Numbers ?

 */

 import java.util.Scanner;

class Main{
    
    public static void main(String[]cvcorp){
        
        Scanner obj = new Scanner(System.in);
        //write your code here.
        int a = obj.nextInt();
        int b = obj.nextInt();
        boolean c = false;
        if(a<=0 && b<=0)
        {
            System.out.print("Invalid Inputs");
        }
        else if(a<=0)
        {
            System.out.print("Invalid First Input");
        }
        else if(b<=0)
        {
            System.out.print("Invalid Second Input");
        }
        else
        {
            for(int i=a; i<b; i++)
            {
                if(isEven(i))
                {
                    if(c)
                    {
                        System.out.print(", ");
                    }
                    System.out.print(i);
                    c=true;
                }
            }
            System.out.print(".");
        }
    }
    
    static boolean isEven(int N){
        
        //Donot change anything in this Method.
        if(N%2==0)
            return true;
        else
            return false;
    }
}