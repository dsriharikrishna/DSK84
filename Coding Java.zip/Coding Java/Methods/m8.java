// 8.Write a program to print the sum of the first n natural Numbers by using Method ?
import java.util.Scanner;

class Main{
    
    public static void main(String[]args){
        
        //Donot change anything in main class.
        
        Scanner obj = new Scanner(System.in);
        int n = obj.nextInt();
        int k=sumOfNaturalNumbers(n);
        if(k>0)
        {
            System.out.print(k);
        }
        else
        {
            System.out.println("Invalid Input");
        }
    }
    
    static int sumOfNaturalNumbers(int N){
        int k=0;
        //Write your code here.
        for(int i=1; i<=N;i++)
        {
            k=k+i;
        }
        return k;
    }
}