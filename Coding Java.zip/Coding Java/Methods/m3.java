/*
3.Write a program to check whether the given number is Armstrong or not by using methods.

 */

 import java.util.Scanner;

class Main
{
    public static void main(String[]args){
        
        Scanner obj = new Scanner(System.in);
        int N = obj.nextInt();
        armstrong(N);
    }
    public static void armstrong(int k)
    {
    //write your code here.
    if(k<=0)
        System.out.print("Invalid Input.");
    else
    {
            int rev=0;
            int cn = noOfDigits(k);
            int t=k;
            while(t>0)
            {
                int r = t%10;
                rev+=(int)Math.pow(r,cn);
                t/=10;
            }
            if(rev==k)
                System.out.print("The given number is Armstrong.");
            else
                System.out.print("The given number is not an Armstrong.");
    }
        
    }
    public static int noOfDigits(int num)
    {
    //write your code here.
       int t=num;
       int d=0;
       while(t>0)
       {
           d++;
           t/=10;
       }
       return d;
    }
}