//7.Write a program to check whether the given number is Palindrome or not by using methods.

import java.util.Scanner;

class Main{
    
    public static void main(String[]args){
        
        Scanner obj = new Scanner(System.in);
        int N = obj.nextInt();
        System.out.print(palindrome(N));
    }
    
    //write a method to check whether the given number is palindrome or not.
    //write your code here.
    public static String palindrome(int N)
    {
        int rev= 0;
        if(N<0)
            N=-N;
        int t=N;
        while(N>0)
        {
            int r= N%10;
            rev=rev*10+r;
            N/=10;
        }
        if(rev==t)
        {
            return "The given number is Palindrome.";
        }
        else
        {
            return "The given number is not a PalinDrome.";
        }
    }
}