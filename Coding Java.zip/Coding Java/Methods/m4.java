/*
4.Write a program to reverse a number by using Methods ?
*/
import java.util.Scanner;

class Main{
    
    public static void main(String[]args){
        
        Scanner obj = new Scanner(System.in);
        int N = obj.nextInt();
        System.out.print(reverse(N));
    }
    
    //write a method to print the reverse of the number.
    //write your code here.
    public static int reverse(int n)
    {
        int rev =0;
        if(n<0)
        {
            n=-n;
        }
        while(n>0)
        {
            int r = n%10;
            rev = rev*10+r;
            n/=10;
        }
        return rev;
    }
    
}
