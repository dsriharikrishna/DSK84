/*
1.Write a program to check whether the given number is prime number or not by using Methods ?
*/

import java.util.Scanner;

class Main{
    
    public static void main(String[]arg){
        
        //Donot change anything in main method.
        
        Scanner obj = new Scanner(System.in);
        int N = obj.nextInt();
        isPrime(N);
        System.out.print(".");
    }
    
    //create a method with name isPrime and check whether the given number is Prime or Not.
    //write your code here.
    public static void isPrime(int a)
    {
        if(a<=0)
        {
            System.out.print("Invalid Input");
        }
        else
        {
            int fc=0;
            for(int i=2; i<=a; i++)
            {
                if(a%i==0)
                {
                    fc++;
                }
            }
            if(fc==1)
                System.out.print(a+" is Prime Number");
            else
                System.out.print(a+ " is Not a Prime Number");
        }
    }    
}