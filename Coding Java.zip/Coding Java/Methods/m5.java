//5.Write a program to Print the Factorial of a number by using method.

import java.util.Scanner;

class Main{
    
    public static void main(String[]args){
        
        //Donot change anything in main method.
        
        Scanner sc = new Scanner(System.in);
        int N = sc.nextInt();
        Main obj = new Main();
        factorial(N);
    }
    
    //Create a program to print the factorial of a give number.
    //write your code here.
    public static void factorial(int N)
    {
        int fc  = 0;
        if (N<0)
        {
            N=-N;
        }
        for(int i=0; i<=N; i++)
        {
            if(i==0)
                fc=1;
            else
                fc*=i;
        }  
      System.out.print(fc);
     }
        
}