//9.Write a program to print first n numbers in Fibonacci series by using Methods ?

import java.util.Scanner;

class Main
{
    
    public static void main(String[]args){
        
        //Donot change anything in main method.
        
        Scanner obj = new Scanner(System.in);
        int n = obj.nextInt();
        fibonacci(n);
        if(n!=0)
            System.out.print(".");
    }
    
    //Create a method called fibonacci to print the first n fibonacci numbers.
    //Write your code here.
    public static void fibonacci(int n)
    {
        int a=0,b=1,fc=0;
        if(n==0)
        {
            System.out.print("Invalid InPut");
        }
        else
        {
            if(n<0)
                n=-n;
            for(int i=1; i<=n; i++)
            {
                System.out.print(a);
                fc++;
                if(fc<n)
                    System.out.print(", ");
                int c=a+b;
                a=b;
                b=c;
            }
        }
    }
    
}