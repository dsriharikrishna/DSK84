//6.Write a program to print the Alternative odd numbers by using Method between the Given Numbers ?

import java.util.Scanner;

class Main{
    
    public static void main(String[]args){
        
        Scanner obj = new Scanner(System.in);
        //Write your code here using isOdd method.
        int a = obj.nextInt();
        int b = obj.nextInt();
        int c=0,od=0;
        if(a==0 && b==0)
        {
            System.out.print("Both Inputs are Zero");
        }
        else if(a==0)
            System.out.print("First Input is Zero");
            
        else if(b==0)
            System.out.print("Second Input is Zero");
            
        else
        {
            if(a<0)
                a=-a;
            if(b<0)
                b=-b;
            for(int i=a+1; i<b; i++)
            {
                if(isOdd(i))
                {
                    od++;
                    if(od%2==1)
                    {
                        c++;
                        if(c!=1)
                        {
                            System.out.print(", ");
                        }
                        System.out.print(i);
                    }
                }
            }
            if(c==0)
                System.out.print("No Odd Numbers Between them");
            else
                System.out.print(".");
        }
    }
    
    static boolean isOdd(int N){
        
        //Donot change anything in this code.
        
        if(N%2!=0)
            return true;
        else
            return false;
    }
}