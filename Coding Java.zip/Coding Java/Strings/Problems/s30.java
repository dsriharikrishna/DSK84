/*
30.Write a program to print the all small characters, then print the capitals character, then print
the Special characters and print the numbers in a given String?
*/


import java.util.*;
class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        
        String s = sc.nextLine();
        
        for(int i=0;i<s.length();i++)
        {
            char ch = s.charAt(i);
            
            if(ch >= '0' && ch <= '9')
                System.out.print(ch+" ");

            else if(ch >='A' && ch <='Z')
                System.out.print(ch+" ");

            else if(ch >= 'a' && ch <= 'z')
                System.out.print(ch+" ");
                
            else 
                System.out.print(ch+" ");
        }
    }
}