//28. Write a program to count the number of Special keys in a given String?

import java.util.*;
class A
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		int c=0;
		for(int i=0;i<s.length();i++)
		{
			char ch = s.charAt(i);
			if(ch>=33 && ch<=47 || ch==64 || ch==94)
				c++;
		}
		System.out.print(c);
	}
}