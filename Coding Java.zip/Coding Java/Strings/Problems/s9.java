 /*
 9.Write a Program to print the string value from certain index to the end of the given String? 
 */

import java.util.*;
class A
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();

       // public int lastIndex(char,int )
       System.out.println(s.indexOf('a',5));
    }
}