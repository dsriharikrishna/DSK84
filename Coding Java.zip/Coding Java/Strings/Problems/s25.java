/*
25.Write a program to find the given word or a character is present or not in a given String?
*/

import java.util.*;

class A {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        String  k = sc.nextLine();
        int s1=0,c=0;

        for (int i = 0; i < s.length(); i++) 
        {
            for(int j=0;j < k.length(); j++)
            {
                if(s.charAt(i)==k.charAt(j))
                    s1++;
            }
        }
        if(s1!=0)
            System.out.println("Found");
        else 
            System.out.println("Not Found");


        /*if(s.contains(k))
            System.out.println("Found");
        else 
            System.out.println("Not Found");*/

    }
}