
/*
2.Write a Program to print the alternative vowels in a given string? 

*/

import java.util.*;

class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        int c=0;

        for(char i=0;i<s.length();i++)
        {
         
            if(s.charAt(i)=='a' || s.charAt(i)=='e' || s.charAt(i)=='i' || s.charAt(i)=='o' || s.charAt(i)=='u' ||s.charAt(i)=='A' || s.charAt(i)=='E' || s.charAt(i)=='I' || s.charAt(i)=='O' || s.charAt(i)=='U')   
            {   c++;
                if(c%2==1)
                    System.out.print(s.charAt(i)+" ");
            }
        }
    }
}