/*
32. Write a program to convert all small characters into capital characters and all capitals
characters into small characters of alternative places?

*/

import java.util.*;
class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        
        String s = sc.nextLine();
        
        for(int i=0;i<s.length();i++)
        {
            char ch = s.charAt(i);
            if(i%2==1)
            {
                if (Character.isLowerCase(ch)) 
                {
                    char upperCase = Character.toUpperCase(ch);
                    System.out.print(upperCase);
                } 
                else if (Character.isUpperCase(ch)) 
                {
                    char lowerCase = Character.toLowerCase(ch);
                    System.out.print(lowerCase);
                } 
                else 
                    System.out.print(ch);
            }
        }
    }
}
