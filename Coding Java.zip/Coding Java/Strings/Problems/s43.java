//43. Write a program to print the largest Unique word in a given String

import java.util.*;
class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        
        String s = sc.nextLine();
        String s1[] = s.split("\\s+");
        int max = Integer.MIN_VALUE;
        String x ="";
        int c=0;
        for(int i=0;i<s1.length;i++)
        {
            c=0;
            for(int j=0;j<s1.length;j++)
            {
                if(s1[i].equals(s1[j]))
                        c++;
            }
            if(c==1)
            {
                if(s1[i].length() > max)
                {
                    max = s1[i].length();
                    x = s1[i];
                }
            }
        } 
        System.out.println(x);
    }
}