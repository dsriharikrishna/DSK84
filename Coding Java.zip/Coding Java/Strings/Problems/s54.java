//54. Write a Program to print all the words in a given two Strings in sorted order?

import java.util.*;

class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        String s2 = sc.nextLine(); 

        String s1[] = s.split(" ");
        String s3[] = s2.split(" ");
        
        for(int i=0;i<s1.length;i++)
        {
            for(int j=0;j<s1.length;j++)
            {
                if(s1[i].length()<s1[j].length())
                {
                    String t = s1[i];
                    s1[i]=s1[j];
                    s1[j]=t;
                }
            }
            for(int j=0;j<s3.length;j++)
            {
                if(s1[i].length()<s3[j].length())
                {
                    String t = s3[i];
                    s3[i]=s3[j];
                    s3[j]=t;
                }
            }
        }
        System.out.println();

        for(int i=0;i<s1.length;i++)
            System.out.print(s1[i]+" ");

        System.out.println();
        
        for(int i=0;i<s3.length;i++)
            System.out.print(s3[i]+" ");
    }
}