
/*
3.Write a program to print the biggest / longest word in a given String?
*/

import java.util.*;
class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        String[] words = s.split(" ");
        String largestWord = "";

        for(String word : words )
        {
            if(word.length()>largestWord.length())
                largestWord = word;
        }
        System.out.print("The Largest Word is :  "+largestWord);
    }
}