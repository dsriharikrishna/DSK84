
import java.util.*;

class A
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		String s = sc.next();
		if(s.length()!=10 && s.length()!=13)
			isvalid();

		if(s.length()==13 && s.charAt(2)==' ' && s.charAt(5)==' ' && s.charAt(8)==' ')
			s = s.replace(" ","");
			
		if(s.length()!=10)
			isvalid();
		
		for(int i=0;i<s.length();i++)
		{
			if(i<=1 || i==4 || i==5)
				isAlpha(s.charAt(i));
			else
				isDigit(s.charAt(i));
		}
		System.out.println("Valid Registration Number");
	}
	public static void isAlpha(char ch)
	{
		if(!(ch>='A' && ch<='Z'))
			isvalid();
	}
	public static void isDigit(char ch)
	{
		if(!(ch>='0' && ch<='9'))
			isvalid();
	}
	public static void isvalid()
	{
		System.out.println("Invalid Registration Number");
		System.exit(0);
	}
}