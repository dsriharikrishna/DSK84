/*
22.Write a Program to check/validate given String value is Valid Pan Number or Not?

IP - JRVPK6441L
OP - VALID PAN NUMBER 
*/

import java.util.*;

class A
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();

		if(s.length()!=10)
			answer();
		for(int i=0;i<s.length();i++)
		{
			if(i<=2  || i==4  ||  i==9)
				isAlpha(s.charAt(i));
			else if(i!=3)
				isDigit(s.charAt(i));
			else if(!(s.charAt(i)=='A' || s.charAt(i)=='P' || s.charAt(i)=='C' || s.charAt(i) == 'H' || s.charAt(i)=='T' || s.charAt(i)=='F'))
				answer();
		
		}	
		System.out.println("Valid Pan Number");
	}
	public static void isAlpha(char ch)
	{
		if(!(ch >='A' && ch <='Z'))
		answer();
	}
	public static void isDigit(char ch)
	{
		if(!(ch >='0' && ch<='9'))
			answer();
	}
	public static void answer()
	{
		System.out.println("Invalid Pan Number");
		System.exit(0);
	}
}
	