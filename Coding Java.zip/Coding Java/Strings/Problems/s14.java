/*
14.  Write a Program to replace the one  word by another word in a given string?
*/

import java.util.*;
class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        String a = sc.nextLine();
        // public replaceAll(String,String)
        System.out.println(s.replace(s,a));
    }
}
 