/*
6.Write a Program to print the last index of a given character in a given string?
*/

import java.util.*;
class A
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        System.out.println(s);
        System.out.print(s.lastIndexOf('a',6));
    }
}