//50. Write a program to print all characters in alphabetical order in a given string with repetition?

import java.util.*;

class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        s = s.replace(" ","");
        char s1[] = s.toCharArray();
        
        for(int i=0;i<s1.length;i++)
        {
            for(int j=i+1;j<s1.length;j++)
            {
                if(s1[i]>(s1[j]))
                {
                    char t = s1[i];
                    s1[i]=s1[j];
                    s1[j]=t;
                }
            }
        }
        for(int i=0;i<s1.length;i++)
            System.out.print(s1[i]+" ");
    }
}