//52. Write a Program to print the common Unique words in a given two Strings?

import java.util.*;

class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        String s1 = sc.nextLine();

        String s2[] = s.split(" ");
        String s3[] = s1.split(" ");
        int c=0,d=0;

        for(int i=0;i<s2.length;i++)
        {
            c=0;
            for(int j=0;j<s2.length;j++)
            {
                if(s2[i].equals(s2[j]))
                    c++;
            }
            if(c==1)
            {
                d=0;
                for(int j=0;j<s3.length;j++)
                {
                    if(s2[i].equals(s3[j]))
                        d++;
                }
            }
            if(d==1)
                System.out.println(s2[i]+" -> "+d); 
        }
    }
}