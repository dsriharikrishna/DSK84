/*
27. Write a program to find the numbers in a given String and print there index values?

*/

import java.util.*;
class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        
        String s = sc.nextLine();
        
        for(int i=0;i<s.length();i++)
        {
            char ch = s.charAt(i);
            if(ch >= '0' && ch <= '9')
            {
                System.out.println(ch+" -> "+i);
            }
        }
    }
}