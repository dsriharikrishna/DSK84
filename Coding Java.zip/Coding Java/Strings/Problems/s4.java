/*
4.Write a Program to print the ASCII key values of a given String characters?
*/

import java.util.*;
class A
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        System.out.println(s);
        System.out.print(s.codePointAt(6));
    }
}