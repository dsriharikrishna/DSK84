/*
40. Write a program to print the words in given string to the count(Repetation) in decreasing
order?
*/

import java.util.*;
class A 
{

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		String s1[]=s.split(" ");
		int n=0;
		for(int i=0;i<s1.length;i++)
		{
			int c=0;
			for(int j=0;j<i;j++)
			{
				if(s1[i].equals(s1[j]))
					c++;
			}
			if(c==0)
				n++;
		}
		String s2[] = new String[n];
		int s3[] = new int[n];
		int m=0;
		for(int i=0;i<s1.length;i++)
		{
			int c=0;
			for(int j=0;j<i;j++)
			{
				if(s1[i].equals(s1[j]))
					c++;
			}
			if(c==0)
			{
				int c1=0;
				for(int j=0;j<s1.length;j++)
					if(s1[i].equals(s1[j]))
						c1++;
				s2[m]=s1[i];
				s3[m]=c1;
				m++;
			}
		}
		for(int i=0;i<n;i++)
		{
			for(int j=i+1;j<n;j++)
			{
				if(s3[i]<s3[j])
				{
					int t=s3[i];
					s3[i]=s3[j];
					s3[j]=t;
						
					String t1=s2[i];
					s2[i]=s2[j];
					s2[j]=t1;
				}
			}
		}
		for(int i=0;i<n;i++)
			System.out.printf("%-15s% 2d\n",s2[i],s3[i]);
	}

}