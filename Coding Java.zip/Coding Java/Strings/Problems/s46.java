//46. Write a program to find the given substring is there are not in a given String?

import java.util.*;
class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        char s1[] = s.toCharArray();

        for(int i=0;i<s1.length;i++)
        {
            for(int j=i;j<s1.length;j++)
            {
                for(int k=i;k<=j;k++)
                {
                    System.out.print(s1[k]+" ");
                }
                System.out.println();
            }
        }
    }
}