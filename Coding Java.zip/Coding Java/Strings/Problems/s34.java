/*
34.Write a program to print the all given words in reverse without changing words positions?
Input: to print the all given words
Output:ot tnirp eht lla nevig sdrow

*/
import java.util.Scanner;

class A
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		String str="to print the all given words";
		String s[]=str.split(" ");

		System.out.println(str);
		for(int i=0;i<s.length;i++)
		{
			StringBuilder rev = new StringBuilder(s[i]);
			rev.reverse();
			System.out.print(rev+" ");
		}
	}
}
