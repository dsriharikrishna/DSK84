//26.  Write a program to find the index values of a given word in a given String? 

import java.util.*;
class A
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		System.out.println(s);
		String wd=sc.next();
		int l = s.indexOf(wd);
		
		for(int i=l;i<s.length();i++)
		{
			if(i>l && s.charAt(i)==32)
			{
               	 break;
            }
			System.out.print(i+" ");
		}
		
	}
}
