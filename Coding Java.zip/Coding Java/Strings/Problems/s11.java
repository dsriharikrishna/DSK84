/*
11.Write a Program to store the given String in character array and then print that character 
array?

*/
import java.util.*;
class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        String []words = s.split("");
        
        System.out.print(Arrays.toString(words));
    }
}