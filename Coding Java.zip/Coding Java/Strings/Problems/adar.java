/*
21.Write a Program to check/validate given String value is Valid Aadhar Number or not?

Input1:	439876875869
Ouput1:Valid Aadhar Number
Input2:	43@776875869
Ouput2: Not A Valid Aadhar Number

*/

import java.util.*;

class A
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
        	int c=0,sp=0;
		
		if(s.length()==12 || s.length()==14)
		{
			c = 0;
			for(int i=0;i<s.length();i++)
			{
				if(s.length() ==14 && (i==4 || i==9))
				{
					if(s.charAt(i)<=' ')
					 sp++;
				}
				else
				{
					if(s.charAt(i)>='0' && s.charAt(i)<='9')
						c++;
				}
			}
			if(!(s.length()==14 && sp==2 && c==12) || s.length() ==12 && c==12)
				System.out.println("Not A Valid Aadhar Number");
			else
                System.out.println("Valid Aadhar Number");
		}
		else
			System.out.println("Valid Aadhar Number");
	}
}