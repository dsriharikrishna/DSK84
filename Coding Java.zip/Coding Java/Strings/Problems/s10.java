/*
10.Write a Program to print the String value from certain index to certain index of  a given 
string?
 
*/

import java.util.*;
class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        String[] words = s.split(" ");
       
        System.out.print(Arrays.toString(words));
    }
}