/*
56. Write a Program to print to the given String characters as shown in example?
Ex:- Input:- I am preparing myself for MNC’s and Product based companies.
Output:- 

I
am
pre
pari
ngmys
elffor
MNC’san
dProduct
basedcomp
anies.

*/

import java.util.*;
class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        String s =  sc.nextLine();
        s = s.replace(" ","");
        int x=0,y=0;
        for(int i=0;;i++)
        {
            x++;
            if(x+y>s.length()-1)
            {
                System.out.println(s.substring(y,s.length()));
                break;
            }
            else 
            {
                System.out.println(s.substring(y,x+y));
                y=x+y;
            }
        }
        sc.close();
    }
}