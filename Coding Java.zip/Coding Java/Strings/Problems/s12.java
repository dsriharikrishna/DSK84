/*
12. Write a Program to check the given character/String in a another given String?
*/

import java.util.*;
class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        String[] words = s.split(" ");
       
        System.out.print(Arrays.toString(words));
    }
}