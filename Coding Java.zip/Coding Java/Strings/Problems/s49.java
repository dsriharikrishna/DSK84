//49. Write a program to print the “N” number of time repeated word in a given string?

import java.util.*;

class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        String s1[] = s.split(" ");
        int k = sc.nextInt();

        for(int i=0;i<s1.length;i++)
        {
            int c=0,d=0;
            for(int j=0;j<i;j++)
            {
                if(s1[i].equals(s1[j]))
                    c++;
            }
            if(c==0)
            {
                d=0;
                for(int j=0;j<s1.length;j++)
                {
                    if(s1[i].equals(s1[j]))
                        d++;
                }
                if(d==k)
                    System.out.println(s1[i]);
                else 
                {
                    System.out.println("levu ra avula unnadhi kottu");
                    break;
                }
            }

        }
    
    }
}
