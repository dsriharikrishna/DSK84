/*
20.  Write a Program to check which is first word in dictionary order of given two words by 
ignoring Case? */

import java.util.*;
class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        String s1 = sc.nextLine();

        System.out.println(s.compareTo(s1)<0);

    }
}
