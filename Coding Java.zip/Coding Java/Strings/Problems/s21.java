/*
21.Write a Program to check/validate given String value is Valid Aadhar Number or not?

Input1:	439876875869
Ouput1:Valid Aadhar Number
Input2:	43@776875869
Ouput2: Not A Valid Aadhar Number

*/
import java.util.*;
class A 
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		String a = sc.nextLine();
		int c=0,s=0,s1=0;

        if(a.length() >= 12 && a.length()<= 14)
		{
			for (int i = 0; i < a.length(); i++) 
			{
				if(a.charAt(4)-32 == 0 && a.charAt(8)-32==0)
				{
         		    s++;
				}
        	    if (a.charAt(i) >= '0' && a.charAt(i) <= '9')
				{
        	        c++;
        	    } 
				else
				  	s1++;
         	}
			if((c == 12 && s1 == 0 && s==0) || (c==12 && s==2 && s1==0))
				System.out.println("Valid Aadhar Number");
			else 
				System.out.println("Not a Valid Aadhar Number");
		}
    }
}
// Using String Methods 
// import java.util.*;
// class A 
// {
// 	public static void main(String args[])
// 	{
// 		Scanner sc = new Scanner(System.in);
// 		String s = sc.nextLine();

// 		if((s.matches("^[1-9][0-9]{11}$")) || (s.matches("^[1-9][0-9]{3}[ ]{1}[0-9]{4}[ ]{1}[0-9]{4}$")))
// 				System.out.println("Valid Aadhar Number");
// 		else
// 			System.out.println("Not a Valid Aadhar Number");
// 	}
// }

