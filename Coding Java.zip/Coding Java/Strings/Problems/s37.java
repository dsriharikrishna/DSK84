import java.util.*;
class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        
        String s = sc.nextLine();
        String s1[] = s.split("\\s+");
        int c=0;
        
        for(int i=0;i<s1.length;i++)
            c++;
            
        System.out.println(c+" ");
    }
}