
import java.util.*;

class A
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		String s = sc.next();
		if(s.length()!=10 && s.length()!=13)
			isvalid();

		if(s.length()==13 && s.charAt(2)==' ' && s.charAt(5)==' ' && s.charAt(8)==' ')
			s = s.replace(" ","");
			
		if(s.length()!=10)
			public static void isAlpha(char ch)
	{
		if(!(ch>='A' && ch<='Z'))
			isvalid();
	}
	public static void isDigit(char ch)
	{
		if(!(ch>='0' && ch<='9'))
			invalid();
	}
	public static void invalid()
	{
		System.out.println("Invalid Registration Number");
		System.exit(0);
	}
}