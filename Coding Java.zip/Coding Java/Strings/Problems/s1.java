/*

1.Write a Program to print the alternative characters in a given String input?

*/

import java.util.*;

class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        int c=0;

        for(char i=0;i<s.length();i++)
        {
            c++;
            if(c%2==1)
                System.out.println(s.charAt(i));
        }
    }
}