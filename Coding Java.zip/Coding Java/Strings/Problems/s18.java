/*
18.  Write a Program to understand equalsIgnoreCase method in strings? 
*/

import java.util.*;
class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        String a = sc.nextLine();
        // public equalsIgnoreCase(String,String)
        System.out.println(s.equalsIgnoreCase(a));
    }
}
 
