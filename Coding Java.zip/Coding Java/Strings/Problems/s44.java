//44. Write a program to print the words and count of the duplicate words in a given String?

import java.util.*;
class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        String s1[] = s.split("[^a-z0-9]+");
        int c=0,k=0;

        for(int i=0;i<s1.length;i++)
        {
            k=0;
            for(int j=0;j<i;j++)
            {
                if(s1[i].equals(s1[j]))
                    k++;
            }
            if(k==0)
            {
                c=0;
                for(int j=0;j<s1.length;j++)
                {
                    if(s1[i].equals(s1[j]))
                        c++;
                }
                System.out.println(s1[i]+" "+c);
            }
        }
    }
}