/*
22.Write a Program to check/validate given String value is Valid Pan Number or Not?

IP - JRVPK6441L
OP - VALID PAN NUMBER 

*/

import java.util.*;
class A 
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine().toUpperCase();

		if(s.matches("^[A-Z]{3,3}[PACFHT]{1,1}[A-Z]{1,1}[0-9]{4,4}[A-Z]{1,1}$"))
				System.out.println("Valid Pan Number");
		else
			System.out.println("Not A Valid Pan Number");
	}
}
