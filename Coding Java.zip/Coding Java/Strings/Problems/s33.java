/*
33.Write a program to print the reverse of a given word ?
*/

import java.util.*;
class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        
        String s = sc.nextLine();
        String rev = "";

        for(int i=s.length()-1;i>=0;i--)
            rev += s.charAt(i);
        System.out.print(rev+" ");

    sc.close();
    }
}
