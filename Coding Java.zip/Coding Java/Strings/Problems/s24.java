/*
24.Write a Program to check/validate given Password is perfect or not and the conditions are
Password length must be 9 characters and must at least one capital, one small, one
number and one special character (except space) ?
*/

import java.util.*;

class A {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        int s1 = 0, s2 = 0, s3 = 0, s4=0,c = 0;

        if (s.length() > 9 && s.length() <= 16)
        {
            for (int i = 0; i < s.length(); i++) 
            {
                char ch = s.charAt(i);
                
                if (ch >= '0' && ch <= '9')
                    c++;
                else if (ch >= 'A' && ch <= 'Z')
                    s1++;
                else if(ch >= 'a' && ch <= 'z')
                    s4++;
                else if (ch == ' ')
                    s2++;
                else
                    s3++;
            }
            if (s1 != 0 && s2 == 0 && s3 != 0 && c != 0 && s4!=0)
                System.out.println("Valid Password");
            else 
                System.out.println("Invalid Password");
        } 
        else
            System.out.println("Invalid Password Length");
    }
}
