//16.Write a Program to understand the use of the trim method in strings?

import java.util.*;

class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();

        String s1 = s.trim().replace(" ","@");
        String s2[] = s1.split("@");
        System.out.println(s1);
//         System.out.println();
//         for(int i=0;i<s2.length;i++)        
//             System.out.println(s2[i]);
//         System.out.println();
//         int c=0,d=0;
//         String dd="";
//         for(int i=0;i<s2.length;i++)
//         {
            
//             for(int j=0;j<s2.length;j++)
//             {
//                 if(s2[i].length()<s2[j].length())
//                 {
//                     String t = s2[i];
//                     s2[i] = s2[j];
//                     s2[j] = t;
//                 }
//             }
//             for(int j=0;j<s2.length;j++)
//             {
//                 if(s2[i].compareTo(s2[j])<0)
//                 {
//                     String t = s2[i];
//                     s2[i] = s2[j];
//                     s2[j] = t;
//                 }
//             }
//             c=0;
//             for(int j=0;j<s2.length;j++)
//             {
//                 if(s2[i].equals(s2[j]))
//                 {
//                     c++;
//                 }
//             }
//         }
//         for(int i=0;i<s2.length;i++)   
//         {
//             if(!dd.equals(s2[i])){
//                 System.out.println(s2[i]+" "+c);
//                     dd=s2[i];
//             }
//         }
    }
}