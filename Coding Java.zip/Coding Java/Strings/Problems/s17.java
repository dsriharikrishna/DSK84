/*
17.  Write a Program to understand that where we have to use == and equals Method  in strings? */

import java.util.*;
class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        String a = sc.nextLine();
        // public equals(String,String)
        System.out.println(s==a);
        System.out.println(s.equalsIgnoreCase(a));
    }
}
