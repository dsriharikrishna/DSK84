//36.Write a program to find the given String is Palindrome or not?

import java.util.*;
class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        
        String s = sc.nextLine();
        String rev = "";
        for(int i=s.length()-1;i>=0;i--)
        {
            rev += s.charAt(i);
        }
        if(rev.equals(s))
            System.out.print(" Pallindrome ");
        else 
             System.out.print(" Not a Pallindrome ");
    }
}
