//38. Write a program to find the count of a each and every character in a given String?

import java.util.*;
class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        
        String s = sc.nextLine();
        
        for(int i=0;i<s.length();i++)
        {
            int c=0;
            for(int j=0;j<=i;j++)
            {
                if(s.charAt(i)==s.charAt(j))
                    c++;
            }  
            System.out.println(s.charAt(i)+" "+c);
        }
    }
}