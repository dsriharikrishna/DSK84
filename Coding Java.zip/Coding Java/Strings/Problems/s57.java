/*
4.Write a program to print Largest Substring without Duplicate Characters.

Input 1 :     aabac

Output 1:     bac

Input 2 :     akanksha

Output 2:     anksh

*/

import java.util.*;
class Main
{
public static void main(String[]args)
{
    Scanner sc=new Scanner(System.in);
    String s=sc.nextLine();
    int t=0;
    String subs="";
    for(int i=0;i<s.length();i++)
    {
        String sub="";
        for(int j=i;j<s.length();j++)
        {
            String s1=s.substring(i,j+1);
            int c=0;
            for(int k=0;k<s1.length();k++)
            {
                for(int m=0;m<s1.length();m++)
                {
                    if(m!=k)
                    {
                        if(s1.charAt(k)==s1.charAt(m))
                            c++;
                    }
                }
            }
            if(c==0)
            {
                sub=s1;
            }
            if(sub.length()>t)
            {
                t=sub.length();
                subs=sub;
            }
        }
    }
    System.out.print(subs);
}
}

/*

import java.util.*;

class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        String k ="";

        for(int i=0;i<s.length();i++)
        {
            for(int j=i;j<s.length();j++)
            {
                if(isValid(s.substring(i,j+1)))
                {
                    if(k.length()<s.substring(i,j+1).length())
                            k=s.substring(i,j+1);
                }
            }   
        }
        System.out.println(k);
    }
    static boolean isValid(String k)
    {
        for(int i=0;i<k.length();i++)
        {
            for(int j=i+1;j<k.length();j++)
            {
                if(k.charAt(i)==k.charAt(j))
                    return false;
            }
        }
        return true;
    }
}

*/


/*
import java.util.*;
class Main
{
public static void main(String[]args)
{
    Scanner sc=new Scanner(System.in);
    String s=sc.nextLine();
    int c=0;
    String s1 = "";
    for(int i=0;i<s.length();i++)
    {
        for(int j=i;j<s.length();j++)
        {
            String l = s.substring(i,j+1);
            HashSet  <Character> Hs = New HashSet<>();
            
            for(int k=0;k<l.length();k++)
            {
                if(!Hs.add(l.charAt(k))
                    c++;
            }
            if(c==0)
            {
                if(s1.length()<l.length())
                    s1=l;
            }
        }
    }
    System.out.print(s1);
    }
}
  
 */