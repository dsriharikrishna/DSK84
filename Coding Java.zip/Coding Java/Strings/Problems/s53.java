//53. Write a Program to print all the words in a given two Strings by one time only?

import java.util.*;

class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        String s1 = sc.nextLine();
        //cancat the two Strings 
        String s2 =  s+" "+s1;

        String a[] = s2.split(" ");

        for(int i=0;i<a.length;i++)
        {
            int c=0;
            for(int j=0;j<i;j++)
            {
                if(a[i].equals(a[j]))
                    c++;
            }
            if(c==0)
            {
                for(int j=0;j<a.length;j++)
                {
                    if(a[i].equals(a[j]))
                        c++;
                }
            }
            if(c!=0)
                System.out.print(a[i]+" ");            
        }
    }
}

/**import java.util.HashSet;
import java.util.Set;

class A 
{
    public static void printUniqueWords(String str1, String str2) {

        String[] wordsStr1 = str1.split("\\s+");
        String[] wordsStr2 = str2.split("\\s+");

    
        Set<String> uniqueWords = new HashSet<>();

        for (String word : wordsStr1) {
            uniqueWords.add(word);
        }

        for (String word : wordsStr2) {
            uniqueWords.add(word);
        }

        for (String word : uniqueWords) {
            System.out.println(word);
        }
    }

    public static void main(String[] args) {
        String string1 = "Hello there! How are you?";
        String string2 = "I'm doing well, thank you.";

        printUniqueWords(string1, string2);
    }
}

import java.util.*;
class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        String s1 = sc.nextLine();

        String s2[] = s.split(" ");
        String s3[] = s1.split(" ");
        
        ArrayList<String> sl1  = new ArrayList<>();
        ArrayList<String> sl12 = new ArrayList<>();
        ArrayList<String> sl2  = new ArrayList<>();
        
        for(int i=0;i<s2.length;i++)
            sl1.add(s2[i]);
        for(int i=0;i<s3.length;i++)
            sl2.add(s3[i]);
        for(int i=0;i<s2.length;i++)
            sl12.add(s2[i]);

        sl1.removeAll(sl2);
        sl2.removeAll(sl12);
        System.out.println(sl1);
        System.out.print(sl2);
    }
}

 */
