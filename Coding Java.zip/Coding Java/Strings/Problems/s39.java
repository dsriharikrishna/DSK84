//39. Write a program to print most repeated character and word in a given String?

import java.util.*;
class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        
        String s = sc.nextLine();
        String s2[] = s.split(" ");
        char ch = '\0';
        int t=0,c=0,s1=0;
        for(int i=0;i<s.length();i++)
        {
            c=1;
            for(int j=i+1;j<s.length();j++)
            {
                if(s.charAt(i)==s.charAt(j))
                    c++;
                if(s.charAt(i)<=' ')
                    s1++;
            }
            if(c!=0 && s1==0)
            {
                if(c>t)
                {
                    t = c;
                    ch = s.charAt(i);
                }
            }
        }
        if(t!=0)
            System.out.println(ch +" -> "+t);
        else
            System.out.println("hi");
    }
}