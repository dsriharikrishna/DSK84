/*
19. Write a Program to check which is first word in dictionary order of given two words?
*/

import java.util.*;
class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        
        System.out.println(s.compareTo(s)<0);
    
        sc.close();
    }
}
