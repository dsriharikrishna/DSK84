/*
48. Write a program to sort the words in a given String according to alphabetically
(lexigrophically)?

*/

import java.util.*;

class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        String s1[] = s.split(" ");
        
        for(int i=0;i<s1.length;i++)
        {
            for(int j=i+1;j<s1.length;j++)
            {
                if(s1[i].compareTo(s1[j])>0)
                {
                    String t = s1[i];
                    s1[i]=s1[j];
                    s1[j]=t;
                }
            }
        }
        for(int i=0;i<s1.length;i++)
            System.out.println(s1[i]);
    }
}
