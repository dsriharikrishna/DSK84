/*
7. Write a Program to print the all the index’s of a given character in a given string?
*/

import java.util.*;
class A
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        char a = sc.next().charAt(0);
        for(int i=0;i<s.length();i++)
        {
            if(s.charAt(i) == a)
                System.out.print(i+" ");
        }
    }    
}