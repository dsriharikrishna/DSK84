// public boolean isEmpty() 

class A
{
    public static void main(String args[])
    {
        String s = "";
        System.out.println((s.isEmpty()));

        s=s+"DSK";
        System.out.println(s.isEmpty());
    
        // public replace(char,char)

        String a = "java";
        System.out.println(a.replace('a','x'));

        // public replace(String,String)
        // public replaceAll(String,String)

        String b = "I am Dasari SriHK";
        System.out.println(b.replace("SriHK","SRIHARIKRISHNA"));
 
        // public replaceFIrst(String,String)

        String s1 = "Java Code , Python Code";
        System.out.println(s1.replaceAll("Code","Program"));
        System.out.println(s1.replaceFirst("Code","Program"));

    }
}

