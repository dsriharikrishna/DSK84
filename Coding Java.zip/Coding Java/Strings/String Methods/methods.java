java
Copy code
boolean empty = str.isEmpty(); // false
equals(String anotherString): Compares the content of two strings.

java
Copy code
boolean isEqual = str.equals("Hello"); // true
equalsIgnoreCase(String anotherString): Compares two strings, ignoring their case.

java
Copy code
boolean isEqualIgnoreCase = str.equalsIgnoreCase("hello"); // true
contains(CharSequence sequence): Checks if the string contains a specified sequence of characters.

java
Copy code
boolean contains = str.contains("ell"); // true
split(String regex): Splits the string based on a specified regular expression and returns an array of substrings.

java
Copy code
String sentence = "This is a sentence";
String[] words = sentence.split(" "); // ["This", "is", "a", "sentence"]
startsWith(String prefix, int offset) / endsWith(String suffix): Allows checking for prefix or suffix from a specific index.

java
Copy code
boolean starts = str.startsWith("He", 0); // true
boolean ends = str.endsWith("lo"); // true
compareTo(String anotherString): Compares two strings lexicographically.

java
Copy code
int comparison = str.compareTo("Hello"); // 0 (if equal)
valueOf(dataType value): Converts different data types to string representation.

java
Copy code
int number = 10;
String numStr = String.valueOf(number); // "10"
replaceAll(String regex, String replacement): Replaces all occurrences of a substring that matches the given regular expression.

java
Copy code
String replacedAll = str.replaceAll("l", "L"); // "HeLLo"
matches(String regex): Checks if the string matches a given regular expression.

java
Copy code
boolean matches = str.matches("[a-zA-Z]+");