// public int Compare o Ignorecase(String )

class A
{
    public static void main(String args[])
    {
        String a = "Apple";
        String b = "ant";

        System.out.println(a.compareTo(b));
        System.out.println(a.compareToIgnoreCase(b));

        /*
       A - a = a-a=0;  //65-65
       p - n = 112-110 = 2

        */
        String c = "Apple";
        String d = "Apple Fruit";

        System.out.println(c.compareTo(d));

        /*
            A-A=0
            p-p=0
            p-p=0
            l-l=0
            e-e=0
            a.length()-b.length() = 5-11
                                  = -6
          */

        String e = "Apples";
        String f = "Apple Fruit";

        System.out.println(e.compareTo(f));
        /*
            space asci value = 32
            A-A=0
            p-p=0
            p-p=0
            l-l=0
            e-e=0
            s-space = 115-32
                    = 83
          */

          String s = "Apple";
          String t = "Apricot";
  
          System.out.println(s.compareTo(t));
          /*
              A-A=65-65=0
              p-p=112-112=0
              p-r=112-114=-2

          */
    }
}