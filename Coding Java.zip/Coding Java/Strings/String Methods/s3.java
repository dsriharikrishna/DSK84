// public concatenate() 

class A {
    public static void main(String args[]) {
    
        String c = "Srihari";
        String d = "Krishna";

        System.out.println(c.concat(d)); 
        System.out.println(c+" "+d); 
    }
}
