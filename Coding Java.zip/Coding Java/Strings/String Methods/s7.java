// public int codePointAt() 

class A
{
    public static void main(String args[])
    {
        String a = "Programming";

        System.out.print(a.codePointAt(5));
        
    }
}