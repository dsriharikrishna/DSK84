// public int CodePointCount(int,int)  

class A
{
    public static void main(String args[])
    {
        String s = "Programming";
        String d = "SRIHARIKRISHNA";
  
        System.out.println(s.codePointCount(5,8));
        System.out.println(d.codePointCount(3,13));

    }
}