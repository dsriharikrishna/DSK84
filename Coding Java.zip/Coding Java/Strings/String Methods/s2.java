//* public boolean contentEquals() 

class A {
    public static void main(String args[]) {
        String a = "Srihari";
        String b = "Srihari";

        System.out.println(a.contentEquals(b));

        String c = "Srihari Krishna";
        String d = "Srihari";

        System.out.println(a.contentEquals(c)); // This should compare 'a' with 'c'
        System.out.println(a.contentEquals(d)); // This should compare 'a' with 'd'
    }
}

