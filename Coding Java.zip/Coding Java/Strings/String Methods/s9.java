// public int lastIndex(char)

class A
{
    public static void main(String args[])
    {
        String a = "Java Program";
        System.out.println(a.indexOf('a'));

        // public int lastIndex(char,int )

        String s = "Java Program";
        System.out.println(s.indexOf('a',5));
  
        // public int lastIndex(String )

        String d = "Java Code, Python code ";
        System.out.println(d.indexOf("code"));

        // public int lastIndex(String,int)
        String e = "Java Code, Python code ";
        System.out.println(e.indexOf("code",18));

    }
}