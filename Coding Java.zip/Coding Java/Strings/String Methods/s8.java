// public int indexOf(char)

class A
{
    public static void main(String args[])
    {
        String s = "Programming";
        String d = "SRIHARIKRISHNA";
  
        System.out.println(s.indexOf('r'));
        System.out.println(d.indexOf('H'));


        // public int indexOf(char)
        String a = "Programming";
        String b = "SRIHARIKRISHNA";
  
        System.out.println(a.indexOf('r',3));
        System.out.println(b.indexOf('H',10));

       //public int indexOf(String)


        String p = "Java Programming, Python Programming";
        System.out.println(p.indexOf("Programming"));

        //public int indexOf(String,int)


        String t = "Java Programming, Python Programming";
    
        System.out.println(t.indexOf("Programming",15));
        System.out.println(t.indexOf("Programming",25));

    }
}