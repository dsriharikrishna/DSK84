// static String copyValueOf(char [])

class A {
    public static void main(String args[]) {
        // Define the method outside the main method
      
            char ch[] = { 's', 'r', 'i', 'h', 'a', 'r', 'i' };
            String s = String.copyValueOf(ch);
            System.out.print(s);
    }
}
