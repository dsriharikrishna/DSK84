// public int CodepOintBefore 

class A
{
    public static void main(String args[])
    {
        String a = "Programming";
        System.out.print(a.codePointBefore(1));
    }
}