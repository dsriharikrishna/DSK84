/*
Merge two arrays into a single array.
Ex:- input:-{ 1 2 3 } { 10 20 30 }
	Output:- { 1 2 3 10 20 30 }
*/
import java.util.*;
class A
{
	public static void main(String args[])
	{
			Scanner sc = new Scanner(System.in);
			int n  = sc.nextInt();
			//int c[] = ;

			if(n<=0)
				System.out.print("Invalid Array SIze.");
			else
			{
				int a[] = new int[n];
				int b[] = new int[n];
				for(int i=0;i<n;i++)
				{
					a[i] = sc.nextInt();
					b[i] = sc.nextInt();
				}
				System.out.print("{");
				for(int i=0;i<n;i++)
				{
					System.out.print(a[i]+" ");
					System.out.print(b[i]+" ");
				}
				System.out.print("}");
			}
		sc.close();
	}
}