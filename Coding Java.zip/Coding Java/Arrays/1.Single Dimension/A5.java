//Write a Program to find the Sum of Numbers upto the Given Key Value(index) in a Given Array.
import java.util.*;
class A 
{
    public static void main(String args[])
    {
        Scanner sc  = new Scanner(System.in);
        int n = sc.nextInt(),sum=0;
        if(n>1 && n<10)
        {
            int a[] = new int[n];
            for(int i=0;i<n;i++)
            {
                a[i] = sc.nextInt();
            }
            int k = sc.nextInt();
            if(k<0 || k>=n)
                System.out.print("Invalid Key Value");
            else
            {
                for(int i=0;i<=k;i++)
                    sum+=a[i];
        
                System.out.print(sum);
            }
        }
        else
            System.out.print("Invalid Array Size");
        sc.close();
    }
}
