//Write a Program to find and print the first 3 Biggest Element from Given Array?

import java.util.*;
class Main 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        if(n<=0)
            System.out.print("Invalid Array Size");
        else
        {
            int a[] = new int[n];
            for(int i=0;i<n;i++)
            {
                a[i] = sc.nextInt();
            }
            int M = Integer.MIN_VALUE;
            int m1=0,m2=0;
            for(int i=0;i<n;i++)
            {
                if(a[i]>M)
                {
                    m2 = m1;
                    m1 = M;
                    M = a[i];
                }
                else if(m1>M)
                {
                    m2 =m1;
                    m1= a[i];
                }
                else
                    m2= a[i];
                    
                for(int j=0;j<n;j++)
                {
                    if(a[i]>a[j])
                    {
                        int t = a[i];
                        a[i] = a[j];
                        a[j] = t;
                    }
                }
            }
            System.out.println(M +" "+m1+" "+m2);
            System.out.print(a[0] +" "+a[1]+" "+a[2]);
        }
        
        sc.close();
    }
}