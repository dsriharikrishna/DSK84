/*
2.Ask user for input n, Search n in the array. 
If found print Found else print Not-Found. 
Using Binary Search Algorithms.
*/
import java.util.*;
class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        
        if(n<=0)
            System.out.print("Invalid Array Size.");
        else
        {
            int a[] = new int[n];
            for(int i=0;i<n;i++)
            {
                a[i] =sc.nextInt();
            }
            for(int i=0;i<n;i++)
            {
                for(int j=i+1;j<n;j++)
                {
                    if(a[i]>a[j])
                    {
                        int t = a[i];
                        a[i] = a[j];
                        a[j] = t;
                    }
                }
            }
            int s=0,e=n-1;
            int k = sc.nextInt();
            while(s<=e)
            {
                int m = ((s+e)/2);
                if(a[m]==k)
                {
                    System.out.print("FOUND");
                    break;
                }
                else if(a[m]<k)
                    s=m+1;
                else   
                    e=m-1;
            }
            if(s>e)
                System.out.print("NOT FOUND");

        sc.close();
        }
    }
}