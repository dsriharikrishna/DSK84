//Write a program to Find and Print the Second Highest Element from Array.

import java.util.*;
class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        if(n<=1)
            System.out.print("Invalid Array Size");
        else
        {
            int a[] = new int[n];
            for(int i=0;i<n;i++)
            {
                a[i]=sc.nextInt();
            }
            int Max = Integer.MIN_VALUE;
            int m1 = 0;
            for(int i=0;i<n;i++)
            {
                if(a[i]>Max)
                {
                    m1 = Max;
                    Max = a[i];
                }
                else if(a[i]>m1)
                    m1=a[i];
            }
            System.out.print(m1);

        }
        sc.close();
    }
}