//Write a Program to Find and Print the First Four Smallest Numbers Missing from 
//the Given Array from the Smallest Element in a Given Array.

import java.util.*;
class A
{
	public static void main(String[] args)
	{
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int c=0;
        if(n<=0)
        {
            System.out.print("Invalid Array Size.");
        }
        else
        {
            int a[] = new int[n];
            int Min = Integer.MAX_VALUE;
            for(int i=0;i<n;i++)
            {
                a[i] = sc.nextInt();
                if(a[i]<Min)
                    Min = a[i];
            }
            int k = 0;
            while(k<4)
            {
                Min++;
                c=0;
                for(int i=0;i<n;i++)
                {
                    if(a[i]==Min)
                        c++;
                }
                if(c==0)
                {
                    System.out.print(Min+" ");
                    k++;
                }
            }
            
	    }
        sc.close();   
    }
}
