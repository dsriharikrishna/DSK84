/*
Find all possible sub-Sequence. 
input:{1,2,3} 	
output:{1},{2},{3},{1,2},{1,3},{2,3},{1,2,3}
*/

import java.util.*;
class A 
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int a[] = new int[n];

		for(int i=0;i<n;i++)
			a[i] = sc.nextInt();

		int k = (int)Math.pow(2,n);
		
		for(int i=1;i<k;i++)
		{
			String bin = binary(i);
			int ind = 0;
			for(int j=bin.length()-1;j>=0;j--)
			{
				if(bin.charAt(j)=='1')
					System.out.print(a[ind]+" ");
				ind++;
			}
		}
		sc.close();
	}
	public static String binary(int n)
	{
		String bin ="";
		while(n>0)
		{
			bin = n%2+bin;
			n=n/2;
		}
		return bin;
	}
}
