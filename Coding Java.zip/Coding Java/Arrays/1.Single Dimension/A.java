import java.util.*;
class A
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int a[] = {10,20,30,40,50};
		
		for(int i=0;i<a.length;i++)
			System.out.print(a[i]+" ");
			
		sc.close();
	}
}