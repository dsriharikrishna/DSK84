/*
51.Write a program to print the Count of Duplicates in the Given Array?

 Input  1 :     9

                1 2 1 4 1 2 3 5 6

Output 1 :      2

Explanation :

Here 1 is Repeated for 3 times, 2 is Repeated for 2 and Remaining all are only Once So here we 2 Numbers are Repeated More Than 1 Time, So we Have to print Output as 2.

*/

import java.util.*;
class A
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int c=0,d=0;
        
        if(n<=5)
            System.out.print("Invalid Array Size.");
        else
        {
            int a[] = new int[n];
            for(int i=0;i<n;i++)
            {
                a[i] = sc.nextInt();
            }
            for(int i=0;i<n;i++)
            {
                int k=0;
                for(int j=0;j<i;j++)
                {
                    if(a[i]==a[j])
                        k++;
                }
                if(k==0)
                {
                    c=0;
                    for(int j=0;j<n;j++)
                    {
                        if(a[i]==a[j])
                            c++;
                    }
                    if(c!=1)
                        d++;
                }
            }
            if(d==0)
                     System.out.print("No Duplicates exists");
            else
                System.out.print(d);
        }
        sc.close();
    }
}