/*
46.Write a program to print the Least Unique Numbers In A given Array?

 ip - 9
      6 2 1 4 3 2 3 5 1
 Op - 4

 */
 import  java.util.*;
 class A {
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        
        if(n<=0)
        {
            System.out.print("Invalid Array Size.");
            System.exit(0);
        }
        int d=0,m =0,c=0;
        int a[] = new  int[n];
        for(int i=0;i<n;i++)
        {
            a[i] = sc.nextInt();
        }
        for(int i=0;i<n;i++)
        {
            c=0;
            for(int j=0;j<n;j++)
            {
                if(a[i]==a[j])
                    c++;
            }
            if(c==1)
            {
                if(a[i]>m)
                {
                    m = a[i];
                    d++;
                }
            }
        }
        if(d==0)  
            System.out.println("No Unique Elements");
        else
            System.out.println(m);
        
    sc.close();
    }
 }