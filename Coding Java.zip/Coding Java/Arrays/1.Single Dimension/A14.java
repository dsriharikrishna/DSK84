//Write a program to find and print the 'N'th Largest Element from a Given Array?
import java.util.*;
class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        if(n<=0)
        {
            System.out.print("Invalid Array Size");
            System.exit(0);
        }
        int a[] = new int[n];
        for(int i=0;i<n;i++)
        {
            a[i] = sc.nextInt();
        }
        int N = sc.nextInt();
        if(N<=0 || N>n)
        {
            System.out.print("Invalid Nth Value");
            System.exit(0);
        }
        
        /*for(int i=0;i<n;i++)
        {
            for(int j=0;j<n-1;j++)
            {
                int t = a[j];
                a[j] = a[j+1];
                a[j+1] = t;
            }
        }
        System.out.println(a[n-N]);
        */

        int max = Integer.MAX_VALUE;
        int m1=0;

        for(int i=0;i<n;i++)
        {
            for(int j=0;j<N;j++)
            {
                if(a[i] > m1 && max > a[i])
                    m1 = a[i];
            }
            max = a[i];
        }
        System.out.print(max);
        sc.close();
    }
}