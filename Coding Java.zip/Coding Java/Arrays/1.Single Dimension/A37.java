// Quick sort in Java

import java.util.Arrays;

class Quicksort {

  static int partition(int array[], int low, int high) {
    
    int pivot = array[high];
   
    int i = (low - 1);

    for (int j = low; j < high; j++) {
      if (array[j] <= pivot) {
        i++;
        int temp = array[i];
        array[i] = array[j];
        array[j] = temp;
      }

    }

    int temp = array[i + 1];
    array[i + 1] = array[high];
    array[high] = temp;

    return (i + 1);
  }

  static void quickSort(int array[], int low, int high) {
    if (low < high) {

      int pi = partition(array, low, high);
      quickSort(array, low, pi - 1);
      quickSort(array, pi + 1, high);
    }
  }
}

class Main {
  public static void main(String args[]) {

    int[] data = { 8, 7, 2, 1, 0, 9, 6 };
    System.out.println("Unsorted Array");
    System.out.println(Arrays.toString(data));

    int size = data.length;

    // call quicksort() on array data
    Quicksort.quickSort(data, 0, size - 1);

    System.out.println("Sorted Array in Ascending Order: ");
    System.out.println(Arrays.toString(data));
  }
}

// import java.util.*;

// class Solution {
//     public int[] sortArray(int[] nums) {
//         quicksort(nums, 0, nums.length - 1);
//         return nums;
//     }

//     public void quicksort(int[] a, int s, int e) {
//         if (s < e) {
//             int pivot = partition(a, s, e);
//             quicksort(a, s, pivot - 1);
//             quicksort(a, pivot + 1, e);
//         }
//     }

//     public int partition(int a[], int s, int e) {
//         int pivot = e;
//         int i = s - 1;
//         for (int j = s; j < e; j++) {
//             if (a[j] <= a[pivot]) {
//                 i++;
//                 int t = a[i];
//                 a[i] = a[j];
//                 a[j] = t;
//             }
//         }
//         int t = a[i + 1];
//         a[i + 1] = a[e];
//         a[e] = t;
//         return i + 1;
//     }
// }
