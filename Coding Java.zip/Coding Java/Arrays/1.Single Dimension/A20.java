import java.util.*;
class A
{
    public static void main(String []args)
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        
        if(n<=0)
        {
            System.out.print("Invalid Array Size.");
            System.exit(0);
        }
        String a[] = new String[n];
        for(int i=0;i<n;i++)
            a[i] = sc.next();
        for(int i=n;i>=0;i--)
            System.out.print(a[i]+" ");
        sc.close();
   }
}