/* 
Input: 84, 
Output: {1, 0, 1, 0, 1, 0, 0 }. 
Decimal to Binary conversion.

*/

import java.util.*;
class A
{
    public static void main(String[]args)
    {
       Scanner sc = new Scanner(System.in);
       int n = sc.nextInt();
       int x=n,c=0;
      
		while(x>0)
		{
			c++;
			x/=2;
		}
		x=n;
		int a[] = new int[c];
		for(int i=c-1;i>=0;i--)
		{
			a[i] = x%2;
			x/=2;
		} 
		System.out.print("a = ");
		System.out.println(Arrays.toString(a));
		sc.close();
   }
}