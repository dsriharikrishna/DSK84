/*
	6.	Print common elements from two arrays.
*/
import java.util.*;
class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();

        if(n<=0)
            System.out.print("Invalid Array Size.");
        else
        {
            int a[] = new int[n];
            for(int i=0;i<n;i++)
            {
                a[i] = sc.nextInt();
            }
            int b[] = new int[n];
            for(int j=0;j<n;j++)
            {
                b[j] = sc.nextInt();
            }
            for(int i=0;i<n;i++)
            {
                for(int j=0;j<n;j++)
                {
                    if(b[j]==a[i])
                    {
                       System.out.print(a[i]+" "); 
                    }
                }
            } 
        }
        sc.close();
    }
}