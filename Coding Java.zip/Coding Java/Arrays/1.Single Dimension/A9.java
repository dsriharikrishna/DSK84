// Write a program to find the sum of the Same Position Values in a Given Two Arrays.
import java.util.*;
class A
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();

        if(n<=0)
            System.out.print("Invalid Array Size");
        else
        {
            int a[] = new int[n];
            for(int i=0;i<n;i++)
            {
                a[i] = sc.nextInt();
            }
            int m = sc.nextInt();
            if(m<=0)
            {
                System.out.print("Invalid array size");
            }
            else
            {
                int b[] = new int[m];
                for(int i=0;i<m;i++)
                {
                    b[i] = sc.nextInt();
                }
                int c=n,d=m;
                if(c<d)
                {
                    d=c;
                    c=m;
                }
                for(int i=0;i<d;i++)
                {
                    System.out.print(a[i]+b[i]+" ");
                }
                for(int i=d;i<c;i++)
                {
                    if(m<n)
                        System.out.print(a[i]+" ");
                    else
                        System.out.print(b[i]+" ");
                }
            }
        }
        
        sc.close();
    }
}