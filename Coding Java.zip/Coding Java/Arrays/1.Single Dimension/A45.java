/*
45.Write a Program to find and print the LCM of all Odd Numbers in Given Array?

ip - 6
     3 6 9 18 81 90
op - 81

*/

import java.util.*;
class Main
{
    public static void main(String []args)
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        
        if(n<=0)
        {
            System.out.print("Invalid Array Size.");
            System.exit(0);
        }
        int d=0;
        int max = Integer.MIN_VALUE;

        int a[] = new  int[n];
        for(int i=0;i<n;i++)
        {
            a[i] = sc.nextInt();
            if(a[i]%2==1)
            {
                d++;
                if(a[i]>max)
                    max = a[i];
            }
        }
        if(d==0)
        {
                System.out.print("No Odd Numbers");
                System.exit(143);
        }
        for(int i=max;i>=0;i+=max)
        {
            int c=0;
            for(int j=0;j<n;j++)
            {
                if(a[j]%2==1)
                {
                    if(i%a[j]==0)
                        c++;
                }
            }
            if(c==d)
            {
                System.out.print(i);
                break;
            }
        }
        sc.close();
    }
}