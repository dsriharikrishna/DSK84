// print the Odd Numbers in array 
import java.util.*;
class A 
{
	public static void main(String args[])
	{
		Scanner sc =  new Scanner(System.in);
		int n =  sc.nextInt();
		int c=0,sum=0;

		if(n>=5)
		{
			int a[] = new int[n];
			for(int i=0;i<n;i++)
			{
			
				a[i] = sc.nextInt();
			}
			for(int i=0;i<n;i++)
			{
				if(a[i]%2==1)
				{
					c++;
					sum+=a[i];
				}
			}
			if(c==0)		
				System.out.print("No Odd Numbers ");
			else
				System.out.print(sum);
		}
		else
			System.out.print("Invalid array Size ");
		sc.close();
	}
}
	
			