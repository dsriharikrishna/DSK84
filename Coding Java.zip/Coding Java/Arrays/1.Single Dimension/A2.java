// print alternative even the array taking dynamic inputs 
import java.util.*;
class A
{
    public  static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int c = 0;
        if(n>1 && n<10)
        {
            int a[] = new int[n];
            for(int i=0;i<a.length;i++)
            {
                a[i] = sc.nextInt();
            }
            for(int i=0;i<a.length;i++)
            {
                if(a[i]%2==0)
                {
                    c++;
                    if(c%2==1)
                       System.out.print(a[i]+" ");
                }
            }
            if(c==0)
                 System.out.println("NO EVEN NUMBERS");
        }
        else
            System.out.println("INVALID ARRAY SIZE");

        sc.close();
    }
}
