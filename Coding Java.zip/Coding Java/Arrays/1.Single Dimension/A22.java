/*
	Input: {3,4,2,1,3,5}, 
    Output: {3^1, 4^2,2^3,1^4,3^5,5^6}={3,16,8,1,243,15625}
*/
import java.util.*;
class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int p=0;

        if(n<=0)
            System.out.print("Invalid Array Size.");
        else
        {
            int a[] = new int[n];
            for(int i=0;i<n;i++)
                a[i] = sc.nextInt();
            for(int i=0;i<n;i++)
            {
                p++;
                System.out.print((int)Math.pow(a[i],p)+" ");
            }
        }
        sc.close();
    }
}