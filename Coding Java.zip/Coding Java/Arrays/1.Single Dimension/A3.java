// print average of the array taking dynamic inputs 
import java.util.*;
class A
{
    public static void main(String args[])
    {
        Scanner sc =  new Scanner(System.in);
        int n = sc.nextInt();
        int c=0,sum=0;

        if(n<=0)
                System.out.print("Invalid Array Size");
        else 
        {
            int a[] = new int[n];
            for(int i=0;i<n;i++)
                a[i] = sc.nextInt();
            
            for(int i=0;i<n;i++)
            {
                sum += a[i];
                c++;
            }
            System.out.print("Average Of Given Array ELements Is ");
            System.out.printf("%.1f",(float)sum/c+" .");

        }
        sc.close();
    }
}