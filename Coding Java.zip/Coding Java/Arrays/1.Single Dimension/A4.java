//Write a Program to Find the sum of first and last element in a Given Array
import java.util.*;
class A 
{
    public static void main(String args[])
    {
        Scanner sc  =  new Scanner(System.in);
        int n = sc.nextInt();

        if(n>1 && n<10)
        {
            int a[] = new int[n];
            for(int i=0;i<n;i++)
            {
                a[i] = sc.nextInt();
            }
            System.out.print(a[0] +" + "+a[n-1]+ " = " +(a[0]+a[n-1]));
            sc.close();
        } 
    }
}