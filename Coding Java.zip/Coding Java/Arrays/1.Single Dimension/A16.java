/*
1.Print all circular arrays. 
Ex: input:{1,2,3}, output:{1,2,3},{2,3,1},{3,1,2}
Ex: inpu:{4,2,9,1}, output:{4,2,9,1},{2,9,1,4},{9,1,4,2},{1,4,2,9}
*/
import java.util.*;
class A
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int a[] = new int[n];

		for(int i=0;i<n;i++)
		    a[i] = sc.nextInt();
	
		for(int i=0;i<n;i++)
		{	
			for(int j=i;j<n;j++)
				System.out.print(a[j]+" ");
			for(int j=0;j<i;j++)
				System.out.print(a[j]+" ");
		}
		System.out.println(Arrays.toString(a));
		sc.close();

    }
}
