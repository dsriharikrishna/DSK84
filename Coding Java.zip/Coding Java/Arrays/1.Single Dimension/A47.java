/*
47.Write a program to find and print the frequency of the Given Array Elements.

Input  2 :  5

            1 2 3 4 5

Output 2 :

        1 -> 1

        2 -> 1

        3 -> 1

        4 -> 1

        5 -> 1

*/
import java.util.*;
class Main
{
    public static void main(String[]args)
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        
        if(n<=0)
        {
            System.out.print("Invalid Array Size.");
            System.exit(0);
        }
        
        int a[] = new int[n];
        for(int i=0;i<n;i++)
        {
            a[i] = sc.nextInt();
        }
        for(int i=0;i<n;i++)
        {
            int c=0;
            for(int j=0;j<n;j++)
            {
                if(a[i] == a[j])
                    c++;
            }
            System.out.println(a[i]+" -> "+c);
        }
        sc.close();
    }
}