// print the sum of the prime Numbers in array 
import java.util.*;
class A 
{
	public static void main(String args[])
	{
		Scanner sc =  new Scanner(System.in);
		int n =  sc.nextInt();
		int c=0,sum=0,d=0,fc=0;
		
		if(n>3)
		{
			int a[] = new int[n];
			for(int i=0;i<n;i++)
			{
				a[i] = sc.nextInt();
			}
			for(int i=0;i<n;i++)
			{
				if(a[i]<=1)
					d++;
				else
				{
					fc=0;
					for(int j=1;j<=a[i];j++)
					{
						if(a[i]%j==0)
							fc++;
					}
					if(fc==2)
					{
						c++;
						sum+=a[i];
					}
				}
			}
			if(d!=0)
				System.out.print("Invalid Array Elements");
			else
			{
				if(c>0)
		    	{
		    		System.out.print("Average of Prime Numbers in a Given Array Elements is ");
        	   		 System.out.printf("%.3f.",(float)sum/c);
				}
        		else
        	   		 System.out.println("No Prime Numbers!");
			}
		 }
		 else
		    System.out.print("Invalid Array Size.");
		sc.close();
	}
}


			
	
		