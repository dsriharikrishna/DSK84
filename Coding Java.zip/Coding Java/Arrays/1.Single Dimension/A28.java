//Write a Program to find out the bubble sorting value of a Given Array?

import java.util.*;
class A
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		
		if(n<=0)
			System.out.print("Invalid ArraySize");
		else
		{
			int a[] = new int[n];
			for(int i=0;i<n;i++)
			{
				a[i] = sc.nextInt();
			}
			for(int i=0;i<n;i++)
			{
				for(int j=0;j<n-i-1;j++)
				{
					if(a[j]>a[j+1])
					{
					   int t = a[j];
					   a[j] = a[j+1];
					   a[j+1] = t;
					}
				}
			}
			//System.out.println(Arrays.toString(a));
			for(int j=0;j<n;j++)
				System.out.print(a[j]+" ");
		}
		sc.close();
	}
}