//Write a Program to find the frequency and print the count and Element from Given Array?

import java.util.*;
class A
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        if(n<=0)
            System.out.print("Invalid Array Size");
        else
        {
            int a[] = new int[n];
            for(int i=0;i<n;i++)
                a[i] = sc.nextInt();
                
            for(int i=0;i<n;i++)
            {
                int c=0;
                for(int j=0;j<n;j++)
                    if(a[i]==a[j])
                        c++;
                System.out.println(a[i]+" -> "+c);
            }
        }
        sc.close();
    }
}