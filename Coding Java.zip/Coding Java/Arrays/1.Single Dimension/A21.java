/*
Reverse the given array and print. (Not just print, reverse array elements)
Ex:- input:-{ 11 34 67}
     Output:- { 76 43 11}

*/
import java.util.*;
class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        
        if(n<=0)
            System.out.print("Invalid Array Size.");
        else
        {
            int a[] = new int[n];
            for(int i=0;i<n;i++)
                a[i] = sc.nextInt();
            
            for(int i=n-1;i>=0;i--)
            {
		        int rev = 0;
                int t = a[i];
                while(t>0)
                {
                    int r = t%10;
                    rev = rev*10+r;
                    t= t/10; 
		        }
                System.out.print(rev+" ");
	        }
	  
          sc.close();
        }
    }
}