//Write a Program for Insertion Sort of a Given Array elements.

import java.util.*;
class A 
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();

		int a[] = new int[n];

		for(int i=0;i<n;i++)
		{
			a[i]=sc.nextInt();
		}
		for(int i=0;i<n;i++)
		{
			int k = a[i],j=0;
			for(j=i-1;j>=0;j--)
			{
				if(a[j]>k)
					a[j+1]=a[j];
				else 
					break;
			}
			a[j+1]  = k;
		}
		System.out.println(Arrays.toString(a));
		sc.close();
	}
}