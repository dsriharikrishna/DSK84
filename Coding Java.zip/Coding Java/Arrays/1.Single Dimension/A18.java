/*
1.	Ask user for input n, Search n in the array. 
If found print Found else print Not-Found. 
Using Linear Search Algorithms.

*/
import java.util.*;
class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int c=0;
        
        if(n<=0)
            System.out.print("Invalid Array Size.");
        else
        {
            int a[] = new int[n];
            for(int i=0;i<n;i++)
            {
                a[i] = sc.nextInt();
            }
            int k =sc.nextInt();
            for(int i=0;i<n;i++)
            {
                if(a[i]==k)
                    c++;
            }
            if(c==0)
                System.out.print("Element Not Found");
            else
                System.out.print("Found");
        }
        sc.close();

    }
}