/*
49.Write a program to print the Most Repeated Number in a Given Array?

Input  1 :  9

            1 2 1 4 1 2 3 5 6

Output 1 :  1

Explanation :

Here 1 is repeated for 3 Times remaining all are repeated less than 3 times so we have to print output as 1.

*/

// import java.util.*;
// class A
// {
//     public static void main(String args[])
//     {
//         Scanner sc = new Scanner(System.in);
//         int n = sc.nextInt();
//         int c=0,x=0;
        
//         if(n<=6)
//             System.out.print("Invalid Array Size");
//         else
//         {
//             int a[] = new int[n];
//             for(int i=0;i<n;i++)
//             {
//                 a[i] = sc.nextInt();
//             }
//             int m = 0;
//             for(int i=0;i<n;i++)
//             {
//                 c=0;
//                 for(int j=0;j<n;j++)
//                 {
//                     if(a[i]==a[j])
//                     {
//                         c++;
//                     }
//                 }
//                 if(c!=1)
//                 {
//                    if(m<c)
//                    {
//                      m=c;
//                      x=a[i];
//                    }
//                 }
//             }
//             if(m==0)
//                 System.out.print("NO such number exists");
//             else 
//                 System.out.println(x);
//         }
//     }
// }

    
// in Method version 

import java.util.*;

class A {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int a[] = new int[n];
        for (int i = 0; i < n; i++)
            a[i] = sc.nextInt();

        if (n <= 6) {
            System.out.print("Invalid Array Size");
            System.exit(0);
        }
        MostRepeatedArrayNo(a);
        sc.close();
    }
    public static void MostRepeatedArrayNo(int a[]) {
        int mrc = 0, mrv = 0;
        for (int i = 0; i < a.length; i++) {
            int c = 0;
            for (int j = 0; j < a.length; j++) {
                if (a[i] == a[j])
                    c++;
            }
            if (mrc < c) {
                mrc = c;
                mrv = a[i];
            }
        }
        System.out.println(mrv + " " + mrc);
    }
}
