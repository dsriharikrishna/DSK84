// print Swapping Elements Before and After the given array 
import java.util.*;
class Main
{
	public static void main(String[] args)
	{
		 Scanner sc = new Scanner(System.in);
		 int n = sc.nextInt();
		 
		 if(n>0)
		 {
    		int a[] = new int[n];
			for(int i=0;i<a.length;i++)
				a[i] = sc.nextInt();
			
			System.out.print("Before Swapping Elements : ");
			for(int i=0;i<a.length;i++)
					System.out.println(a[i]+" ");

			System.out.println();
			System.out.print("After Swapping Elements : ");

		   	for(int i=n;i>=0;i--)
    		    System.out.println(a[i]+" ");
		 }
		 else
		    System.out.print("Invalid Array Size.");
		
        sc.close();
	}
}