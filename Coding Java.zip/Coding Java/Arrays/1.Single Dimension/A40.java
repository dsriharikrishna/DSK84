import java.util.*;

class A {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] array1 = new int[n];
        int[] array2 = new int[n];

        for(int i=0;i<n;i++)
            array1[i] = sc.nextInt();
        for(int i=0;i<n;i++)
            array2[i] = sc.nextInt();

        int length = array1.length + array2.length;

        int[] result = new int[length];
        int pos = 0;
        for (int element : array1) {
            result[pos] = element;
            pos++;
        }

        for (int element : array2) {
            result[pos] = element;
            pos++;
        }
        System.out.println(Arrays.toString(result));

    sc.close();
    }
}
