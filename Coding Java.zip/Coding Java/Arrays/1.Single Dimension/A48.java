/*
48.Write a Program to find and print the HCF / GCD of Given Array Elements?

Input  1 :   4

            12 40 16 64

Output 1 :  4

Explanation :

HCF Means Highest Common Factor

GCD Means Greatest Common Divisor

Factors of 12 - 1, 2, 3, 4, 6, 12

Factors of 40 - 1, 2, 4, 5, 8, 10, 20, 40

Factors of 16 - 1, 2, 4, 8, 16

Factors of 64 - 1, 2, 4, 8,16, 32, 64

Here 1, 2, 4 are the Common Factors of Given 12, 40, 16, 64. But We Have to Print Highest in it. So Here We Have to Print 4.
*/

import java.util.*;
class Main
{
    public static void main(String []args)
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        
        if(n<=0 || n>10)
        {
            System.out.print("Invalid Array Size.");
            System.exit(0);
        }
        
        int a[] = new  int[n];
        for(int i=0;i<n;i++)
        {
            a[i] = sc.nextInt();
        }
        int Min = Integer.MAX_VALUE;
        for(int i=0;i<n;i++)
        {
            if(a[i]<Min)
                Min = a[i];
        }
        for(int i=Min;i>0;i--)
        {
            int c=0;
            for(int j=0;j<n;j++)
            {
                if(a[j]%i==0)
                    c++;
            }
            if(c==n)
            {
                 System.out.print(i);
                 break;
            }
        }
        sc.close();
    }
}

 