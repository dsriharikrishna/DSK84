/*
Write a Program to find out the MEAN value of a Given Array?

*/

import java.util.*;
class A
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int Median=0;
		
		if(n<=0)
			System.out.print("Invalid ArraySize");
		else
		{
			int a[] = new int[n];
			for(int i=0;i<n;i++)
			{
				a[i] = sc.nextInt();
			}
			for(int i=0;i<n;i++)
			{
				Median = (a[0]+a[n-1])/2;
			}
			System.out.print(Median);
		}
		sc.close();
	}
}
			