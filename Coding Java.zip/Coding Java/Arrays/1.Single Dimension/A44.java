/* 44.Write a program to find and print the LCM of given Array elements?

ip - 4 
     1 2 8 3 
op - 24

*/

import java.util.*;
class A
{
    public static void main(String []args)
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        
        if(n<=0 || n>10)
        {
            System.out.print("Invalid Array Size.");
            System.exit(0);
        }
        
        int a[] = new  int[n];
        
        for(int i=0;i<n;i++)
        {
            a[i] = sc.nextInt();
        }
        int max = a[0];
        for(int i=1;i<n;i++)
        {
            if(a[i]>max)
                max = a[i];
        }
        for(int i=max;i>=0;i+=max)
        {
            int c=0;
            for(int j=0;j<n;j++)
            {
                if(i%a[j]==0)
                 c++;
            }
            if(c==n)
            {
                System.out.print(i);
                break;
            }
        }
        sc.close();
    }
}