/*
 *          Example:
            
            Input : 7 3

             T  s  i

             h  %  x

             i  !  #

             s  M  >

             $  a  .

             #  t  %    

             i  r  !

            Output : This is Matrix#>.%!
 */
import java.util.*;

class A {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int rows = sc.nextInt();
        int cols = sc.nextInt();

        char[][] matrix = new char[rows][cols];

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                matrix[i][j] = sc.next().charAt(0);
            }
        }

        StringBuilder output = new StringBuilder();
        
        for (int j = 0; j < cols; j++) {
            for (int i = 0; i < rows; i++) {
                output.append(matrix[i][j]);
            }
        }
        System.out.println(output);

    sc.close();
    }
}


/*
 * 
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int rows = scanner.nextInt();
        int cols = scanner.nextInt();

        char[][] matrix = new char[rows][cols];

        // Input the characters into the matrix
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                matrix[i][j] = scanner.next().charAt(0);
            }
        }

        // Output the characters without separation
        StringBuilder output = new StringBuilder();
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                output.append(matrix[i][j]);
            }
        }

        System.out.println(output.toString());
    }
}

 */