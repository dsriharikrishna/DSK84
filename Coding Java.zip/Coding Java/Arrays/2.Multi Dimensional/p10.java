//10.element found in 2d array 

import java.util.*;

class A {
    public static boolean sm(int a[][], int target) {
        int i = 0, j = a[0].length - 1;
        
        while (i < a.length && j >= 0) {
            if (a[i][j] == target)
                return true;
            else if (target < a[i][j])
                j--;
            else
                i++;
        }
        return false;
    }

    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int r = sc.nextInt();
        int c = sc.nextInt();

        int ar[][] = new int[r][c];
        for (int i = 0; i < ar.length; i++) {
            for (int j = 0; j < ar[i].length; j++)
                ar[i][j] = sc.nextInt();
        }

        int target = sc.nextInt();

        boolean result = sm(ar, target); 
        System.out.println(result); 

    sc.close();
    }
}
