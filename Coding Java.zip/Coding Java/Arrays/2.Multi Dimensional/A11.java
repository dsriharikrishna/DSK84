//11.	Find the Given 2D array is  Equal Row Matrix or Equal Column Matrix?
//Ex1: Input: {{2,2,2},{5,5,5},{6,6,6}} Output: Equal Row Matrix                             
//Ex2: input: {{1,2,3, {1,2,3},{1,2,3}} output: Equal Column Matrix

import java.util.Scanner;
class A {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int r=sc.nextInt();
		int c=sc.nextInt();
		int a[][]=new int[r][c];

		int d=0;
		int e=0;

		for(int i =0;i<r;i++) {
			for(int j=0;j<c;j++) {
				a[i][j]=sc.nextInt();
			}
		}

		for(int i =0;i<r;i++) {
			for(int j=0;j<c;j++) {
				if(a[i][0]==a[i][j]) {
					d++;
				}
				if(a[0][j]==a[i][j]) {
					e++;
				}
			}
		}
		if(d==(r*c)) 
			System.out.println("Given matrix is Equal Row matrix. ");
		
		if(e==(r*c))
			System.out.print("Given matrix is Equal Column matrix. ");
		
		sc.close();
	}

}
