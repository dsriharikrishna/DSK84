//8.  Input: {{1,2,3},{3,5,4},{4,5,6}} output:{{4,5,6},{3,5,4},{1,2,3}} 

import java.util.*;
class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        int r = sc.nextInt();
        int c = sc.nextInt();

        int a[][] = new int[r][c];

        for(int i=0;i<r;i++)
        {
            for(int j=0;j<c;j++)
                a[i][j] = sc.nextInt();
        }
        System.out.println("Before : ");
        for(int i=0;i<r;i++)
        {
            for(int j=0;j<c;j++)
            {
                System.out.print(a[i][j]+" ");
            }
            System.out.println();
        }
        System.out.println("After : ");
        for(int i=r-1;i>=0;i--)
        {
            for(int j=0;j<c;j++)
            {
                System.out.print(a[i][j]+" ");
            }
            System.out.println();
        }

        sc.close(); 
    }    
}
