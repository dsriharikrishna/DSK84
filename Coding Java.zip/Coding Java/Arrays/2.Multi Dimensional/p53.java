// 11.	Find the Given 2D array is  Equal Row Matrix or Equal Column Matrix?
// Ex1: Input: {{2,2,2},{5,5,5},{6,6,6}} Output: Equal Row Matrix  
// Ex2: input: {{1,2,3},{1,2,3},{1,2,3}} output: Equal Column Matrix

import java.util.*;
class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        int r  = sc.nextInt();
        int n = sc.nextInt();

        int a[][] = new int[r][n];

        for(int i=0;i<r;i++)
            for(int j=0;j<n;j++)
                a[i][j] = sc.nextInt();

        int c=0,k=0;
        for(int i=0;i<r;i++)
        {
            int h = a[i][0];
            int t = a[0][i];
            for(int j=0;j<n;j++)
            {
                if(h == a[i][j])
                    c++;
                if(t == a[j][i])
                    k++;
            }
        }
        if(c==r*r)
            System.out.print("Equal Row Matrix");
        else if(k==n*n)
            System.out.print("Equal Column Matrix");
        else
            System.out.print("Invalid .....");
        
        sc.close();
    }
}