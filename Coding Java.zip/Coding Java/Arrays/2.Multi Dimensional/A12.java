// 12.Write a Program to Print the sorted 2D array?

import java.util.*;
class A 
{
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        int r = sc.nextInt();
        int c = sc.nextInt();
        
        int a[][] = new int[r][c];

        for(int i=0;i<r;i++)
        {
            for(int j=0;j<c;j++)
                a[i][j] = sc.nextInt();
        }
       int m = a[0].length;
        for (int i = 0; i < a.length; i++) 
        {
            for (int j = 0; j < m; j++) 
            {
                for (int k = 0; k < m - j - 1; k++) {
                    if (a[i][k] > a[i][k + 1]) 
                    {
                        int temp = a[i][k];
                        a[i][k] = a[i][k + 1];
                        a[i][k + 1] = temp;
                    }
                }
            }
            m++;
        }
        System.out.println();
        for(int i=0;i<r;i++)
        {
            for(int j=0;j<a[0].length;j++)
            {
                System.out.print(a[i][j]+" ");
            }
            System.out.println();
        }
        sc.close();
    }
}

/*
 * //12.	Write a Program to Print the sorted 2D array?
import java.util.*;
class Main
{
    public static void main (String[] args) 
    {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int ar[][]=new int[n][n];
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<n;j++)
            {
                ar[i][j]=sc.nextInt();
            }
        }
        for(int i=1;i<=n;i++)
        {
            for(int j=0;j<n;j++)
            {
                for(int k=0;k<n-1;k++)
                {
                    if(ar[j][k]>ar[j][k+1])
                    {
                        int t=ar[j][k];
                        ar[j][k]=ar[j][k+1];
                        ar[j][k+1]=t;
                    }
                }
            }
        }
        for(int h[]:ar)
        {
            for(int c:h)
            {
                System.out.print(c+" ");
            }
            System.out.println();
        }
    }
}
 */
