//10. Input: {{7,0,0},{0,7,0},{0,0,7}} output: 7-Identity matrix 

import java.util.*;
class A {
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        int r = sc.nextInt();
        int c = sc.nextInt();
        
        int a[][] = new int[r][c];

        for(int i=0;i<a.length;i++)
        {
            for(int j=0;j<a.length;j++)
            {
                a[i][j] = sc.nextInt();
            }
        }

        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if(i==j){
                    if(a[i][j]!=0){
                        System.out.print("Not I m");
                        System.exit(0);
                    }
                }
                else{
                    if(a[i][j]!=0){
                        System.out.print("Not I m");
                        System.exit(0);
                    }		
                }
            }
        }
        System.out.println("I M");

        sc.close();
    }
}