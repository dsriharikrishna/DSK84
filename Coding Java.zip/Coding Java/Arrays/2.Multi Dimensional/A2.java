//2.  Search for a number in 2D array

import java.util.*;
class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        int r = sc.nextInt();
        int c = sc.nextInt();

        int a[][] = new int[r][c];

        for(int i=0;i<r;i++)
        {
            for(int j=0;j<c;j++)
                a[i][j] = sc.nextInt();
        }
        int n = sc.nextInt();

        for(int i=0;i<r;i++)
        {
            for(int j=0;j<c;j++)
            {
                if(n==a[i][j])
                    System.out.print("Element Found : "+n);
            }
            System.out.println();
        }
        sc.close();
    }
}