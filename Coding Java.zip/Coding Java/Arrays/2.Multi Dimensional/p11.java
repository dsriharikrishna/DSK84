// 11.rotate 90 degree of matrix 

import java.util.*;

class A {
    public static void rotate(int ar[][]) {
        int n = ar.length;
        // Transpose the matrix
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                int temp = ar[i][j];
                ar[i][j] = ar[j][i];
                ar[j][i] = temp;
            }
        }

        // Reverse each row
        for (int i = 0; i < n; i++) {
            int l = 0, r = n - 1;
            while (l < r) {
                int temp = ar[i][l];
                ar[i][l] = ar[i][r];
                ar[i][r] = temp;
                l++;
                r--;
            }
        }
    }

    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int r = sc.nextInt();
        int c = sc.nextInt();

        int ar[][] = new int[r][c];
        
        rotate(ar);
        System.out.println(Arrays.deepToString(ar));

    sc.close();
    }
}
