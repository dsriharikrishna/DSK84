/*
16.Input            : First Line of The Input Consists of One Integer Value Which Represents No of Matches

                       Second Line of the Input Consists of One Integer Value Which Represents No of Players 

                       And Next Line Consists of Match -1 Scores of All Players and in Next Line Consists of Match -2 Scores of All Players and so on for All R No of Matches 

Output         : Print the Highest Scorer Name And Score In Each and Every Match Separately after that Print the Highest Individual Scorer in All Matches.

Constraints  : NA


Example:
Input 1 :           3

                    3

                    3 5 6

                    7 8 9

                    12 15 12

Outupt 1 :          Player3 - 6

                    Plaer3 - 9 

                    Player2 - 15

                    Player2 - 28

                    */
import java.util.*;

class A 
{
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int r = sc.nextInt();
        int c = sc.nextInt();

        int a[][] = new int[r][c];

        for (int i = 0; i < a.length; i++) 
        {
            for (int j = 0; j < a[i].length; j++)
                a[i][j] = sc.nextInt();
        }

        int a1=0,b1=0,s=0,s1=0,s2=0;
        for(int i=0;i<r;i++)
        {
            for(int j=0;j<c;j++)
            {
                a1 = a[i][j];
                for(int k=0;k<c;k++)
                {
                    if(a1<a[i][k])
                    {
                        a1 = a[i][k];
                        s=k;
                    }
                }
            }
            s++;
            System.out.println("player"+s+" -  "+a1);
        }
        for(int i=0;i<c;i++)
        {
            s2=0;
            for(int j=0;j<r;j++)
            {
                s2 += a[j][i];
            }
            if(s1<s2)
            {
                s1=s2;
                b1=i;
            }
        }
        b1++;
        System.out.println("player"+b1+" -  "+s1);

    sc.close();
    }
} 
