//4.Write a Program to print the sum of the numbers in a 2D Array? 

import java.util.*;
class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        int r = sc.nextInt();
        int c = sc.nextInt();

        int a[][] = new int[r][c];

        for(int i=0;i<r;i++)
        {
            for(int j=0;j<c;j++)
                a[i][j] = sc.nextInt();
        }
        int sum=0;
        for(int i=0;i<r;i++)
        {
            for(int j=0;j<c;j++)
                sum+=a[i][j];
        }
        System.out.println(sum);
    sc.close();
    }
}