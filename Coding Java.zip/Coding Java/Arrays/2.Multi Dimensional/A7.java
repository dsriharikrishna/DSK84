//7.  Find the Sum of the both the Diagonals individually in a 2D array?

import java.util.*;
class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        int r = sc.nextInt();
        int c = sc.nextInt();

        int a[][] = new int[r][c];

        for(int i=0;i<r;i++)
        {
            for(int j=0;j<c;j++)
                a[i][j] =sc.nextInt();
        }
        int sum=0,sum1=0;
        for(int i=0;i<a.length;i++)
        {
            for(int j=0;j<a.length;j++)
            {
                if(j==i)
                    sum+=a[i][j];
            }   
        }
        for(int i=0;i<a.length;i++)
        {
            for(int j=0;j<a.length;j++)
            {
                if(j==c-i-1)
                    sum1+=a[i][j];
            }   
        }
        System.out.println(sum+" "+sum1);
        System.out.println(Arrays.deepToString(a));

        sc.close();
    }
}