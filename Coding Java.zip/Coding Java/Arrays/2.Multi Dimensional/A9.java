//9.	Write a program to check given matrix is identity matrix or not.
import java.util.*;
class A
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int r=sc.nextInt();
		int c=sc.nextInt();
		int a[][]=new int[r][c];
		
		for(int i=0;i<r;i++)
		{
			for(int j=0;j<c;j++)
			{
				a[i][j]=sc.nextInt();
			}
		}
		int cn=0;
		int d=0;
		for(int i=0;i<r;i++)
		{
        	for(int j=0;j<c;j++)
			{
				if((i==j && a[i][j]==a[0][0]) || (i!=j && a[i][j]==0)){
					cn++;
				}
				else{
					d++;
				}
			}
			System.out.println();
		}
		if(cn==r*c && d==0)
			System.out.print("Identity : ");
		else
			System.out.print("No Identity : "+cn);

		sc.close();
	}
}
/* 
import java.util.*;

class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int r = sc.nextInt();
        int c = sc.nextInt();
        
        int a[][] = new int[r][c];

        for (int i = 0; i < r; i++)
            for (int j = 0; j < c; j++)
                a[i][j] = sc.nextInt();

        int k=0,d=0;
        for (int i = 0; i < r; i++) 
        {
            for (int j = 0; j < c; j++) 
            {
                if((i==j && a[i][j]==0) || (i!=j && a[i][j]==0))
                {
                    k++;
                }
                else
                {
                    d++;
                }
            }
        }
        if(k==r*c && d==0)
            System.out.println("I Matrix:");
        else    
            System.out.println("I Not Matrix:");
              
        System.out.println("Resultant Matrix:");
        System.out.println(Arrays.deepToString(a));
    }
}

*/