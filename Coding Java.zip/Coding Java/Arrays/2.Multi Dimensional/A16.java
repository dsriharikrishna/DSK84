//16.	Input: {{1,2,3},{4,5,6},{5,6,7}} 
//    output: {{1,2,3,6},{4,5,6,15},{5,6,7,18}} (Last value sum of row values)

import java.util.*;
class A
{
    public static void main (String[] args)
    {
        Scanner sc=new Scanner(System.in);
        int r = sc.nextInt();
        int c = sc.nextInt();

        int a[][] = new int[r][c];

        for(int i=0;i<r;i++)
            for(int j=0;j<c;j++)
                a[i][j] = sc.nextInt();
        int k = c+1;
        int temp[][] = new int[r][k];
        int sum = 0;
        for(int i=0;i<r;i++)
        {
            sum=0;
            for(int j=0;j<k;j++)
            {
                if(j<c)
                {
                    temp[i][j] = a[i][j];
                    sum+=a[i][j];
                }
                else
                {
                    temp[i][j] = sum;
                }
            }
        }
        System.out.println(Arrays.deepToString(a));
        System.out.println(Arrays.deepToString(temp));

        sc.close();
    }
}

/*
 * import java.util.*;
class A
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int r=sc.nextInt();
		int c=sc.nextInt();
		int a[][]=new int[r][c];
		for(int i=0;i<r;i++)
		{
			for(int j=0;j<c;j++)
			{
				a[i][j]=sc.nextInt();
			}
		}
		for (int i=0;i<r;i++)
		{
			int sum=0;
			for (int j=0;j<c;j++)
			{
				sum=sum+a[i][j];
				System.out.print(a[i][j]+" ");
			}
			System.out.print(sum);
			System.out.println();
		}
		sc.close();
	}
}

 */
