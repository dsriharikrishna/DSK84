/*
Write a Program to replace the All Diagonal Elements with the Largest Number in Diagonal?
*/

import java.util.*;
class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        int r  = sc.nextInt();
        int c = sc.nextInt();

        int a[][] = new int[r][c];

        for(int i=0;i<r;i++)
            for(int j=0;j<c;j++)
                a[i][j] = sc.nextInt();
                
        int max = 0;
        for(int i=0;i<r;i++)
        {
            for(int j=0;j<c;j++)
            {
                if(a[i][i]>max)
                {
                    max = a[i][j];
                }
            }
        }
        for(int i=0;i<r;i++)
        {
            for(int j=0;j<c;j++)
            {
                a[i][i] = max;
            }
        }
        System.out.print(Arrays.deepToString(a));

    sc.close();
    }
}