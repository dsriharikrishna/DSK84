import java.util.Scanner;
class A
{
	public static void main(String[]args)
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		if(armstrong(n,0,n,0)==n)
			System.out.print("is a armstrong");
		else
			System.out.print("is not a armstrog");
	}
	public static int armstrong(int n,int c,int t,int arm)
	{
		if(n>0)
		{
			return armstrong(n/10,++c,t,arm);
		}
		if(t>0)
		{
			arm+=(int)Math.pow(t%10,c);
			return armstrong(n,c,t/10,arm);
		}
		return arm;
	}
}


