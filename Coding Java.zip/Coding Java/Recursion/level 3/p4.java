import java.util.Scanner;
class A
{
	public static void main(String[]args)
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		if(prime(n,1,0)==2)
			System.out.print("is a prime");
		else
			System.out.print("not a prime");
	}
	public static int prime(int a,int i,int fc)
	{
		if(i<=a)
		{
			if(a%i==0)
				fc++;
			return prime(a,++i,fc);
		}
		return fc;
	}
}

