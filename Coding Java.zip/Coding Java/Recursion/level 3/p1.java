
import java.util.Scanner;
class A
{
	public static void main(String[]args)
	{
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		num(a,b);
	}
	public static void num(int x,int y)
	{
		if(x<=y)
		{
			System.out.print(x+" ");
			x++;
			num(x,y);
		}
	}
}


