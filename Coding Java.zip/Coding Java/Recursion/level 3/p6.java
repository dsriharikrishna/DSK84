import java.util.Scanner;
class A
{
	public static void main(String[]args)
	{
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		table(a,b,1);
	}
	public static void table(int a,int b,int c)
	{
		if(c<=b)
		{
			int mul=c*a;
			System.out.println(c+" * "+a+" = "+mul);
			c++;
			table(a,b,c);
		}
	}
}


