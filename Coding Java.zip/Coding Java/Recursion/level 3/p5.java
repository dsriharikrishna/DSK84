import java.util.Scanner;
class A
{
	public static void main(String[]args)
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		fibonaaci(0,1,n,0);
	}
	public static void fibonaaci(int a,int b,int n,int c)
	{
		if(c<=n)
		{
			if(c!=0)
			System.out.print(", ");
			System.out.print(a);
			int d=a+b;
			a=b;
			b=d;
			fibonaaci(a,b,n,++c);
		}
	}
}