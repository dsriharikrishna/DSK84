import java.util.Scanner;
class A
{
	public static void main(String[]args)
	{
		Scanner sc=new Scanner(System.in);
		char c='A';
		alphabets(c);
	}
	public static void alphabets(char c)
	{
		
		if(c<='Z')
		{
			System.out.print(c+" ");
			c++;
			alphabets(c);
		}
	}
}



