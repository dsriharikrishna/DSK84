import java.util.Scanner;
class A
{
	public static void main(String[]args)
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		System.out.print(facto(n,1));
	}
	public static int facto(int a,int fact)
	{
		if(a>=1)
		{
			fact*=a;
			return facto(--a,fact);
		}
		return fact;
	}
}