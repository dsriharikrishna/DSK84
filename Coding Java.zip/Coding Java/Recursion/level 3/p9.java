import java.util.Scanner;
class A
{
	public static void main(String[]args)
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		if(reverse(n,0)==n)
			System.out.print("palindrome");
		else
			System.out.print("not a palindrome");
	}
	public static int reverse(int a,int rev)
	{
		if(a>0)
		{
			int r=a%10;
			rev=(rev*10)+r;
			return reverse(a/10,rev);
		}
		return rev;
	}
}
