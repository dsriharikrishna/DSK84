import java.util.Scanner;
class A
{
	public static void main(String[]args)
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		System.out.print(reverse(n,0));
	}
	public static int reverse(int a,int rev)
	{
		if(a>0)
		{
			int r=a%10;
			rev=(rev*10)+r;
			a/=10;
			return reverse(a,rev);
		}
		return rev;
	}
}
