class A{
    
    public static void main(String[] args) {
        // You can call the factorial method here and print the result
	
        int n = 5; // Change this to the desired number
        System.out.println("Factorial of " + n + " is: " + factorial(n));
    }
	public static int factorial(int n) {
        // Base case
        if (n == 0) {
            return 1;
        }
        //Recursive step
        return n * factorial(n - 1);
    }

}
