import java.util.*;
class A
{
   static Scanner sc  = new Scanner(System.in);
    public static void main(String[] args) 
	{
        int n = sc.nextInt(); // Change this to the number you want to check
        boolean isNumberEven = isEven(n);

        if (isNumberEven) 
	{
            System.out.println(n + " is even.");
        } else 
	{
            System.out.println(n + " is odd.");
        }
        }
	public static boolean isEven(int num) {
        
        if (num == 0) {
            return true;
        }
       
        if (num == 1) {
            return false;
        }
        return isEven(num - 2);
    }
    
}
