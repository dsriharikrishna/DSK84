import java.util.*;
class A
{
    static Scanner sc  =new Scanner(System.in);
    public static void main(String[] args) 
    {
        int number = sc.nextInt();
        boolean result = isArmstrong(number, 0, number);
        System.out.println(number + " is an Armstrong number: " + result);
    }
    public static boolean isArmstrong(int num, int sum, int original) 
    {
        if (num == 0) 
	{
            return sum == original;
        }
        int digit = num % 10;
        return isArmstrong(num / 10, sum + (digit * digit * digit), original);
    }
}
