import java.util.*;
class A
{
    static Scanner sc  =new Scanner(System.in);
    public static void main(String[] args) 
    {
        int number = sc.nextInt();
        boolean result = isPalindrome(number, 0, number);
        System.out.println(number + " is a palindrome: " + result);
    }
     public static boolean isPalindrome(int n, int reversed, int original) {
        if (n == 0) {
            return reversed == original;
        }
        int digit = n % 10;
        return isPalindrome(n / 10, reversed * 10 + digit, original);
    }
}
