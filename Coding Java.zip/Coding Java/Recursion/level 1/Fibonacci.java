import java.util.*;
class A 
{
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) 
	{
        int a = sc.nextInt();
        System.out.println("Fibonacci sequence for " + a + " terms:");

        for (int i = 0; i < a; i++) 
	{
            
            System.out.print(fibonacci(i)+ " ");
        }
}
	public static int fibonacci(int a) 
	{
        // Base cases
        if (a == 0) {
            return 0;
        }
        if (a == 1) {
            return 1;
        }
        // Recursive step
        return fibonacci(a - 1) + fibonacci(a - 2);
    	}
}

