import java.util.*;
class A
{
    static Scanner sc  =new Scanner(System.in);
    public static void main(String[] args) 
    {
        int number = sc.nextInt();
        int reversed = reverse(number, 0);
        System.out.println("Reverse of " + number + " is " + reversed);
    }
    public static int reverse(int n, int reversed) 
    {
        if (n == 0) {
            return reversed;
        }
        int digit = n % 10;
        return reverse(n / 10, reversed * 10 + digit);
    }
}
