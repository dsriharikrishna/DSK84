import java.util.*;
class A
{
    static Scanner sc  =new Scanner(System.in);
    public static void main(String[] args) {
        int number = sc.nextInt();
        boolean result = isOdd(number);
        System.out.println(number + " is odd ");
   	}
	public static boolean isOdd(int n) {
        if (n == 0) 
	{
            return false;
        } 
	else if (n == 1) 
	{
            return true;
        } 
	else 
	{
            return isOdd(n - 2);
        }
    }
}
