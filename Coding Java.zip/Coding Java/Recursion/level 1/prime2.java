/******************************************************************************

                   Prime Numbers in given range 

*******************************************************************************/
import java.util.*;
class A
{
	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	
	int a = sc.nextInt();
	int b = sc.nextInt();
	int fc = 0;
	
	isprime(a,b,fc);
	
	}
	public static void isprime(int a,int b,int fc)
	{
	    //prime(a,1);
	    if(a<=b)
	    {
    	    int x =  prime(a,1,0);
    	     //System.out.print(x);
    	    if(x==2)
    	        System.out.println(a+" ");
    	    isprime(a+1,b,0);
	    }
	}
	public static int prime(int a,int i,int fc)
	{
	      System.out.println(a+" "+i+" "+ fc);
	    if(i<=a)
	    {
	        if(a%i==0)
	            fc++;
	       return  prime(a,i+1,fc);
	   }
	   return fc;
	}
}
