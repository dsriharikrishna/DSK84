
import java.util.*;
class Main
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int Median=0,c=0;
		
		if(n<=0)
			System.out.print("Invalid ArraySize");
		else
		{
			int a[] = new int[n];
			for(int i=0;i<n;i++)
			{
				a[i] = sc.nextInt();
			}
			for(int i=0;i<n;i++)
			{
			    if(a[i]%2==0)
			    {
			           for(int j=i;j<n;j++)
			           {
			                if(a[j]%2==0)
			                {
			                       if(a[i]>a[j])
			                       {
			                           int t = a[i];
			                           a[i]= a[j];
			                           a[j]=t;
			                       }
			                }
			           }
			    }
				
			}
			System.out.print(Arrays.toString(a));
		}
	}
}
			