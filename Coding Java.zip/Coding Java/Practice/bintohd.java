import java.util.Scanner;
class A
{
	public static void main(String[]args)
	{
		Scanner sc  = new Scanner(System.in);
		String bin = sc.next();
		String hd ="";
		int dec=0,p=0,f=0,s=0,s1=0,s2=0,s3=0;
		for(int i=bin.length()-1;i>=0;i--)
		{
			if(bin.charAt(i)=='1')
				dec+=1*(int)Math.pow(2,p);

			else if(bin.charAt(i)=='0')
				dec+=1*(int)Math.pow(2,p);

			else if(bin.charAt(i)>='a' && bin.charAt(i)<='z')
			{	
				s++;
				break;
			}
			else if(bin.charAt(i)>='A' && bin.charAt(i)<='Z')
			{
				s1++;
				break;
			}
			else if(bin.charAt(i)>='1' && bin.charAt(i)<='9')
			{
				s2++;
				break;
			}
			else
			{
				s3++;
				break;
			}
			p++;	
		}
		if(dec>0)
		{
			int r = dec%16;
			if(r<=9)
				hd = r+hd;
			else
			 	hd=(char)(r+55)+hd;
			dec/=16;
		}
		System.out.print(hd);
     }
}
		