// Armstrong or not 
import java.util.Scanner;
class A
{
    public static void main(String args[])
    {
        Scanner sc  =  new Scanner(System.in);
        int a = sc.nextInt();
		int arm = 0,d = 0;
		int t=a;

		if(a>0)
		{
			while(t>0)
			{
				t=t/10;
				d++;
			}
			t=a;	
			while(t>0)
			{
				int r = t%10;
				arm += (int)Math.pow(r,d);
				t/=10;
			} 
			if(arm==a)
				System.out.print("Armstrong Number");
			else
				System.out.print("Not a Armstrong Number");
		}
		else
			System.out.print(" Invalid Input ");

    }
}
