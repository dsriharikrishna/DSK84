import java.util.*;
class Main
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();

		char a[] = new char[n];
	    for(int i=0;i<n;i++)
	        a[i]=sc.next().charAt(0);
	        
		for(int i=1;i<n/2;i++)
		{
		    if(i%2==1)
		    {
    		    for(int j=n-i;j>=0;j--)
    		    {
    		        if(j%2!=0)
    		        {
    		            char s = a[i];
    		            a[i]=a[j];
    		            a[j]=s;
    		            i++;
    		            break;
    		        }
    		        else
    		        {
    		            j--;
    		        }
    		    }
		    }
		}
	System.out.print(Arrays.toString(a));
	}
}