/*Average of Alternative prime Numbers  */
import java.util.*;
class A
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		int b = sc.nextInt();
		int fc=0,c=0,sum=0,p=0;

	if(a>0 && b>0)
	{
		for(int i=a;i<=b;i++)
		{
		 	fc=0;
			for(int j=2;j<=i;j++)
			{
		 		if(i%j==0)
					fc++;
			}	
			if(fc==1)
			{	
				System.out.print(i+" ");
				/*c++;
				if(c%2==1)
				{
					p++;
					sum = sum+i;
          	 		
				}*/
			}
		}
		if(p>0)
			System.out.printf("%.2f",(float)sum/p);	
		else
			System.out.print("No Numbers");
	}
	else
		System.out.print(" INvalid Inputs ");
	}	
}