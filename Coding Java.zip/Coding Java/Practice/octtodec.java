import java.util.Scanner;
class A
{
    public static void main(String[]args)
    {
       Scanner sc = new Scanner(System.in);
       String n = sc.next();
       int dec = 0;
       int p=0,s=0;
		if(n.charAt(0) == '-')
			n=n.substring(1);	
		for(int i=n.length()-1;i>=0;i--)
		{
			char a = n.charAt(i);
			int y = a-48;
			if(y==0 || y==7)
				dec = y*(int)Math.pow(8,p)+dec;
			else
				s++;
			p++;
		}
		if(s!=0)
			System.out.print("InvAlid Input.");
		else
			System.out.print(dec);
	
	}
}
