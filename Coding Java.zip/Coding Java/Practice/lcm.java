import java.util.Scanner;

class A
{
    public static void main(String[]args)
    {
       Scanner sc = new Scanner(System.in);
       int a = sc.nextInt();
       int b = sc.nextInt();
       int lcm = 1;

		if(a>0 && b>0)
		{
			for(int i=2;a>1||b>1; )
			{
				if(a%i==0 || b%i==0)
				{	
					if(a%i==0)
						a=a/i;
					if(b%i==0)
						b=b/i;
					lcm = lcm*i;
				}
				else
					i++;
			}
			System.out.println(lcm);
		}
    }
} 