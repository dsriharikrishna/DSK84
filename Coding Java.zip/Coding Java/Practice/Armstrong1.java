// Armstrong numbers in the given range  
import java.util.Scanner;
class A
{
    public static void main(String args[])
    {
        Scanner sc  =  new Scanner(System.in);
        int a = sc.nextInt();
		int b = sc.nextInt();
		int arm =0,d=0;
		int t=0,alt=0,sum=0;

	if(a>0 && b>0)
	{
		for(int i=a+1;i<=b;i++)
		{
			t=i;
			arm=0;
			d=0;
			int r=0;
			while(t>0)
			{
				t=t/10;
				d++;
			}
			t=i;	
			while(t>0)
			{
				r = t%10;
				arm += (int)Math.pow(r,d);
				t/=10;
			} 
			if(arm==i)
			{
				alt++;
				sum=sum+i;
				
                if(alt!=1)
                    System.out.print(" + ");
                else
            		System.out.print("Alternative Armstrong Numbers between the Given Values is ");

			System.out.print(i);
			}
	  	}
		System.out.print(" = "+ sum);  
		System.out.println();
		System.out.printf("%.2f",(float)sum/alt);
	}
	else
		System.out.print(" Invalid Input ");

     }
}