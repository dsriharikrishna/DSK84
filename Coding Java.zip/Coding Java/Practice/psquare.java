import java.util.Scanner;
class A
{
    public static void main(String []args)
    {
    Scanner sc =  new Scanner(System.in);
    int n = sc.nextInt();
    double x = Math.sqrt(n);


    if(n>0)
    {
	    if(x==(int)x)
		    System.out.print("Given Number is a Perfect Square.");
        else
            System.out.print("Given Number is Not a Perfect Square.");
       }
       else
            System.out.print("InvaliD Input");
    }
}