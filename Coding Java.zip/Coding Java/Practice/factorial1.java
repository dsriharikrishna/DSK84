/* factorial of a number upto the numbers */
import java.util.Scanner;
class A
{
    public static void main(String []args)
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
		int fact=1,sum=0;

		if(n>0)
		{
			for(int i=0;i<=n;i++)
			{
				for(int j=0;j<=i;j++)
				{
					if(j==0)
						fact=1;
					else
						fact=fact*j;
				}
				sum+=fact;
				if(i==0)
					System.out.print(fact);
				else
					System.out.print("+"+fact);
			}
			System.out.print("="+sum);
		}
		else
			System.out.println("Invalid input");
	}
}