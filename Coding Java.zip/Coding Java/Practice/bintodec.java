import java.util.Scanner;
class A
{
    public static void main(String[]args)
    {
       Scanner sc = new Scanner(System.in);
       String bin = sc.next();
       int dec = 0;
       int p=0,s=0;
	
		for(int i=bin.length()-1;i>=0;i--)
		{
			char a = bin.charAt(i);
			int y = a-48;
			if(y==0 || y==1)
				dec = y*(int)Math.pow(2,p)+dec;
			else
				s++;
		p++;
		}
		if(s!=0)
			System.out.print("InvAlid Input.");
		else
			System.out.print(dec);
	
	}
}
