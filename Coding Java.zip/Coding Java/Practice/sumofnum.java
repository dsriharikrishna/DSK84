import java.util.Scanner;
class Main
{
    public static void main(String []args)
    {
    Scanner sc =  new Scanner(System.in);
    int n = sc.nextInt();
    int sum =0,c=0;
    
   
    if(n!=0)
    {
        if(n<0)
        System.out.print("Sorry! you have Entered Negative Values.");
        else
        {
           for(int i=1; i<=n; i++)
           {
               sum +=i;
               c++;
               if(c==1)
                    System.out.print("Sum of 'N' Natural Numbers is "+i);
               else
                    System.out.print(" + "+i);
           }
     System.out.print(" = "+sum+".");
        }
    }
    else
        System.out.print("InvaLid Input.");
    }
}