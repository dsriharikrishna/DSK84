//Lowest Digit in a Given Number ,Highest Digit in a Given Number and Highest Span in a Given Number 
import java.util.Scanner;
class A
{
    public static void main(String []args)
    {
    Scanner sc =  new Scanner(System.in);
    int n = sc.nextInt();
 
    int lowestdigit = 9;
    int highestdigit = 0;
    int highestspan = 0;
    
    boolean c = false;

	if(n>0)
	{
		while(n>0)
		{
			int r = n%10;
			lowestdigit = Math.min(lowestdigit,r);
			highestdigit = Math.max(highestdigit,r);
			n=n/10;
		}
	    int span = highestdigit - lowestdigit;
	    System.out.println("Lowest Digit in a Given Number is "+Lowestdigit+".");
        System.out.println("Highest Digit in a Given Number is "+Highestdigit+".");
        System.out.println("Highest Span in a Given Number is "+span+".");
       }
}
}
	