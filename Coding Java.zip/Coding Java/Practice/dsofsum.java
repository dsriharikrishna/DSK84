/* digits count and sum of the sum
*/
import java.util.*;
class A
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int sum = 0;
		int count = 0;
	if(n>0)
	{
		while(n>0)
		{
			sum = sum + n%10;
			n=n/10;
			if(n==0 && sum>=10)
			{
				n=sum;
				sum=0;
			}
		}
		//System.out.println(sum%9);
		System.out.println(sum);
	}
	else
		System.out.print(" INvalid Input ");
	}	
}