
import java.util.*;
class Main
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		pattern(n);
	}
	public static void pattern(int z)
	{
	    int p=2,a=0,b=1,c=0;
		for(int i=1;i<=z;i++)
		{
		    for(int j=1;j<=i;j++)
		    {
		        c++;
		        if(c%2==1)
		        {
		            int fc=0;
		            for(int k=1;k<=p;k++)
		            {
		                if(p%k==0)
		                    fc++;
		            }
		            if(fc==2)
		            {
		                System.out.print(p+" ");
		            }
		            else
		            {
		                c--;
		                j--;
		            }
		            p++;
		        }
		        else
		        {
		            System.out.print(a+" ");
		            int d=a+b;
		            a=b;
		            b=d;
		        }
		    }
		    System.out.println();
		}
	}
}
			