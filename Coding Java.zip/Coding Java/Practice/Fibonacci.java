/*Fibonnacci Numbers  */
import java.util.*;
class A
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int a=0,b=1,count=0;

	if(n>0)
	{
		/* fibonacci numbers 
		for(int i=1;i<=n;i++)
		{
			System.out.print(a+" ");
			int c=a+b;
			a=b;
			b=c;
		}
		*/
		
		 /*Alternative fibonacci numbers */
		for(int i=1;i<=2*n;i++)
		{
			count++;
			if(count%2==1)	
			{
				System.out.print(a+" ");
			}
			else
			{
				System.out.print(", "+a);
			}
			int c=a+b;
			a=b;
			b=c;
		}
	}
	}
}