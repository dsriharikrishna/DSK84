/* 2 
   0 3 
   1 5 1
   7 2 11 3 
   13 5*/
import java.util.*;
class A
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int fc=0,a=0,b=1,count=0,p=0;
		if(n>0)
		{
			for(int i=1;i<=2*n;i++)
			{
			count++;
			if(count%2==0)
			{
					System.out.print(a+" ");
					int c=a+b;
					a=b;
					b=c;
			}	
			if(count%2==1)
				{
				fc=0;
				for(int j=2;j<=i;j++)
				{
					if(p%j==0)
						fc++;
				}	
				if(fc==1)
						System.out.print(p+" ");
				else
					count--;
				p++;
					
			}
			}  
		}	
     }
}	
