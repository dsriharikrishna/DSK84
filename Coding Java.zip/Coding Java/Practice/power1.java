import java.util.Scanner;
class A
{
    public static void main(String []args)
    {
    Scanner sc =  new Scanner(System.in);
    int n = sc.nextInt();
    int sum=0;
    boolean c = false;

    if(n>0) 
    {
	for(int i=n;i>0;i--)
	{
		sum=sum+i*i;
		if(c)
			System.out.print(" + ");
	System.out.print(i*i); 
	c=true;
	}
	System.out.print(" = "+sum);
   }
}
}