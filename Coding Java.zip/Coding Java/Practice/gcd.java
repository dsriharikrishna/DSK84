import java.util.Scanner;

class A
{
    public static void main(String[]args)
    {
       Scanner sc = new Scanner(System.in);
       int a = sc.nextInt();
       int b = sc.nextInt();

		if(a>0 && b>0)
		{
			for(int i=a;i>0;i--)
			{
				if(a%i==0 && b%i==0)
				{	
					System.out.print(i);
					break;
				}
			}
		}
    }
} 