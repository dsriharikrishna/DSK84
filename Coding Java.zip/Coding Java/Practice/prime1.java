import java.util.*;
class A
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		int b = sc.nextInt();
		int fc=0;

	if(a>0 && b>0)
	{
		for(int i=a;i<=b;i++)
		{
			fc=0;
			for(int j=2;j<=i;j++)
			{
		 		if(i%j==0)
					fc++;
			}	
			if(fc==1)
          	 	System.out.print(i+" ");
		}
	}
	else
		System.out.print(" INvalid Inputs ");
	}	
}