/* digits count and count sum
*/
import java.util.*;
class A
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int sum = 0;
		int count = 0;
		if(n>0)
		{
			while(n>0)
			{
				int r = n%10;
				count++;
				if(count%2==1)
					sum = sum+r;
				n=n/10;
			}
			System.out.print(count);
			System.out.print(sum);
		}
		else
			System.out.print(" INvalid Input ");
	}	
}