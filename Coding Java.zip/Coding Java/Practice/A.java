//Character array {‘c’,’v’,’c’,’o’,’r’,’p’}, 
//output:1 (Number of vowels)

import java.util.*;
class A 
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int c =0;
		char a[] = new char[n];
	
		for(int i=0;i<n;i++)
		{
			a[i] = sc.next().charAt(0);
		}
		for(int i=0;i<n;i++)
		{
			if(a[i]=='a' || a[i]=='e' || a[i]=='i' || a[i]=='o' || a[i]=='u')
			c++;
		}
		System.out.print(c);
	}
}