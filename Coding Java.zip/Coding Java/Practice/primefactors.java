/*prime factors */
import java.util.*;
class A
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int fc=0,c=0;

	if(n>0)
	{
		for(int i=1;i<=n;i++)
		{
		   if(n%i==0)
		   {
			fc=0;
			for(int j=2;j<=i;j++)
			{
		 		if(i%j==0)
					fc++;
			}	
			if(fc==1)
			{	
				c++;
          	 		System.out.print(i+" ");
			}
	           }
		}
		if(c==0)
			System.out.print("No Numbers");	
	}
	else
		System.out.print(" INvalid Inputs ");
	}	
}