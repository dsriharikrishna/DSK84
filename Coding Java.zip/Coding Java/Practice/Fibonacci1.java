/* factorial of a number */
import java.util.Scanner;
class A
{
    public static void main(String []args)
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
		int a=0,b=1,sum=0;

		if(n>0)
		{
			for(int i=1;i<=n;i++)
			{
				sum=sum+a;
				System.out.print(a+" ");
				int c=a+b;
				a=b;
				b=c;
			}
			System.out.println(sum);
		}
		else
			System.out.print(" Invalid Inout ");
	}
}
