import java.util.*;
class A
{
	public static void main(String args[])
	{
		Scanner sc =  new Scanner(System.in);
		int r = sc.nextInt();
		
		if(r>0)
		{
			int c = (int)(r/2)+1;
			for(int i=1;i<=r;i++)
			{
				for(int j=1;j<=r;j++)
				{
					if(r%2==0)
					{
						if(i==(c-1) || j==(c-1))
							System.out.print("* ");
						else if(j==c || i==c)
							System.out.print("* ");
						else
							System.out.print("  ");
					}
					else
					{
						if(j==c || i==c)
							System.out.print("* ");
						else
							System.out.print("  ");
					}
				}
			System.out.println();
			}
		}
		else
			System.out.println("Invalid Input");
	}
}