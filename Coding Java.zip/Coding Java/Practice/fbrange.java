/*Fibonnacci Numbers  */
import java.util.*;
class A
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int x = sc.nextInt();
		int y = sc.nextInt();
		int a=0,b=1,count=0,fc=0,sum=0;

		if(x>0 && y>0)
		{
		
			/* fibonacci in range 
			while(a<=y)
			{
				if(a>=x)
				{
					count++;
					System.out.print(a+" ");
				}
				int c=a+b;
				a=b;
				b=c;
			}
			if(count == 0)
				System.out.print(" No Fibonacci Series Values ");
			*/
			//Average of alternative fibonacci in range 
			while(a<=y)
			{
				if(a>=x)
				{
					count++;
					if(count%2==1)
					{
						fc++;
						sum = sum+a;
					}
				}
				int c=a+b;
				a=b;
				b=c;
			}
			
			if(fc == 0)
				System.out.print(" No Fibonacci Series Values ");
			else
				System.out.printf("%.2f",(float)sum/fc);
		}	
		else
			System.out.print("Invalid Input");
	}
}