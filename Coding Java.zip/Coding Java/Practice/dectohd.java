import java.util.Scanner;
class A
{
	public static void main(String[]args)
	{
		Scanner sc  = new Scanner(System.in);
		String bin = sc.next();
		String HD ="";


		
				hd= (char)(r+55)+hd;
			a=a/16;
		
		System.out.print(hd);
     }
}
		