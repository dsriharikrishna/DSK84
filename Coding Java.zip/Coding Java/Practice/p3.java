import java.util.*;
class A
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt(),c=0;
        
        if(n<=0)
            System.out.print("Invalid Input");
        else
        {
            for(int i=1;i<=n;i++)
            {
		if(i%2==1)
		{
			c=c+i;
			for(int j=1;j<=i;j++)
			{
				if(i==j)
					System.out.print(c);

				else
					System.out.print(c+"*");
				c++;	
			}
		}
		else
		{
			c=c+i-1;
			for(int j=1;j<=i;j++)
			{
				if(i==j)
					System.out.print(c);

				else
					System.out.print(c+"*");
				c--;	
			}
		}
		System.out.println();
	} 
     
     }
   }
}
	