class A
{
	public static void main(String[]args)
	{
		int sal=15000;
		int c=3;
		int d=22;

		System.out.println(sal*d);
		System.out.println(d*50);

		int a=(d/c)*5;
		int b=a;
		int e=a;
		if(d%c==1)
		{
			a+=2;
			b+=2;
			e+=1;
		}
		else if(d%c==2)
		{
			a+=4;
			b+=3;
			e+=3;
		}
		System.out.print(a+"\n"+b+"\n"+e);
	}
}