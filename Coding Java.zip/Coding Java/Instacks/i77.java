import java.util.Scanner;
class Main
{
    public static void main(String []args)
    {
        Scanner sc =  new Scanner(System.in);
        int n = sc.nextInt();
        int sum=0,rev=0,count=0;
        
        if(n>0)
        {
           while(n>0)
           {
               int r = n%10; 
               rev=rev*10+r;
               n=n/10;
           }
           n=rev;
           while(n>0)
           {
               int digit = n%10;
               count++;
               n=n/10;
               if(count!=1)
               {
                   System.out.print(" + ");
               }
               System.out.print(digit);
           
           }
         System.out.print(".");
        }
        else
            System.out.print("Invalid Input.");
    }
}
