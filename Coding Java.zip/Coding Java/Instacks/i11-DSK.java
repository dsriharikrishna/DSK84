import java.util.Scanner;
class dsk
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        
        int a  = sc.nextInt();
        int b = sc.nextInt();
        
        if(a>b){
            System.out.println("INVALID RANGE");
        }
        else{
            for(int i=a; i<=b; i++){
                if(i%2!=0){
                    System.out.print(i + " ");
                }
            }
        } 
    }
}