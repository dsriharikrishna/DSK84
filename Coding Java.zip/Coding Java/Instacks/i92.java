import java.util.Scanner;
class Main
{
    public static void main(String args[])
    {
        Scanner sc  = new Scanner(System.in);
        int n  = sc.nextInt();
        
        if(n!=0)
        {
            if(n<0)
                System.out.print("Given Number is Not a Perfect Square.");
            else
            {
                int sqrt = (int)Math.sqrt(n);
                int r = sqrt*sqrt;
                if(r==n)
                    System.out.print("Given Number is Perfect Square.");
                else
                    System.out.print("Given Number is Not a Perfect Square.");
            }
        }
        else
            System.out.print("Invalid Input");
            
    }
}
