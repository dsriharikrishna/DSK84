
class greatest
{
public static void main(String[]args)
{

int num1 = 15;
int num2 = 25;
int num3 = 17;
int num4 = 19;
int num5 = 16;

if (num1 >= num2 && num1 >= num3 && num1 >= num4 && num1 >= num5){
System.out.println(" The First Number (" + num1 + ") is the greatest.");
}
else if (num2 > num1 && num2 >= num3 && num2 >= num4 && num2 >= num5){
System.out.println("The Second Number (" + num2 + ") is the greatest.");
}
else if(num3 >= num1 && num3 >= num2 && num3 >= num4 && num3 >= num5){
System.out.println(" The Third Number (" + num3 + ") is the greatest.");
}
else if (num4 >= num1 && num4 >= num2 && num4 >= num3 && num4 >= num5 ){
System.out.println("The Four Number (" + num4 + ") is the greatest.");
}
else {
System.out.println("The Numbers Are not distinct.");
}

}
}
 