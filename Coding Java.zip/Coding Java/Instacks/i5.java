import java.util.Scanner;

class dsk
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        
        int n = sc.nextInt();
        int n1 = sc.nextInt();
        
        int sum = 0;
        if(!(n>n1)){
        for(int i=n; i<=n1; i++)
        {
            sum = sum+i;
        }
        System.out.println(sum);
        }       
        else
        {
            System.out.println("INVALID RANGE");
        }
    }
}