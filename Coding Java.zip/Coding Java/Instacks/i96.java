import java.util.Scanner;
class A
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        int a=sc.nextInt();
        int r=sc.nextInt();
        int n=sc.nextInt();
        int sum=0;
        if(n<0)
        {
            System.out.print("Invalid Input");
        }
        else
        {
            for(int i=0;i<n;i++)
            {
                int d=a*(int)Math.pow(r,i);
                sum=sum+d;
            }
            System.out.print(sum);
        }
    }
}