import java.util.Scanner;
class Main
{
    public static void main(String args[])
    {
        Scanner sc  =  new Scanner(System.in);
        int a = sc.nextInt();
        int c=0;
        
        if(a>0)
        {   int i=0;
            for (i=2;i<=a;i++)
            {
            if(a%i==0)
               break;
            }
            if(i==1)
            System.out.print("Prime Number");
            else
            System.out.print("Not a Prime Number");
        }
        else 
        {
            System.out.print("Invalid Input");
        }
    }
}