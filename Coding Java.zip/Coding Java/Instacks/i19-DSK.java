import java.util.Scanner;
class dsk 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        
        int count = 0;
        int sum = 0;
        
        if(a>b)
        {
            System.out.print("INVALID RANGE");
        }
        else
        {
          for(int i = a; i<=b; i++)
          {
            if(i%2==0){
                sum = sum +i;
                count++;
            }
          }
        }
        if(count>0){
           float ave =(float)sum/count;  
           System.out.print(ave);
        }
        
    }
}