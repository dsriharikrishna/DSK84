import java.util.Scanner;
class Main
{
    public static void main(String args[])
    {
        Scanner sc  =  new Scanner(System.in);
        int n = sc.nextInt();
        int rev = 0,t=n;
      
      if(n>0)
      {
        while(n>0)
        {
            int r = n%10;
            rev =  rev*10+r;
            n/=10;
        }
        if(rev==t)
            System.out.print("Palindrome");
        else
            System.out.print("Not a Palindrome");
      }
      else
        System.out.print("InvAlid Input");
    }
}