import java.util.Scanner;

class Main
{
    public static void main(String[]args)
    {
       Scanner sc = new Scanner(System.in);
       int a = sc.nextInt();
       int b = sc.nextInt();
       int c = sc.nextInt();
       
       if(a>0 && b>0 && c>0)
       {
        for(int i=a;i>0;i--)
        {
             if(a%i==0 && b%i==0 && c%i==0)
                {
                System.out.print(i);
                break;
                }
        }
       }
       else if((a<=0 && b<=0) || (b<=0 && c<=0) || (c<=0 && a<=0)) 
                System.out.print("Invalid Inputs");
       else if(a<=0)
                System.out.print("Invalid First Input");
       else if(b<=0)
                System.out.print("Invalid Second Input");
       else if(c<=0)
                System.out.print("Invalid Third Input");
       
    }
}
