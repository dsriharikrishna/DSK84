import java.util.Scanner;

class Main
{
    public static void main(String[]args)
    {
       Scanner sc = new Scanner(System.in);
       int a = sc.nextInt();
       int d = sc.nextInt();
       int n = sc.nextInt();
       boolean c = false;
       int sum =0;
       
       if(n>0)
       {
           for(int i=1; i<=n; i++)
           {
               if(c)
                    System.out.print(" + ");
               System.out.print(a);
               sum+=a;
               a=a+d;
               c=true;
           }
           System.out.print(" = "+sum);
           System.out.print(".");
       }
       else
            System.out.print("Invalid input.");
    }
}
