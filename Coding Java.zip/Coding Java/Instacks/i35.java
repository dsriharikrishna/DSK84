import java.util.Scanner;
class Main
{
    public static void main(String []args)
    {
    Scanner sc  = new Scanner(System.in);
    int a = sc.nextInt();
    int sum =0;
    
    if(a>0)
    {
       while(a>0)
       {
           int r=a%10;
           sum = sum+r;
           a=a/10;
       }
       System.out.print(sum);
    }
    else
        System.out.print("Invalid Input");
    }
}