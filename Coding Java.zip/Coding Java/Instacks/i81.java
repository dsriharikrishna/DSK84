import java.util.Scanner;
class Main
{
    public static void main(String []args)
    {
       Scanner sc = new Scanner(System.in);
       int n = sc.nextInt();
       int smalldigit = 9;
       
      
       if(n>0)
       {
           while(n>0)
           {
               int r = n%10;
               smalldigit = Math.min(smalldigit, r);
               n=n/10;
           }
           System.out.print("Smallest Digit in a Given Number is "+smalldigit+".");
       }
       else
            System.out.print("Invalid Input.");
    }
}