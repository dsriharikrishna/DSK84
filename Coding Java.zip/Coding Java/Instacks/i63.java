import java.util.Scanner;
class Main
{
    public static void main(String args[])
    {
        Scanner sc  =  new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        int sr =0;
        int sum =0;
        int count=0;
        int alt =0;
          
        if(a<0)
          a=-a;
        if(b<0)
          b=-b;
        if(a>b)
        {
           a=a+b;
           b=a-b;
           a=a-b;
        
        }
        if(a!=0 && b!=0)
        {
            for( int i=a+1; i<b; i++)
            { 
                int rev=0;
                int t=i;  
                while(t>0)
                { 
                    int r = t%10;
                    rev =  rev*10+r;
                    t/=10;
                }
                if(rev==i)
                {
                    alt++;
                    if(alt%2==1)
                    {
                     count++;
                     sum+=i;
                     if(count==1)
                     System.out.print("Sum of Alternative Palindrome Numbers between the " +a+ " and " +b+ " is ");
                    else
                    {
                        System.out.print(" + ");
                    }
                     System.out.print(rev);
                    }
                }
            }
            if(count==0)
                System.out.print(" No Palindrome Values");
            else
                System.out.print(" = "+sum+".");
        }
      else
        System.out.print("Invalid Inputs");
    }
}
