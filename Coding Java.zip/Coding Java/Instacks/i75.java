import java.util.Scanner;
class Main
{
    public static void main(String []args)
    {
    Scanner sc =  new Scanner(System.in);
    int a = sc.nextInt();
    int b = sc.nextInt();
    int c =0;
    
    if(a!=0 && b!=0)
    {
        if(a<0)
            a=-a;
        if(b<0)
            b=-b;
        if(a>b)
        {
            a=a+b-(b=a);
        }
        for(int i =a+1; i<b; i++)
        {
            int t=i;
            int arm=0; 
            int d=0;
            while(t>0)
            {
               t/=10;
               d++;
            }
            t=i;
            while(t>0)
            {
              int r=t%10;
              arm+=(int)Math.pow(r, d);
              t/=10;
            }
            if(arm == i)
            {
                c++;
                if(c==1)
                    System.out.print("Armstrong Numbers between the Given Values is ");
                if(c!=1)
                     System.out.print(", ");
            System.out.print(i);
            }
        }
        if(c==0)
            System.out.print("No Armstrong Numbers Between Given Values");
        else
            System.out.print(".");
    }
    else
        System.out.print("Invalid Inputs");
    }
}