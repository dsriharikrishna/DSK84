import java.util.Scanner;

class dsk
{
    public static void main(String args[])
    {
     Scanner sc = new Scanner(System.in);
     float kg = sc.nextFloat();
     float grams = kg*1000;
     System.out.println((int)grams+ " Grams");
    }
}