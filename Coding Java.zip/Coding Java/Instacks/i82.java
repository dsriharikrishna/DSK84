import java.util.Scanner;
class Main
{
    public static void main(String []args)
    {
       Scanner sc = new Scanner(System.in);
       int n = sc.nextInt();
       int Highestdigit = 0;
       
      
       if(n>0)
       {
           while(n>0)
           {
               int r = n%10;
               Highestdigit = Math.max(Highestdigit, r);
               n=n/10;
           }
                 System.out.print("Highest Digit in a Given Number is "+Highestdigit+".");
       }
       else
            System.out.print("Invalid Input.");
    }
}