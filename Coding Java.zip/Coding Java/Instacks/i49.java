import java.util.Scanner;

class Main
{
    public static void main(String []args)
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int fc=0;
        
        int a=0,b=1;
        
        if(n<=0)
         {
             n=-n;
         }
        if(n>0)
        {
            int count=0;
            for(int i=1; i<=2*n; i++)
            {
                count++;
                if(count%2==1)
                {
                    if(count==1)
                   	 System.out.print(a);
                    else
                    System.out.print(", "+a);
                }
              
                int c=a+b;
                a=b;
                b=c;
            }
        }
        else
            System.out.print("Invalid Input");
    }
}