import java.util.Scanner;
class dsk
{
    public static void main(String args[])
    {
        
    Scanner sc = new Scanner(System.in);
    int a = sc.nextInt();
    int b =sc.nextInt();
    
    if(a>b)
    {
    for (int i = a; i>=b; i--)
    {

        if(i!=a)
        {
            System.out.print(",");
        }
        System.out.print(i+ "@" +(i-1));
    }
    }
    if(a<b){
        for(int i=a;i<=b;i++)
        {
    
            if(i!=a)
            {
                System.out.print(",");
            }
            System.out.print(i+ "@" +(i+1));
        }
    }
 }
}
