import java.util.Scanner;

class dsk {
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
         
         int a = sc.nextInt();
        
        if(!(a>100 && a<1000))
        {
            System.out.println("WRONG NUMBER");
        }
        else 
        {
            if(a%2==0)
            {
              System.out.println(a%3);
            }
            else
            {
                System.out.println(a%2);
            }
        }
         
    }
}S