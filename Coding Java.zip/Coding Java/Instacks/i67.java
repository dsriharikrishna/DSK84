import java.util.Scanner;
class Main
{
    public static void main(String []args)
    {
    Scanner sc =  new Scanner(System.in);
    int a = sc.nextInt();
    int b = sc.nextInt();
    int c =0,d=0,r;
    int sum =0;
   
    if(a!=0 && b!=0)
    {
        if(a<0)
            a=-a;
        if(b<0)
            b=-b;
        if(a>b)
             a=a+b-(b=a);
             
        for(int i =a; i<=b; i++)
        {
            int t=i;
            int arm=0; 
            int e=0;
            while(t>0)
            {
               t/=10;
               e++;
            }
            t=i;
            r=0;
            while(t>0)
            {
              r=t%10;
              arm+=(int)Math.pow(r, e);
              t/=10;
            }
            if(arm == i)
            {
                 c++;
                if(c%2==1)
                {
                    d++;
                    if(d==1)
                    {
                        System.out.print("Average of Alternative Armstrong Numbers in the Given Range is ( ");
                    }
                    else
                    {
                         System.out.print(" + ");
                    }
                    System.out.print(i);
                    sum = sum +i;
                }
            }
            
        }
        if(d==0)
            System.out.print("No Armstrong Numbers in a Given Range");
        else
        {
            float avg =(float)sum/d; 
            System.out.printf(" ) "+"/ "+d+" = "+"%.2f",avg);
        }
    }
    else
        System.out.print("Invalid Inputs.");
    }
}
