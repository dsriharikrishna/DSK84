import java.util.Scanner;
class Main
{
    public static void main(String args[])
    {
        Scanner sc  = new Scanner(System.in);
        int n  = sc.nextInt();
 
        if(n>0)
        {
            while(n>1)
            {
                n=n-2;
            }
            if(n==0)
                System.out.print("Even");
            else
                System.out.print("Odd");
        }
        else
            System.out.print("Invalid Input");
            
    }
}