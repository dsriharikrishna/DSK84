import java.util.Scanner;
class dsk {
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        
        int a = sc.nextInt();
        int b = sc.nextInt();
        if(a>0 && b>0)
        {
            for(int i=a;i<=b;i++)
            {
                if(i!=a && i%100==0)
                {
                    System.out.print(", ");
                }
                if(i%100==0){
                    System.out.print(i);
                }
            }
        }
        else
        {
            System.out.print("Invalid Inputs");
        }
    }
}