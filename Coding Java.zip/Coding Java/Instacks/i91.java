import java.util.Scanner;
class Main
{
    public static void main(String args[])
    {
        Scanner sc  = new Scanner(System.in);
        int n  = sc.nextInt();
        
        if(n>0)
        {
            if((n*0.5) == (int)(n*0.5))
                System.out.print("Even");
            else
                System.out.print("Odd");
        }
        else
            System.out.print("InvaliD InpuT");  
            sc.close();
    }
}