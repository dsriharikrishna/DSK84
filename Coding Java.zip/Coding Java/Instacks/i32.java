// even positions code 
//i/p=212
//o/p=4


import java.util.Scanner;
class Main
{
    public static void main(String []args)
    {
    Scanner sc  = new Scanner(System.in);
    int a = sc.nextInt();
    int sum =0;
    int pos=0; 
    if(a>0)
    {
        while(a>0)
        {
            int r=a%10;
            if(r%2==0)
            {
            sum = sum+r;
            }
            a=a/10;
        }
        System.out.println(sum);
    }
    else{
        System.out.println("Invalid Input");
    }
    }
}
