import java.util.Scanner;

class Main
{
    public static void main(String []args)
    {
    Scanner sc  = new Scanner(System.in);
    int a = sc.nextInt();
    int b = sc.nextInt();
    int c =0;
    int sum = 0;
    
        if(a>0 && b>0)
        {
        for (int i=a+1; i<b; i++)
        {
            int count =0;
            for (int j=2; j<i; j++)
            {
                if(i%j==0)
                {
                    count++;
                }
            }
            if(count==0)
            {
               c++;
               sum = sum+i;
            }
        }
        float avg = (float)sum/c;
        System.out.printf("%.3f", avg);
        }
        else
            System.out.print("Invalid Inputs");
    }
}
