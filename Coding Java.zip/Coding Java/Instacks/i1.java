import java.util.Scanner;
class dsk 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        
       if (!(a>=0 && a<=100))
       {
           System.out.print("INVALID INPUT");
       }
       else
       {
           if(a>=91 && a<=100)
            {
                System.out.print("SUPER SMART");
            }
            else if(a>=81 && a<=90)
            {
                System.out.print("SMART");
            }
            else if(a>=71 && a<=80)
            {
                System.out.print("SMART ENOUGH");
            }
            else if(a>=61 && a<=70)
            {
                System.out.print("JUST SMART");
            }
            else if(a>=36 && a<=60)
            {
                System.out.print("NO SMART");
            }
            else if(a>=0 && a<=35)
            {
                System.out.print("DUMB");
            }
        }
    }
    
}