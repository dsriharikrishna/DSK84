import java.util.Scanner;
class Main
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int sum =0,c=0;
        if(n<0)
            n=-n;
        if(n!=0)
        {
          for(int i=n;i>=1; i--)
          {
              sum = sum+i*i;
              c++;
             if(c!=1)
                System.out.print(" + ");
            else
                System.out.print(i*i);
          }
          System.out.print(" = "+sum);
        }
        else
            System.out.print("Invalid Input");
    }
}