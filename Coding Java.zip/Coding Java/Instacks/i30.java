import java.util.Scanner;
class dsk
{
    public static void main(String args[])
    {
        
    Scanner sc = new Scanner(System.in);
    int a = sc.nextInt();
    
    if(a>0)
    {
        for (int i = 1; i<=a; i++)
        {
            if(i!=1)
            {
                System.out.print(", ");
            }
            if(i%2==0)
            {
                System.out.print(10);
            }
            else
            {
                System.out.print(5);
            }
        }
     }
     else
     {
         System.out.print("Invalid Input");
     }
    
 }
}