import java.util.Scanner;
class dsk
{
    public static void main(String args[]){
        
    Scanner sc = new Scanner(System.in);
    int a = sc.nextInt();
    
    for (int i = 1; i<=a; i++)
    {
        if(i!=1 )
        {
            System.out.print(", ");
        }
        if(i%2==0)
        {
            System.out.print("even");
        }
        else
        {
            System.out.print(i);
        }
    }
    }
}