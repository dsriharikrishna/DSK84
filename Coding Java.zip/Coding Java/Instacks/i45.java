import java.util.Scanner;

class Main
{
    public static void main(String []args)
    {
    Scanner sc  = new Scanner(System.in);
    int a = sc.nextInt();
    int b = sc.nextInt();
    int c =0;
    int pc =0;
    int sum = 0;
    
   	if(a>b)
        {
            a=a+b;
            b=a-b;
            a=a-b;
        }    
        if(a>0 && b>0)
        {
        for (int i=a+1; i<b; i++)
        {
            int fc =0;
            for (int j=1; j<=i; j++)
            {
                if(i%j==0)
                    fc++;
            }
            if(fc==2)
            {
               c++;
               if(c%2==1)
               {
               pc++;
               sum = sum+i;
               }
            }
         }
         if(pc!=0)
         {
         float avg =(float)sum/pc;
         System.out.printf("%.3f", avg);
         }
         else
         {
               System.out.print("No Prime Numbers");
         }
        }
        else
            System.out.print("Invalid Inputs");
    }
}