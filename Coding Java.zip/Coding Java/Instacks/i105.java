import java.util.Scanner;

class Main
{
    public static void main(String[]args)
    {
       Scanner sc = new Scanner(System.in);
       int a = sc.nextInt();
       int d = sc.nextInt();
       int n = sc.nextInt();
       boolean c = false;
       int sum =0;
       
       if(n>0)
       {
           for(int i=1; i<=n; i++)
           {
               if(i==n)
               System.out.print("Last term value is : "+(a+(n-1)*d));
           }
           System.out.print(".");
       }
       else
            System.out.print("InValid Input.");
    }
}
