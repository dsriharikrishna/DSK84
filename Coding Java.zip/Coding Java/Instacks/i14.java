import java.util.Scanner;

class dsk
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        
        int a  = sc.nextInt();
        int b  =  sc.nextInt();
        int c=0;
        
      if(a<b)
      {
          for(int i=a;i<=b;i++)
          {
              if(i%2==0)
              {
                  c++;
                  if(c%2==1)
                  {
                    System.out.print(i+" ");  
                  }
              }
          }
          if(c==0)
              System.out.print("NO NUMBERS");
      }
      else
      {
           System.out.print("INVALID INPUTS");
      }
      
    }
    
}