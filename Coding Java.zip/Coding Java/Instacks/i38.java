import java.util.Scanner;
class Main
{
    public static void main(String args[])
    {
        Scanner sc  =  new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        int fc = 0;
        int c=0;
        
        if(a>0 && b>0)
        {
            for(int i=a; i<=b; i++)
            {
                fc=0;
                for(int j=1; j<=i; j++)
                {
                if(i%j==0)
                {
                 fc++;
                }
            }
            if(fc==2)
              {
                c++;
            if(c!=1)
            System.out.print(", ");
           System.out.print(i);
             }   
        }
        }
        else 
        {
            System.out.print("Invalid Inputs");
        }
    }
}