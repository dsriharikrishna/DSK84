import java.util.Scanner;

class Main
{
    public static void main(String []args)
    {
    Scanner sc  = new Scanner(System.in);
    int a = sc.nextInt();
    int b = sc.nextInt();
    int c =0;
    int pc =0;
    int sum = 0;
    
        if(a>0 && b>0)
        {
        for (int i=a+1; i<b; i++)
        {
            int fc =0;
            for (int j=1; j<=i; j++)
            {
                if(i%j==0)
                    fc++;
            }
            if(fc==2)
            {
               c++;
               if(c%2==1)
               {
               pc++;
               sum = sum+i;
               }
            }
         }
            if(sum!=0)
            {
                System.out.print(sum);
            }
            if(pc==0)
             {
                 System.out.print("No Prime Numbers");
             }
        }
        else
            System.out.print("Invalid Inputs");
    }
}