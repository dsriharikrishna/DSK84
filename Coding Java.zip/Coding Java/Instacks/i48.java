import java.util.Scanner;
class Main
{
    public static void main(String []args)
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int fact=1;
        int c=0;
        int sum =0;
        
        if(n>=0)
        {
            for(int i=0; i<=n; i++)
            {
                for(int j=0; j<=i; j++)
                {
                    if(j==0)
                        fact=1;
                    else
                        fact= fact*j;
                }
             sum = sum+fact;
             if(i==0)
             System.out.print(fact);
             else
              System.out.print("+"+fact);
            }
          System.out.print("="+sum);  
        }
        else
            System.out.print("INvalid INput");
    }
}