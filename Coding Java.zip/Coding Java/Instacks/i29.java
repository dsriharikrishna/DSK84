import java.util.Scanner;
class dsk 
{
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        
        float a = sc.nextFloat();
        float b = sc.nextFloat();
        
        for (float i =a; i<=b; i+=0.2)
        {
            if(i!=a)
            {
                System.out.print(", ");
            }
             System.out.printf("%.1f", i);
             System.out.print("^"+"2");
        }
             System.out.print(".");
    }
}