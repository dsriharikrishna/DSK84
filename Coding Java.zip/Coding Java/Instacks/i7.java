import java.util.Scanner;

class dsk
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        int c = sc.nextInt();
        float d =(((float)c*9/5)+32);
        System.out.println(+d+ "F");
    }
}