import java.util.Scanner;

class Main
{
    public static void main(String []args)
    {
        Scanner sc = new Scanner(System.in);
        int x = sc.nextInt();
        int y = sc.nextInt();
        int sum =0;
        int count=0;
        int fc=0;
        
        int a=0,b=1;
        
        if(x>y)
         {
             x=x+y;
             y=x-y;
             x=x-y;
         }
        if(x>=0 && y>=0)
        {
            
           while(a<=y)
            {
               if(a>=x) 
               {
                  count++;
                   if(count%2==1)
                    {
                       fc++;
                       sum = sum+a;
                    }
               }
                int c=a+b;
                a=b;
                b=c;
            }
            if(fc!=0)
            {
                float avg = (float)sum/fc;
                System.out.printf("%.2f",avg);
            }
            else
            System.out.print("No Fibonacci Series Values");
        }
        else
            System.out.print("Invalid Inputs");
    }
}