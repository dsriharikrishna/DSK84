import java.util.Scanner;
class dsk {
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        
        int n = sc.nextInt();
        
        if(n>10 && n<100)
        {
               for(int i = 1; i<=n; i++)
                {
                 System.out.println("CVCORP");
                }
        }
        else
        {
            System.out.println("Invalid Input");
        }
    }
}