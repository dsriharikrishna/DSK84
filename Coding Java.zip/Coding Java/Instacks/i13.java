import java.util.Scanner;

class dsk
{
    public static void main(String args[])
    {
     Scanner sc = new Scanner(System.in);
     int a = sc.nextInt();
     int b = sc.nextInt();
     int sum = 0;
     int count = 0;
     
     if(!(a>b))
     {
         for(int i = a+1; i<b; i++)
         {
             if(i%2==0)
             {
                 sum = sum+i;
                 count++;
             }
         }
         if(count>0)
              System.out.print(sum);
          else
            System.out.print("NO NUMBERS");
        } 
        else
        {
            System.out.print("INVALID RANGE");
        }
    }
}