import java.util.Scanner;
class dsk
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        
        for(int i = 1; i<=a; i++)
        {
            System.out.print("A,B");
            if(i !=a)
            {
               System.out.print(",");
            }
        }
    }
}