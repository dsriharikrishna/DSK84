import java.util.Scanner;
class dsk
{
    public static void main(String args[])
    {
        
    Scanner sc = new Scanner(System.in);
    int a = sc.nextInt();
    int b = sc.nextInt();
    int c = 0;
 
    if(a<0 || b<0)
    {
        System.out.print("Invalid Inputs");
    }
    else
    {
            for (int i = a; i<=b; i+=2)
            {
                c++;
                if(c!=1)
                    System.out.print(", ");
                   
            System.out.print((i)+"^"+2);
            }
       }
    }
}
