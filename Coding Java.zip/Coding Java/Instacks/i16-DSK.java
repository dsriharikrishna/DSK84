import java.util.Scanner;
class dsk
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        char op = sc.next().charAt(0);
		
        for(char i ='a'; i<='z'; i++)
			System.out.print(i);

		for(char i ='A'; i<='Z'; i++)
			System.out.print(i);

    }
}