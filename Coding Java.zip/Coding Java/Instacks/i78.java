import java.util.Scanner;
class Main
{
    public static void main(String []args)
    {
       Scanner sc = new Scanner(System.in);
       int n = sc.nextInt();
       int Lowestdigit = 9;
       int Highestdigit = 0;
       
       if(n>0)
       {
           while(n>0)
           {
               int r = n%10;
               Lowestdigit = Math.min(Lowestdigit, r);
               Highestdigit = Math.max(Highestdigit, r);
               n=n/10;
           }
            int span = Highestdigit - Lowestdigit;
            System.out.println("Lowest Digit in a Given Number is "+Lowestdigit+".");
            System.out.println("Highest Digit in a Given Number is "+Highestdigit+".");
            System.out.println("Highest Span in a Given Number is "+span+".");
       }
       else
            System.out.print("Invalid Input.");
    }
}