import java.util.Scanner;

class Main
{
    public static void main(String []args)
    {
    Scanner sc  = new Scanner(System.in);
    int a = sc.nextInt();
    int c =0;
  
    if(a<0)
     {
        a=-a;
       }
    if(a>0)
        {
            for (int i=1; i<=a; i++)
            {
              if(a%i==0)
              {
                  int fc =0;
                  for(int j=1; j<=i; j++)
                  {
                      if(i%j==0)
                          fc++;
                  }
                  if(fc==2)
                  {
                      System.out.print(i +" "); 
                      c++;
                  }
              }
            }
          if(c==0)
                System.out.print("No Prime Factors");    
       }
    else
        System.out.println("Invalid Input");
    }
}