import java.util.Scanner;
class Main
{
    public static void main(String args[])
    {
        Scanner sc  =  new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        int p =0;
        int sum =0;
        
        if(a<0)
         a=-a;
        if(b<0)
        {
            b=-b;
        }
         if(a!=0&&b!=0)
         {
             if(a>b)
             {
                 System.out.print("Given Inputs are Swapped");
             }
             else
             {
            for( int i=a; i<=b; i++)
            { 
                int rev=0;
                int t=i;  
                while(t>0)
                { 
                    int r = t%10;
                    rev =  rev*10+r;
                    t/=10;
                }
                if(rev==i)
                {
                    p++;
                    sum = sum +i;
                }
            
            }
            if(p==0)
            System.out.print("No Palindrome Values");
            else
            {
            float avg = (float)sum/p;
            System.out.printf("%.2f",avg);
            }
             }
      }
      else
        System.out.print("INVALID Inputs");
    }
}
