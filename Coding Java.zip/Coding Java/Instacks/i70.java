import java.util.Scanner;
class Main
{
    public static void main(String []args)
    {
    Scanner sc =  new Scanner(System.in);
    int n = sc.nextInt();
    int sum=0;
   
    if(n!=0)
    { 
        if(n<0)
            System.out.print("Sorry! you have Entered Negative Values.");
        else
        {
           for(int i=1; i<=n; i++)
           {
               sum = (n*(n+1)/2);
           }
       System.out.print("Sum of 'N' Natural Numbers is " +sum);
    System.out.print(".");
        }
    }
    else
        System.out.print("InvaLid Input.");
    }
}