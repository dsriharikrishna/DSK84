import java.util.Scanner;
class Main
{
    public static void main(String []args)
    {
        Scanner sc = new Scanner(System.in);
        int x = sc.nextInt();
        int y = sc.nextInt();
        int a=0,b=1;
        int count=0;
        
        if(x>y)
        {
            x=x+y;
            y=x-y;
            x=x-y;
        }
        if(x>=0 && y>=0)
        {
            while(a<=y)
            {
                if(a>=x)
                {
                 count++;
                 System.out.print(a +" ");
                 }
                int c = a+b;
                a=b;
                b=c;
            }
            if(count==0)
                 System.out.print("No Fibonacci Series Values");
	    
        }
        else
        System.out.print("Invalid Inputs");
    }
}
