// odd positions code 
//i/p=5432
//o/p=6


import java.util.Scanner;
class Main
{
    public static void main(String []args)
    {
    Scanner sc  = new Scanner(System.in);
    int a = sc.nextInt();
    int sum =0;
    int pos=0; 
    if(a>0)
    {
        while(a>0)
        {
            int r=a%10;
            pos++;
            if(pos%2==1)
            {
            sum = sum+r;
            }
            a=a/10;
        }
        System.out.println(sum);
    }
    else{
        System.out.println("Invalid Input");
    }
    }
}
