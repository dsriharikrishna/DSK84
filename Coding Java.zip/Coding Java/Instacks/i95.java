import java.util.Scanner;

class Main
{
    public static void main(String[]args)
    {
       Scanner sc = new Scanner(System.in);
       int a = sc.nextInt();
       int b = sc.nextInt();
       int c = sc.nextInt();
       int lcm = 1;
       
       if(a>0 && b>0 && c>0)
       {
        for(int i=2; a>1||b>1||c>1; )
        {
             if(a%i==0||b%i==0||c%i==0)
                {
                if(a%i==0)
                    a/=i;
                if(b%i==0)
                    b/=i;
                if(c%i==0)
                    c/=i;
                lcm*=i;
                }
                else
                 i++;
        }
       System.out.print(lcm);
       }
        else if((a<=0 && b<=0 )|| (a<=0 && c<=0) || (b<=0 && c<=0))
                System.out.print("Sorry Invalid Inputs!");
        else if(a<=0)
                System.out.print("InvalId First Input");
        else if(b<=0)
                System.out.print("Invalid Second Input");
        else if(c<=0)
                System.out.print("InvaliD ThirD Input");
    }
}