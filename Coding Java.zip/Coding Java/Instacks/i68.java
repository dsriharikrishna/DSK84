import java.util.Scanner;
class Main
{
    public static void main(String []args)
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int t=n,arm=0;
        
        if(n>0)
        {
            while(n>0)
            {
                int r=n%10;
                arm+=(int)Math.pow(r,3);
                n/=10;
            }
            if(arm==t)
                System.out.print("Armstrong Number");
            else
                System.out.print("Not a Armstrong Number");
        }
        else
            System.out.print("Invalid Input");
    }
}
