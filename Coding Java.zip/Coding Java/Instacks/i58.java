import java.util.Scanner;
class Main
{
    public static void main(String args[])
    {
        Scanner sc  =  new Scanner(System.in);
        int n = sc.nextInt();
        int rev =0;
        int t=n;
     
     if(n==0)
          System.out.print("Zero");
      if(n>=0)
      {
            while(n>0)
                { 
                    int r = n%10;
                    rev =  rev*10+r;
                    n/=10;
                }
                if(rev==t)
                {
                    if(rev!=0)
                         System.out.print("Given Number is Palindrome");  
                }
                else
                System.out.print( "Reverse of a Given Number is " +rev);
      }
      else
        System.out.print("Invalid Input");
    }
}