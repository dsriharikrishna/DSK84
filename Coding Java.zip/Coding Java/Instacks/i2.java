import java.util.Scanner;

class dsk
{
    public static void main(String []args )
    {
       Scanner obj = new Scanner(System.in);
       
       int n = obj.nextInt();
       int n1 = obj.nextInt();
       int count=0;
       
       if(!(n<n1))
         {
           System.out.println("INVALID RANGE");
          }
          else
             {
              for(int i = n; i<=n1; i++)
                {
                        if(i%11==0)
                        {
                        System.out.print(" " +i);
                        count++;
                        }
                }
            }
            if(count==0 && n<n1 )
            {
                System.out.println("NO NUMBERS");
            }
      }
}