import java.util.Scanner;
class Main
{
    public static void main(String args[])
    {
        Scanner sc  =  new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        int power = 1;
      
      if(a>0 && b>0)
      {
          double r = Math.pow(a,b);
         System.out.print(a+" Power "+b+" value is " +(int )r+".");   
        }
      else
        System.out.print("Invalid Inputs");
    }
}
