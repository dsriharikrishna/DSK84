import java.util.Scanner;
class dsk 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        
            for (int i = a; i>=b; i--)
            {
                if (i!=a)
                {
                    System.out.print(", ");
                }
               
                if(i>=0)
                {
                 System.out.print(i*5);
                }
                if(i<0)
                {
                System.out.print("("+5*i+")");
                }
            }

            for(int i=a;i<=b; i++)
            {
                
                if(i!=a)
                {
                System.out.print(", ");
                }
                
                if(i>=0)
                {
                System.out.print(i*5);
                }
                if(i<0)
                {
                System.out.print("("+5*i+")");
                }
            }
        
    }
}