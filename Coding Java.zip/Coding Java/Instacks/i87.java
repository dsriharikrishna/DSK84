import java.util.Scanner;
class Main
{
    public static void main(String args[])
    {
        Scanner sc  = new Scanner(System.in);
        int n = sc.nextInt();
       
        if(n>0)
        { 
            n=n%10;
            if(n==2 || n==4 || n==6 || n==8 || n==0 )
                System.out.print("Even");
            else
                System.out.print("Odd");
        }
        else
            System.out.print("Invalid Input");
            
    }
}
