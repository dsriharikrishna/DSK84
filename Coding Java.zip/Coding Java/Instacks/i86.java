import java.util.*;
class Main
{
    public static void main(String args[])
    {
        Scanner sc  = new Scanner(System.in);
        int n = sc.nextInt();
        int before =0,after=0;
    if(n>0)
    {
        for(int i=n-1;i>=1;i--)
        {
            int fc=0;
            for(int j=1;j<=i;j++)
            {
              if(i%j==0)
                fc++;
            }
            if(fc==2)
            {
                before= i;
                break;
            }
        }
        for(int i=n+1; i>=1;i++)
        {
            int fc=0;
            for(int j=1;j<=i;j++)
            {
                if(i%j==0)
                    fc++;
            }
            if(fc==2)
            {
                after = i;
                break;
            }
        }
        if(after-n>n-before)
            System.out.print(before);
        else if(after-n<n-before)
            System.out.print(after);
        else
            System.out.print(before+"\n"+after);
    }
    else
        System.out.print("InValid Input");
    }
}