import java.util.Scanner;
class Main
{
    public static void main(String args[])
    {
        Scanner sc =  new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        int result = 1;
        
        if(a>0 && b>0)
        {
            for(int i=b; i>0;i--)
            {
                result*=a;
            }
         System.out.print(+a +" Power "+b+" value is "+result+".");
        }
        else
            System.out.println("Invalid Inputs");
    }
}