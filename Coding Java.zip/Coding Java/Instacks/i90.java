import java.util.Scanner;
class Main
{
    public static void main(String args[])
    {
        Scanner sc  = new Scanner(System.in);
        int n  = sc.nextInt();
        int i,j,c=0;
        if(n>0)
        {
            for(i=2; ; i++)
            {
                for(j=2; j<=i;j++)
                {
                    if(i%j==0)
                        break;
                }
                if(i==j)
                {
                    c++;
                    if(c!=1)
                        System.out.print(", ");
                System.out.print(i);
                }
                if(c==n)
                    break;
            }
        }
        else
            System.out.print("Invalid Input");
            
    }
}
