/*
37.Write a Program to Print the Following Pattern?

If Input is 5 then Print

%  % % % %

& & & &

% % %

& &

%
*/
import java.util.*;
class A
{
    public static void main(String []args)
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int c=0;
        if(n>0)
        {
            for(int i=n; i>=1; i--)
            {
              c++;
              for(int j=1;j<=i;j++)
              {
                  if(c%2==0)
                     System.out.print("& ");
                  else
                     System.out.print("% ");
              }
              System.out.println();
            }        
        }
        else
            System.out.print("Invalid Input");
    }
}