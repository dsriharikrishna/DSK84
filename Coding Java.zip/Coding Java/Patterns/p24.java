/*
24.Write a Program to Print the Following Pattern?

If Input is 5 then Print

*****

 ****

  ***

   **

    *
*/

import java.util.*;
class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        
        if(a>0)
        {
            for(int i=a; i>=1; i--)
            {
                for(int j=1;j<=a-i; j++)
                {
                    System.out.print(" ");
                }
                for(int j=1;j<=i;j++)
                {
                    System.out.print("*");
                }
                System.out.println( );
            }
        }
        else
            System.out.print("Invalid Input");
    }
}
