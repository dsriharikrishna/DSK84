
/*
86.

                 02                  02          
               00  03              04  06
             01  05  01          08  10  12
           07  02  11  03      14  16  18  20
         13  05  17  08  19  22  24  26  28  30
           13  23  21  29      29  27  25  23
             34  31  65          21  19  17
               37  99              15  13
                 41                  11
*/

import java.util.*;
class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();

        int c = 2,k1=2;
        int a = 0,b=1,count=0;
        
        for(int i=1;i<=n;i++)
        {
            for(int j=0;j<n-i;j++)
                System.out.print("  ");

            for(int j=1;j<=i;)
            {
                count++;
                if(count%2==1)
                {
                    int fc=0;
                    for(int k=2;k<=c;k++)
                    {
                        if(c%k==0)
                            fc++;
                    }
                    if(fc==1)
                    {
                        System.out.printf("%02d  ",c);
                        j++;
                    }
                    else
                        count--;
                    c++;
                }
                else
                {
                    System.out.printf("%02d  ",a);
                    int d = a+b;
                    a=b;
                    b=d;
                    j++;
                }
            }
            for(int j=1;j<=n-i;j++)
            {
                System.out.print("    ");
            }
            for(int j=1;j<=i;j++)
            {
                System.out.printf("%02d  ",k1);
                k1+=2;
            }
            System.out.println();
        }
        k1=k1-3;
        for(int i=n;i>0;i--)
        {
            for(int j=i;j<=n;j++)
                System.out.print("  ");

            for(int j=1;j<i;)
            {
                count++;
                if(count%2==1)
                {

                    int fc=0;
                    for(int k=2;k<=c;k++)
                    {
                        if(c%k==0)
                            fc++;
                    }
                    if(fc==1)
                    {
                        System.out.printf("%02d  ",c);
                        j++;
                    }
                    else
                        count--;
                    c++;
                }
                else
                {
                    System.out.printf("%02d  ",a);
                    int d = a+b;
                    a=b;
                    b=d;
                    j++;
                }
            }
            for(int j=i;j<=n;j++)
            {
                System.out.print("    ");
            }
            for(int j=1;j<i;j++)
            {
                System.out.printf("%02d  ",k1);
                k1-=2;
            }
            System.out.println();
        }
    }
}