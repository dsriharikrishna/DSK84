
/*
12.Write a Program to Print the Following Pattern?

If Input is 4 and 1 then Print

1 – 1
2 3 – 5
4 5 6 – 15
7 8 9 10 – 34

*/

import java.util.*;
class A
{
    public static void main(String []args)
    {
       
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        int sum=0;
        
        if(a>0 && b>0)
        {
            for(int i=1;i<=a;i++)
            {
                sum=0;
                for(int j=1;j<=i;j++)
                {
                    System.out.print(b+" ");
                    sum+=b;
                    b++;
                }
                System.out.print("- "+sum);
                System.out.println();
            }
        }
        else if(a>0 && b<0)
            System.out.print("Invalid Starting Value");
        else if(a<0 && b>0)
            System.out.print("Invalid Row Input");
        else 
            System.out.print("Invalid Inputs");
    }
}