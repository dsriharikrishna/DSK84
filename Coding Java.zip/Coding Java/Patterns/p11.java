
/*
11.Write a Program to Print the following Basic Pattern?

If Input is 5 and 5 then Print 

1*2*3*4*5
6*7*8*9*10
11*12*13*14*15
16*17*18*19*20
21*22*23*24*25


*/
import java.util.*;
class A
{
    public static void main(String []args)
    {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt(),c=0;

        if(a>0 && b>0)
        {
            for(int i=1; i<=a; i++)
            {
                for(int j=1; j<=b; j++)
                {
                    c++;
                    if(j==b)
                        System.out.print(c);
                    else
                        System.out.print(c+"*");
                }
                System.out.println();
            }
        }
        else if(a<=0 && b<=0)
                System.out.print("Invalid Row and Column Values");
        else if(a<=0)
                System.out.print("Invalid Row Value");
        else if(b<=0)
                System.out.print("Invalid Column Value");

        sc.close();
    }
}