/*
56.Write a Program to Print the Following Pattern?

If Input is 5 then Print

*      *

* *    *

*   *  *

*    * *

*      *

*/

import java.util.*;
class A
{
	public static void main(String[]args)
	{
		//Write your code here.
		Scanner sc  = new Scanner(System.in);
		int n = sc.nextInt();
		if(n>0)
		{
		    for(int i=1;i<=n;i++)
		    {
		        for(int j=1;j<=n;j++)
		        {
		            if(j==1 || j==n || j==i)
		                System.out.print("*");
		            else
		                System.out.print(" ");
		        }
		        System.out.println();
		    }
		    
		}
		else
		    System.out.print("Invalid Input");
	}
}
