/*

15.Write a Program to Print the Following Pattern?

If Input is 6 then Print

1 2 3 4 5 6
5 4 3 2 1
1 2 3 4
3 2 1
1 2
1

*/
import java.util.*;
class A{
    public static void main(String []args)
    {
        //Write Your Code Here
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int c=1;
        
        if(a>0)
        {
            for(int i=a;i>=1;i--)
            {
                if(c==1)
                {
                    for(int j=1;j<=i;j++)
                    {
                        System.out.print(c+" ");
                        c++;
                    }
                }
                else
                {
                    c=c-2;
                    for(int j=1;j<=i;j++)
                    {
                        System.out.print(c+" ");
                        c--;
                    }
                    c++;
                }
                System.out.println();
            }
        }
        else
            System.out.println("Invalid Input");
    }
}
