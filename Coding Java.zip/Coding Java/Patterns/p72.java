/*

72.Write a Program to Print the following Basic Pattern?

If Input is 4 then Print 

01 02 03 04

05       06

07       08

09 10 11 12

*/

import java.util.*;
class A
{
	public static void main(String[]args)
	{
		//Write your code here.
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int c=0;
		
		if(n<=0)
		    System.out.print("Invalid Input");
		else
		{
		    for(int i=1;i<=n;i++)
		    {
		        for(int j=1;j<=n;j++)
		        {
		            if(i==1 ||i==n || j==1 || j==n )
		            {
		                c++;
		                if(c>0 && c<=9)
		                    System.out.print("0"+c+" ");
		                else
		                    System.out.print(c+" ");
		            }
		             else
		                System.out.print("   ");
		        }
		        System.out.println();
		    }
		}
	}
}