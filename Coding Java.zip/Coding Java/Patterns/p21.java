/*
21.Write a Program to Print the Following Pattern?

If Input is 5 then Print

2
3 5
6 8 10
11 13 15 17
18 20 22 24 26

*/

import java.util.*;
class Main
{
    public static void main(String []args)
    {
        //Write Your Code Here
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int c=2;
        
        if(a>0)
        {
            for(int i=1;i<=a;i++)
            {
                for(int j=1;j<=i;j++)
                {
                    System.out.print(c+" ");
                    c+=2;
                }
                c--;
                System.out.println();
            }
                
        }
        else
            System.out.print("Invalid Input");
        
    }
}