/*
35.Write a Program to Print the Following Pattern?

If Input is 6 then Print

1

1 2

1 2 3

1 2 3 5

1 2 3 5 8

1 2 3 5 8 13

*/
import java.util.*;
class A
{
    public static void main(String []args)
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int a=0,b=1;
        if(n>0)
        {
            for(int i=1; i<=n; i++)
            {
                a=1;b=1;
                for(int j=1;j<=i;j++)
                {
                    System.out.print(b+" ");
                    int c=a+b;
                    a=b;
                    b=c;
                }   
             System.out.println();
            }   
        }
        else
            System.out.println("Invalid Input");
    }
}