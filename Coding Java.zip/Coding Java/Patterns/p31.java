/*
31.Write a Program to Print the Following Pattern?

If Input is 5 and 3 then Print

3

44

555

6666

77777

*/

import java.util.*;
class Main
{
    public static void main(String []args)
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int n1 = sc.nextInt();
        
        if(n>0 && n1>=0)
        {
         for(int i=1; i<=n; i++)
            {
              for(int j=1;j<=i;j++)
              {
                System.out.print(n1);
              }
              n1++;
              System.out.println();
            }  
        }
        else if(n<=0 && n1>=0)
              System.out.print("Invalid Row Value");
        else if(n1<0 && n>0)
              System.out.print("Invalid Starting Value");
        else 
            System.out.print("Invalid Inputs");
    }
}
