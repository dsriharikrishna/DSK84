
/*
51.Write a Program to Print the Following Pattern?

If Input is 4 then Print

   1

  1 2

 1 2 3

1 2 3 4

*/
import java.util.*;
class A
{
	public static void main(String[]args)
	{
	    Scanner sc  = new Scanner(System.in);
	    int n = sc.nextInt();
	    
	    if(n<=0)
	        System.out.print("Invalid Input");
	    else
	    {
	        for(int i=1;i<=n;i++)
	        {
	            for(int j=n-i;j>=1; j--)
	            {
	                System.out.print(" ");
	            }
	            for(int j=1;j<=i;j++)
	            {
	                System.out.print(j+" ");
	            }
	            System.out.println();
	        }
	    }
	}
}