import java.util.*;

class A
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int a=0,b=1,c=2,fc=0,count=0;

        for(int i=1;i<=n;i++)
        {
            for(int j=1;j<=i;)
            {
                count++;
                if(count%2==1)
                {
                    System.out.print(a+" ");
                    int d=a+b;
                    a=b;
                    b=d;
                    j++;
                }
                else 
                {
                    fc=0;
                    for(int k=1;k<=c;k++)
                    {
                        if(c%k==0)
                            fc++;
                    }
                    if(fc==2)
                    {
                        System.out.print(c+" ");
                        j++;
                    }
                    else
                        count--;
                c++;
                }
            }
            System.out.println();
        }
    }
}