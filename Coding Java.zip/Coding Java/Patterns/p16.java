
/*
16.Write a Program to Print the Following Pattern?

If Input is 5 then Print

5 4 3 2 1
4 3 2 1 
3 2 1
2 1
1
*/

import java.util.*;
class A
{
    public static void main(String []args)
    {
        //Write Your Code Here
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int c=1;
        
        if(a>0)
        {
            for(int i=a;i>=1;i--)
            {
                for(int j=i;j>=1;j--)
                {
                    System.out.print(j+" ");
                }
                System.out.println();
            }
        }
        else
            System.out.println("Invalid Input");
    }
}