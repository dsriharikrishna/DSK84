/*
9.Write a Program to Print the following Basic Pattern?

If Input is 5 then Print 

55555
54444
54333
54322
54321

*/
import java.util.*;
class Main
{
    public static void main(String []args)
    {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        if(a<0)
            a=-a;
        if(a!=0)        
        {
            for(int i=a; i>=1; i--)
            {
                for(int j=a; j>=1; j--)
                {
                    if(i<=j)
                         System.out.print(j);
                    else
                        System.out.print(i);
                }
                System.out.println();
            }
        }
        else 
            System.out.print("InvaliD Input");
    }
}