/*
62.Write a Program to Print the Following Pattern?

If Input is 5 then Print

5
454
34543
2345432
123454321
2345432
34543
454
5

*/

import java.util.*;
class Main
{
	public static void main(String[]args)
	{
		//Write your code here.
		Scanner sc  = new Scanner(System.in);
		int n = sc.nextInt();
		
		if(n>0)
		{
		    for(int i=n;i>0;i--)
		    {
		        for(int j=i;j<=n;j++)
		        {
		            System.out.print(j);
		        }
		        for(int j=(n-1);j>=i;j--)
		        {
		            System.out.print(j);
		        }
		        System.out.println();
		    }
		    for(int i=2;i<=n;i++)
		    {
		        for(int j=i;j<=n;j++)
		        {
		            System.out.print(j);
		        }
		        for(int j=(n-1);j>=i;j--)
		        {
		            System.out.print(j);
		        }
		        System.out.println();
		    }
		}
		else
		    System.out.print("Invalid Input");
	}
}