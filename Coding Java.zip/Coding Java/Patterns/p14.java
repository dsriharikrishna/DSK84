/*
14.Write a Program to Print the Following Pattern?

If Input is 5 then Print

5 4 3 2 1
5 4 3 2
5 4 3
5 4
5
*/
import java.util.*;
class A
{
    public static void main(String []args)
    {
        //Write Your Code Here
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        
        if(a>0)
        {
            for(int i=1;i<=a;i++)
            {
                for(int j=a;j>=i;j--)
                {
                    System.out.print(j+" ");
                }
                System.out.println();
            }
                
        }
        else
            System.out.print("Invalid Input");
        
    }
}