/*
39.Write a Program to Print the Following Pattern?

If Input is 5 then Print

1

3*2

4*5*6

10*9*8*7

11*12*13*14*15

*/
import java.util.*;
class A
{
    public static void main(String []args)
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int c=0;
        
        if(n<0)
            n=-n;
        if(n>0)
        {
            for(int i=1; i<=n; i++)
            {
                 if(i%2==1)
                 {  
                  c=c+i;
                      for(int j=1;j<=i;j++)
                      {
                        if(i==j)
                            System.out.print(c);
                        else
                            System.out.print(c+"*");
                      c++;
                      }
                  }
                  else
                  {
                     c=c+i-1;
                     for(int j=1;j<=i;j++)
                     {
                        if(i==j)
                            System.out.print(c);
                        else
                            System.out.print(c+"*");
                     c--;
                     }
              }
              System.out.println();
            }        
        }
        else
            System.out.print("Invalid Input");
    }
}