
/*
63.Write a Program to Print the Following Pattern?

If Input is 4 then Print

1
2 4
3 6 9
4 8 12 16
5 10 15
6 12
7

*/

import java.util.*;
class A
{
	public static void main(String[]args)
	{
		Scanner sc  = new Scanner(System.in);
		int n = sc.nextInt(),c=0;
		
		if(n>0)
		{
		    for(int i=1;i<=n;i++)
		    {
		        for(int j=0;j<i;j++)
		        {
		            System.out.print(i+(i*j)+" ");
		        }
		        System.out.println();
		    }
		    for(int i=(n+1);i<=((n*2)-1);i++)
		    {
		        c=0;
		        for(int j=i;j<=((n*2)-1);j++)
		        {
		            System.out.print(i+(c*i)+" ");
		            c++;
		        }
		        System.out.println();
		    }
		}
		else
		    System.out.println("Invalid Input.");
		
	}
}
