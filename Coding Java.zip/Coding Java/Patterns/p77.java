
/*
77.Write a Program to Print the following Hollow Pattern?

If Input is 5 then Print 

    *

    *

* * * * *

    *

    *

If Input is 6 then Print

    * *

    * *

* * * * * *

* * * * * * 

    * * 

    * * 

    */

import java.util.*;
class A
{
	public static void main(String[]args)
	{
		//Write your code here.
		Scanner sc = new Scanner(System.in);
		int r = sc.nextInt();
		
		if(r<=0)
		    System.out.print("Invalid Input");
		else
		{
		    int c=(int)(r/2)+1;
		    for(int i=1;i<=r;i++)
		    {
		        for(int j=1;j<=r;j++)
		        {
		            if(r%2==0)
		            {
    		            if(j==(c-1) || i==(c-1))
    		                System.out.print("* ");
    		            else if(j==c || i==c)
    		                System.out.print("* ");
    		            else
    		                System.out.print("  ");
    		        }
    		        else
    		        {
    		            if(i==c || j==c)
    		                System.out.print("* ");
    		            else
    		                System.out.print("  ");
    		        }
		        }
		        System.out.println();
		    }
		}
	}
}