/*
8.Write a Program to Print the following Basic Pattern?

If Input is 3 and 5 then Print 

1 2 3 4 5

6 7 8 9 10

11 12 13 14 15

*/

import java.util.*;
class Main
{
    public static void main(String []args)
    {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt(),b=sc.nextInt(),c=0;
        
        if(a<0)
            a=-a;
        if(b<0)
            b=-b;
        if(a>0 && b>0)        
        {
            for(int i=1;i<=a; i++)
            {
                for(int j=1; j<=b; j++)
                {
                    c++;
                    System.out.print(c+" ");
                }
                System.out.println();
            }
        }
        else 
            System.out.print("Invalid Inputs");
    }
}

 