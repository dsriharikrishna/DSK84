/*
49.Write a Program to Print the Following Pattern?

If Input is 5 then Print

        01

      02  03

    04  05  06

  07  08  09  10

11  12  13  14  15

*/

import java.util.*;
class A
{
	public static void main(String[]args)
	{
	    Scanner sc  = new Scanner(System.in);
	    int n = sc.nextInt();
	    int c=0;
	    
	    if(n<0)
	        n=-n;
	    if(n==0)
	        System.out.print("Invalid Input");
	    else
	    {
	        for(int i=1;i<=n;i++)
	        {
	            for(int j=1;j<=n-i;j++)
	            {
	                System.out.print("  ");
	            }
	            for(int j=1;j<=i;j++)
	            {
	                c++;
	                if(c>=1 && c<=9)
	                     System.out.print("0"+c+"  ");
	                else
	                    System.out.print(c+"  ");
	            }
	            System.out.println();
	        }
	    }
	}
}
