/*
83.Write a Program to Print the following Hollow Pattern?

If Input is 5 then Print 

    * * * * * 

   *       *

  *       * 

 *       * 

* * * * *

*/

import java.util.*;
class A
{
	public static void main(String[]args)
	{
		//Write your code here.
		Scanner sc  = new Scanner(System.in);
		int r = sc.nextInt();
		
		if(r<=0)
		    System.out.print("Invalid Input");
		else
		{
		    for(int i=1;i<=r;i++)
		    {
		        for(int j=1;j<=r-i;j++)
		            System.out.print(" ");
		        for(int j=1;j<=r;j++)
		        {
		            if(i==1 || j==1 || i==r || j==r)
		                System.out.print("* ");
		            else
		                System.out.print("  ");
		        }
		        System.out.println();
		    }
		}
	}
}