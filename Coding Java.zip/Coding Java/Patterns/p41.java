
/*
41.Write a Program to Print the Following Pattern?

If Input is 7 then Print

            G

          G F

        G F E

      G F E D

    G F E D C

  G F E D C B

G F E D C B A

*/
import java.util.*;
class A
{
    public static void main(String []args)
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        char c=(char)(64+n);
        if(n>0 && n<=26)
        {
            for(int i=1; i<=n; i++)
            {
              char d=c;
              for(int j=1;j<=n-i; j++)
              {
                  System.out.print("  ");
              }
              for(int j=1;j<=i;j++)
              {
                System.out.print(d+" ");
                d--;
              }
              System.out.println();
            }        
        } 
        else if(n>0)
                System.out.print("Invalid Row Value");
        else
            System.out.print("Invalid Input");
    }
}