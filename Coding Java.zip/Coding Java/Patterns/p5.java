/*
5.Write a Program to Print the following Basic Pattern?

If Input is 5 and 6 then Print 

* * * * * *

* $ $ $ $ *

* $ $ $ $ *

* $ $ $ $ *

* * * * * *

*/
import java.util.*;
class A
{
    public static void main(String []args)
    {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt(),b=sc.nextInt();
        if(a>0 && b>0)        
        {
            for(int i=1;i<=a;i++)
            {
                for(int j=1; j<=b; j++)
                {
                    if(i==1||i==a || j==1||j==b)
                        System.out.print("* ");
                    else
                        System.out.print("$ ");
                }
                System.out.println();
            }
        }
        else 
            System.out.print("Invalid Inputs");
    }
}