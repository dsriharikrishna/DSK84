/*
60.Write a Program to Print the Following Pattern?

If Input is 4 then Print

   1
  121
 12321
1234321
 12321
  121
   1

*/

import java.util.*;
class Main
{
	public static void main(String[]args)
	{
		//Write your code here.
		Scanner sc  = new Scanner(System.in);
		int n = sc.nextInt();
		
		if(n>0)
		{
		    for(int i=1;i<=n;i++)
		    {
		        for(int j=i;j<n;j++)
		        {
		            System.out.print(" ");
		        }
		        for(int j=1;j<=i;j++)
		        {
		            System.out.print(j);
		        }
		        for(int j=(i-1);j>0;j--)
		        {
		            System.out.print(j);
		        }
		        System.out.println();
		    }
		    for(int i=(n-1);i>0;i--)
		    {
		        for(int j=i;j<n;j++)
		        {
		            System.out.print(" ");
		        }
		        for(int j=1;j<=i;j++)
		        {
		            System.out.print(j);
		        }
		        for(int j=(i-1);j>0;j--)
		        {
		            System.out.print(j);
		        }
		        System.out.println();
		    }
		}
		else
		    System.out.println("Invalid Input");
	}
}