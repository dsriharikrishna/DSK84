
/*
18.
Write a Program to Print the Following Pattern?

If Input is 4 then Print

100
200 300
400 500 600
700 800 900 1000

*/
import java.util.*;
class Main
{
    public static void main(String []args)
    {
        //Write Your Code Here
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int c=0;
        
        if(a>0)
        {
            for(int i=1;i<=a;i++)
            {
                for(int j=1; j<=i;j++)
                {
                    c++;
                    System.out.print((c*100)+" ");
                }
                System.out.println();
            }
                
        }
        else
            System.out.print("Invalid Input");
        
    }
}