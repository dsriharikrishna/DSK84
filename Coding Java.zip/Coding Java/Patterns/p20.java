/*
20.Write a Program to Print the Following Pattern?

If Input is 5 then Print

1
3 5
7 9 11
13 15 17 19
21 23 25 27 29

*/

import java.util.*;
class Main
{
    public static void main(String []args)
    {
        //Write Your Code Here
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int c=1;
        
        if(a>0)
        {
            for(int i=1;i<=a;i++)
            {
                for(int j=1; j<=i;j++)
                {
                    System.out.print(c+" ");
                    c+=2;
                }
                System.out.println();
            }
                
        }
        else
            System.out.print("Invalid Input");
        
    }
}