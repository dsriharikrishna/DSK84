
/*
22.Write a Program to Print the Following Pattern?

If Input is 4 then Print

A

B C

D E F

G H I J

*/

import java.util.*;
class A 
{
    public static void main(String []args)
    {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        char c = 'A';
        
        if(a<0)
            a=-a;
        if(a>=1 && a<=6)
        {
            for(char i=1; i<=a; i++)
            {
                for(int j=1; j<=i;j++)
                { 
                    System.out.print(c+ " ");
                    c++;
                }
                System.out.println();
            }
        }
        else if(a==0)
            System.out.print("Invalid Input");
        else 
            System.out.print("Range Exceeded");
    }
}