/*
55.Write a Program to Print the Following Pattern?

If Input is 5 then Print

    *
   # #
  * * *
 # # # #
* * * * *
 # # # #
  * * * 
   # #
    *
*/

import java.util.*;
class A
{
	public static void main(String[]args)
	{
		//Write your code here.
		Scanner sc  = new Scanner(System.in);
		int n = sc.nextInt();
		
		if(n>0)
		{
		    for(int i=1;i<=n;i++)
		    {
		        for(int j=i;j<n;j++)
		        {
		            System.out.print(" ");
		        }
		        for(int j=1;j<=i;j++)
		        {
		            if(i%2==1)
		                 System.out.print("* ");
		            else
		                System.out.print("# ");
		        }
		        System.out.println();
		    }
		    for(int i=n-1;i>0;i--)
		    {
		        for(int j=i;j<n;j++)
		        {
		            System.out.print(" ");
		        }
		        for(int j=1;j<=i;j++)
		        {
		            if(i%2==1)
		                System.out.print("* ");
		            else
		                System.out.print("# ");
		        }
		        System.out.println();
		    }
		}
		else
		    System.out.println("Invalid Input");
		
	}
}
