
/*
42.Write a Program to Print the Following Pattern?

If Input is 3 then Print

    12321

     232

      3

  */
import java.util.*;
class A
{
	public static void main(String[]args)
	{
	    Scanner sc = new Scanner(System.in);
	    int n = sc.nextInt();
	    
	    if(n==0 || (n>0 && n%2==0) || (n<0 && n%2==-1))
	        System.out.print("Invalid Input");
	    else
	    {
	        if(n<0)
	            n=-n;
                
	        for(int i=1;i<=n;i++)
	        {
	            for(int j=1;j<i;j++)
	            {
	                System.out.print(" ");
	            }
	            for(int j=i;j<=n;j++)
	            {
	                System.out.print(j);
	            }
	            for(int j=(n-1);j>=i;j--)
	            {
	                System.out.print(j);
	            }
	            System.out.println();
	        }
	    }
	   
	}
}