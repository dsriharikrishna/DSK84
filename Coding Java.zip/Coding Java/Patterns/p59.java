
/*
59.Write a Program to Print the Following Pattern?

If Input is 5 and 3 then Print

3
44
555
6666
77777
6666
555
44
3

*/

import java.util.*;
class A
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int n1 = sc.nextInt();
        
        if(n<=0 && n1<=0)
            System.out.print("Invalid Inputs");
        else if(n<=0)
            System.out.print("Given Row Value is Invalid");
        else if(n1<=0)
            System.out.print("Given Starting Value is Invalid");
        else
        {
           for(int i=n;i>=1;i--)
           {
               for(int j=i;j<=n;j++)
               {
                   System.out.print(n1);
               }
               System.out.println();
               n1++;
           }
           n1-=2;
           for(int i=1;i<=n-1;i++)
           {
               for(int j=i;j<n;j++)
               {
                   System.out.print(n1);
               }
               System.out.println();
              n1--;
           }
        }  
    }
}
