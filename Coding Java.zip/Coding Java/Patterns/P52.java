
/*
52.Write a Program to Print the Following Pattern?

If Input is 5 then Print

* * * * *

 * * * *

  * * *

   * *

    *
*/

import java.util.*;
class A
{
	public static void main(String[]args)
	{
	    Scanner sc  = new Scanner(System.in);
	    int n = sc.nextInt();
	    
	    if(n<0)
	       n=-n;
	    if(n<=0)
	        System.out.print("Invalid Input");
	    else
	    {
	        for(int i=n;i>=1;i--)
	        {
	            for(int j=1;j<=n-i;j++)
	            {
	                System.out.print(" ");
	            }
	            for(int j=1;j<=i;j++)
	            {
	                System.out.print("* ");
	            }
	            System.out.println();
	        }
	    }
	}
}
