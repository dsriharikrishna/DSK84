/*
74.Write a Program to Print the following Hollow Pattern?

If Input is 5 then Print 

         *

        * *

       * * * 

      * * * * 

     * * * * * 

    *         *

   * *       * * 

  * * *     * * * 

 * * * *   * * * *

* * * * * * * * * * 

*/

import java.util.*;
class A
{
	public static void main(String[]args)
	{
		//Write your code here.
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		
		if(n<=0)
		    System.out.print("Invalid Input");
		else
		{
		    for(int i=1;i<=n;i++)
		    {
		        for(int j=1;j<=n;j++)
		        {
		            System.out.print(" ");
		        }
		        for(int j=1;j<=n-i;j++)
		        {
		            System.out.print(" ");
		        }
		        for(int j=1;j<=i;j++)
		        {
		            System.out.print("* ");
		        }
		        System.out.println();
		    }
		    for(int i=1;i<=n;i++)
		    {
		        for(int j=1;j<=n-i;j++)
		        {
		            System.out.print(" ");
		        }
		        for(int j=1;j<=i;j++)
		        {
		            System.out.print("* ");
		        }
		        for(int j=1;j<=n-i;j++)
		        {
		            System.out.print("  ");
		        }
		        for(int j=1;j<=i;j++)
		        {
		            System.out.print("* ");
		        }
		        System.out.println();
		    }
		}
	}
}