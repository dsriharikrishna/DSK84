// fib pattern in cols 

import java.util.*;
class A
{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		List<Integer> li = new ArrayList<>();
	    int a=0,b=1;
	    for(int i=0;i<n;i++)
	    {
	        for(int j=0;j<=i;j++)
	        {
	            System.out.print(b+" ");
	            li.add(b);
	            int c = a+b;
	            a=b;
	            b=c;
	        }
	         System.out.println();
	    }
	    for(int i=0;i<n*n;i++)
	    {
	        for(int j=1;j<=i;j++)
	        {
	            li.add(b);
	            int c = a+b;
	            a=b;
	            b=c;
	        }
	    }
	    for(int i=0;i<n;i++)
	    {
	        int k=i;
	        for(int j=0;j<=i;j++)
	        {
	            System.out.print(li.get(k)+" ");
	            k+=n-j-1;
	        }
	        System.out.println();
	    }
	}
}
