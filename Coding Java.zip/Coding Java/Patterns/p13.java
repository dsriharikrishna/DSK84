/*
13.
Write a Program to Print the Following Pattern?

If Input is 4 and 5 then Print

5 @ 5 – odd
7 9 @ 16 – even
11 13 15 @ 39 – odd
17 19 21 23 @ 80 – even

*/

import java.util.*;
class Main
{
    public static void main(String []args)
    {
        //Write Your Code Here
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int a = sc.nextInt();
        int sum=0;
        
        if(n>0)
        {
            if(a%2==1 || a%2==-1)
            {
                for(int i=1;i<=n;i++)
                {
                    sum=0;
                    for(int j=1; j<=i;j++)
                    {
                        System.out.print(a+" ");
                        sum+=a;
                        a+=2;
                    }
                    if(sum%2==0)
                        System.out.print("@ "+sum+" - Even");
                    else 
                        System.out.print("@ "+sum+" - Odd");
                System.out.println();
                }
            }
            else
                System.out.print("Invalid Starting Value");
        }
        else if(n<=0 && a%2==1)
            System.out.print("Invalid Row Value");
        else if(n<=0 && a%2==0)
              System.out.print("Invalid Inputs");
              
    }
}