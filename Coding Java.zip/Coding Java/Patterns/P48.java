
/*
48.Write a Program to Print the Following Pattern?

If Input is 5 then Print

    A

   B B

  C C C

 D D D D

E E E E E

*/

import java.util.*;
class Main
{
	public static void main(String[]args)
	{
	    Scanner sc  = new Scanner(System.in);
	    int n = sc.nextInt();
	    char c='A';
	    
	    if(n==0)
	        System.out.print("Zero");
	    else if(n>=(-26) && n<=26)
	    {
	        if(n>0)
	        {
    	        for(int i=1;i<=n;i++)
    	        {
    	            for(int j=1;j<=n-i;j++)
    	            {
    	                System.out.print(" ");
    	            }
    	            for(int j=1;j<=i;j++)
    	            {
    	                System.out.print(c+" ");
    	            }
    	            c++;
    	            System.out.println();
    	        }
	        }
    	    else
    	    {
    	        n=-n;
    	        c=(char)(n+64);
        	    for(int i=n;i>=1;i--)
        	    {
        	        for(int j=1;j<=n-i;j++)
        	        {
        	            System.out.print(" ");
                    }
    	            for(int j=1;j<=i;j++)
    	            {
                        System.out.print(c+" ");
    	            }
                    c--;
    	            System.out.println();
    	        }
    	    }
	    }
	}
}