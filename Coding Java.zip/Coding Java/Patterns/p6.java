/*
6.Write a Program to Print the following Basic Pattern?
If Input is 5 then Print 

1 2 3 * 5
6 7 * 9 10
11 * 13 14 15
* 17 18 19 *
21 22 23 * 25
*/
import java.util.*;
class Main
{
    public static void main(String []args)
    {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt(),c=0;
        if(a>0)        
        {
            for(int i=1;i<=a;i++)
            {
                for(int j=1;j<=a;j++)
                {
                    c++;
                    if(c%4==0)
                        System.out.print("* ");
                    else
                        System.out.print(c +" ");
                }
                System.out.println();
            }
        }
        else 
            System.out.print("Given Value is Invalid");
    }
}