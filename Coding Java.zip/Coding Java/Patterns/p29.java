/*
29.Write a Program to Print the Following Pattern?

If Input is 6 then Print

1

1 2

1 2 3

1 2 3 4

1 2 3 4 5

1 2 3 4 5 6
*/

import java.util.*;
class A
{
    public static void main(String []args)
    {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        
        if(a>0)
        {
            for(int i=1; i<=a; i++)
            {
                for(int j=1; j<=i;j++)
                {
                    System.out.print(j+" ");
                }
                System.out.println();
            }
        }
        else 
            System.out.print("Invalid Input");
    }
}