/*
4.Write a Program to Print the following Basic Pattern?
If Input is 5 then Print 

1 0 1 0 1
1 0 1 0 1
1 0 1 0 1
1 0 1 0 1
1 0 1 0 1

*/
import java.util.*;
class Main
{
    public static void main(String []args)
    {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int c=0;
        if(a>0)        
        {
            for(int i=1;i<=a; i++)
            {
                for(int j=1; j<=a; j++)
                {
                    c++;
                    if(c%2==0)
                        System.out.print("0 ");
                    else 
                        System.out.print("1 ");
                }
                System.out.println();
                c--;
            }
        }
        else 
            System.out.print("Invalid Input");
    }
}