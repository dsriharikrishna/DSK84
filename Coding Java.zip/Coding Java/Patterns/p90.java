// Non fib in cols 

import java.util.*;
class A
{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		List<Integer> li = new ArrayList<>();
		int a=0,b=1,c=a+1;
		
		for(int i=0;i<n*n;i++)
		{
		    for(int j=0;j<=i;)
		    {
		        if(c<b)
		        {
		            System.out.print(c+" ");
		            li.add(c);
		            j++;
		            c++;
		        }
		        else
		        {
		            int k =a+b;
		            a=b;
		            b=k;
		            c=a+1;
		        }
		    }
		    System.out.println();
		}
		
		for(int i=0;i<n;i++)
		{
		    int k=i;
		    for(int j=0;j<=i;j++)
		    {
		        System.out.print(li.get(k)+" ");
		        k=k+n+j-1;
		    }
		    System.out.println();
		}
	}
}
