/*
38.Write a Program to Print the Following Pattern?

If Input is 5 then Print

1

2 6

3 7 10

4 8 11 13

5 9 12 14 15

*/
import java.util.*;
class A
{
    public static void main(String []args)
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        
        if(n>0)
        {
            for(int i=1; i<=n; i++)
            {
              int n1=i;
              int t=n-1;
              for(int j=1;j<=i;j++)
              {
                System.out.print(n1+" ");
                n1=n1+t;
                t--;
              }
              System.out.println();
            }        
        }
        else
            System.out.print("Invalid Input");
    }
}