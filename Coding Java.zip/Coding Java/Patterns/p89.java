//prime pattern in cols

import java.util.*;
class A
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		List<Integer> li = new ArrayList<>();
		
		int fc=0,c=2;
		for(int i=0;i<n*n;i++)
		{
		    for(int j=0;j<=i;)
		    {
		        fc=0;
		        for(int k=2;k<=c;k++)
		        {
		            if(c%k==0)
		            {
		                fc++;
		            }
		        }
		        if(fc==1)
		        {
		          //  System.out.print(c+" ");
		            li.add(c);
		            j++;
		        }
		        c++;
		    }
		  //  System.out.println();
		}
		
		for(int i=0;i<n;i++)
		{
		    int k=i;
		    for(int j=0;j<=i;j++)
		    {
		        System.out.print(li.get(k)+" ");
		        k+=n+j-1;
		    }
		    System.out.println();
		}
	}
}
