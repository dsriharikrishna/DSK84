
/*

47.Write a Program to Print the Following Pattern?

If Input is 4 then Print

   1

  212

 32123

4321234

*/

import java.util.*;
class A
{
	public static void main(String[]args)
	{
		//Write your code here.
		Scanner sc = new Scanner(System.in);
		int n =sc.nextInt();
		
		if(n==0)
		    System.out.print("Oh! I got Zero(0)");
		else
		{
		    if(n<0)
		       n=-n;
		    for(int i=1;i<=n;i++)
		    {
		        for(int j=i;j<n;j++)
		        {
		            System.out.print(" ");
		        }
		        for(int j=i;j>0;j--)
		        {
		            System.out.print(j);
		        }
		        for(int j=2;j<=i;j++)
		        {
		            System.out.print(j);
		        }
		        System.out.println();
		    }
		}
	}
}
