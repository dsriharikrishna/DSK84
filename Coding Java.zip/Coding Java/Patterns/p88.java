//Non Fibonacci numbers In pattern 
class A
{
	public static void main(String[] args) {
		int n = 5;
		int a=0,b=1,c=a+1;
		for(int i=1;i<=n;i++)
		{
		    for(int j=1;j<=i;)
		    {
		       if(c<b)
		       {
		           System.out.print(c+" ");
		           j++;
		           c++;
		       }
		       else 
		       {
		           int k=a+b;
		           a=b;
		           b=k;
		           c=a+1;
		       }
		    }
		    System.out.println();
		}
		
	
	}
}
