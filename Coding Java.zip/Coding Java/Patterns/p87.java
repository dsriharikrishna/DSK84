
/*
86.

                 02                  02          
               00  03              04  06
             01  05  01          08  10  12
           07  02  11  03      14  16  18  20
         13  05  17  08  19  22  24  26  28  30
           13  23  21  29      29  27  25  23
             34  31  65          21  19  17
               37  99              15  13
                 41                  11
*/

import java.util.*;
class A 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int c1=0,p=2,a=0,b=1,n1=2;
        for(int i=1;i<=n;i++)
        {
            for(int j=i;j<n;j++)
                System.out.print("  ");
            for(int j=1;j<=i;j++)
            {
                c1++;
                if(c1%2==1)
                {
                    int fc=0;
                    for(int k=2;k<=(p/2);k++)
                    {
                        if(p%k==0)
                            fc++;
                    }
                    if(fc==0)
                        System.out.printf("%02d  ",p);
                    else
                    {
                        j--;
                        c1--;
                    }
                    p++;
                }
                else
                {
                    System.out.printf("%02d  ",a);
                    int c=a+b;
                    a=b;
                    b=c;
                }
            }
            for(int j=i;j<n;j++)
                System.out.print("    ");
            for(int j=1;j<=i;j++)
            {
                System.out.printf("%02d  ",n1);
                n1+=2;
            }
            System.out.println();
        }
        n1-=3;
        for(int i=n-1;i>0;i--)
        {
            for(int j=i;j<n;j++)
                System.out.print("  ");
            for(int j=1;j<=i;j++)
            {
                c1++;
                if(c1%2==1)
                {
                    int fc=0;
                    for(int k=2;k<=(p/2);k++)
                        if(p%k==0)
                            fc++;
                    if(fc==0)
                        System.out.printf("%02d  ",p);
                    else
                    {
                        j--;
                        c1--;
                    }
                    p++;
                }
                else
                {
                    System.out.printf("%02d  ",a);
                    int c=a+b;
                    a=b;
                    b=c;
                }
            }
            for(int j=i;j<n;j++)
                System.out.print("    ");
            for(int j=1;j<=i;j++)
            {
                System.out.printf("%02d  ",n1);
                n1-=2;
            }
            System.out.println();
        }
    }
}