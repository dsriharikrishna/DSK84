/*6.Write a program to Convert the Binary number to Decimal number?

Input 1    :    1101
Output  1  :    13

Input 2    :    10011000
Output  2  :    152

*/

import java.util.*;
class Main
{
	public static void main(String[]args)
	{
		//write your code here.
		Scanner sc = new Scanner(System.in);
		String bin = sc.next();
		int dec = 0;
		int x = bin.length();
		int p=0,s=0;
		
    	for(int i=(x-1);i>=0; i--)
    	{
    		 char a = bin.charAt(i);
    		 int y = a-48;
             
    		if(y==0 || y==1)
    		    dec = y*(int)Math.pow(2,p)+dec;
    		else
    		    s++;
    		p++;
         }
         if(s!=0)
    	 {
    		  System.out.print("InvAlid Input.");
    	 } 
    	 else
    	    System.out.print(dec);
	}
}