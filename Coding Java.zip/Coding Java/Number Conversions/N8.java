/*8.Write a program to Convert the Hexa Decimal number to Octal number?

Input 1    :    1B
Output  1 :    33

Input 2    :    -2E
Output  2 :    -2E -> 56
*/

import java.util.*;
class Main
{
	public static void main(String[]args)
	{
		//write your code here.
		Scanner sc = new Scanner(System.in);
		String n = sc.next();
		String oc =""; 
	
		int dec=0,p=0,f=0,s=0;
		
		if(n.charAt(0) == '-')
		    s++;
		    
		for(int i=n.length()-1; i>=s; i--)
		{
		    if(n.charAt(i)>='0' && n.charAt(i)<='9')
		        dec +=(n.charAt(i)-48)*(int)Math.pow(16,p);
		        
		    else if(n.charAt(i)>='A' && n.charAt(i)<='F')
		        dec+= (n.charAt(i)-55)*(int)Math.pow(16,p);
		        
		    else if(n.charAt(i)>='a' && n.charAt(i)<='f')
		        dec+=(n.charAt(i)-87)*(int)Math.pow(16,p);
		        
		    else
		        f++;
		    p++;
		}
		if(f>0)
		    System.out.print("InvaliD Input");
		    
		else
		{
		    if(dec==0)
		         System.out.print("0");
		    else
		    {
		    while(dec>0)
		    {
		        int r = dec%8;
		        if(r<=7)    
		            oc = r+oc;
		        dec/=8;
		    }
		    if(n.charAt(0)=='-')
		    {
		        System.out.print(n+" -> "+oc);
		    }
		    else
		    {
		        System.out.print(oc);
		    }
		  }
		}
  }
}