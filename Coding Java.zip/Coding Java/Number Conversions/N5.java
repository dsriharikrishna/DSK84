/*5.Write a program to Convert the Octal number to Binary number?

Input 1    :    377
Output  1  :    11111111

*/

import java.util.*;
class Main
{
	public static void main(String[]args)
	{
		//write your code here.
		Scanner sc = new Scanner(System.in);
		String n = sc.next();
		String bin ="";
		int dec=0,p=0,f=0;
		
    	for(int i=n.length()-1;i>=0; i--)
    	{
    		if(n.charAt(i)=='0')
    		    dec +=0*(int)Math.pow(8,p);

    		else if(n.charAt(i)=='1')
    		    dec += 1*(int)Math.pow(8,p);

    		else if(n.charAt(i)=='2')
    		    dec +=2*(int)Math.pow(8,p);

    		else if(n.charAt(i)=='3')
    		    dec +=3*(int)Math.pow(8,p);

    		else if(n.charAt(i)=='4')
    		    dec +=4*(int)Math.pow(8,p);

    		else if(n.charAt(i) == '5')
    		    dec +=5*(int)Math.pow(8,p);

    		else if(n.charAt(i) == '6')
    		    dec+=6*(int)Math.pow(8,p);

    		else if(n.charAt(i)=='7')
    		    dec += 7*(int)Math.pow(8,p);
    		else
    		{
    		    f++;
    		}
    		p++;
         }
         if(f!=0)
    	 {
    		  System.out.print("InvalId Input");
    	 } 
    	 else
    	 {
    	     if(dec==0)
    	         System.out.print("0");
    	     while(dec>0)
    	     {
    	         int r=dec%2;
    	         bin=r+bin;
    	         dec/=2;
    	     }
    	    System.out.print(bin);
    	 }
	}
}