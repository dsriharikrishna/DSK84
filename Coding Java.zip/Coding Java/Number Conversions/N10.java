/*10.Write a program to Convert the Decimal number to Binary number?

Input 1    :    25
Output  1 :    11001

Input 2    :    -16
Output  2 :    10000
*/

import java.util.*;
class Main
{
	public static void main(String[]args)
	{
		//write your code here.
		Scanner sc = new Scanner(System.in);
		int dec = sc.nextInt();
		String bin = "";
		
		if(dec<0)
	    	dec=-dec;
			
		if(dec==0)
	        System.out.print("Zero");
		if(dec>0)
		{
		  while(dec>0)
		  {
		      int r = dec%2;
		      bin = r+bin;
		      dec/=2;
		  }
		  System.out.print(bin);
		}
	}
}