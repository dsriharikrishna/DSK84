/*
1.Write a program to Convert the Binary number to Hexa Decimal number?
i/p - 100111
o/p - 27

*/
import java.util.*;
class Main
{
	public static void main(String[]args)
	{
		Scanner sc  = new Scanner(System.in);
		String bin = sc.next();
		String HD =" ";
		int dec=0,p=0,f=0,s=0,s1=0,s2=0,s3=0;
		
		for(int i=bin.length()-1;i>=0;i--)
		{
		    if(bin.charAt(i)=='1')
		       dec +=1*(int)Math.pow(2,p);

		    else if(bin.charAt(i)=='0')
		       dec+=0*(int)Math.pow(2,p);

		    else if(bin.charAt(i)>='a' && bin.charAt(i)<='z')
		    {
		        s++;
		        break;
		    }
		    else if(bin.charAt(i)>='A' && bin.charAt(i)<='Z')
		    {
		        s1++;
		        break;
		    }
		    else if(bin.charAt(i)>='1' && bin.charAt(i)<='9')
		    {
		        s2++;
		        break;
		    }
		    else
		    {
		        s3++;
		        break;
		    }
		    p++;
		}
		if(s>0)
		        System.out.print("Invalid input because of small characters");
		else if(s1>0)
		        System.out.print("Invalid input because of Capital characters");
		else if(s2>0)
		    System.out.print("Invalid input because of invalid Digits");
		else if(s3>0)
		   System.out.print("Invalid input because of Special characters"); 
		else
		{
		        if(dec==0)
		        {
		            System.out.print("0");
		        }
		        while(dec>0)
		        {
		            int r = dec%16;
		            if(r<=9)
		            {
		                HD = r+HD;
		            }
		            else
		            {
		                HD = (char)(r+55)+HD;
		            }
		            dec = dec/16;
		        }
		  System.out.print(HD);
		}
	}
}