/*9.Write a program to Convert the Binary number to Octal number.
Input 1    :    1101
Output  1 :    15

Input 2    :    1AB11
Output  2 :    Invalid InPut
*/

import java.util.*;
class Main
{
	public static void main(String[]args)
	{
		//write your code here.
		Scanner sc = new Scanner(System.in);
		String bin = sc.next();
		String oc ="";
		int dec=0,p=0,f=0;
		
    	for(int i=bin.length()-1;i>=0; i--)
    	{
    		if(bin.charAt(i)=='1')
    		{
    		    dec +=1*(int)Math.pow(2,p);
    		}
    		else if(bin.charAt(i)=='0')
    		{
    		    dec += 0*(int)Math.pow(2,p);
    		}
    		else
    		{
    		    f++;
    		}
    		p++;
         }
         if(f!=0)
    	 {
    		  System.out.print("Invalid InPut");
    	 } 
    	 else
    	 {
    	     if(dec==0)
    	     {
    	         System.out.print("0");
    	     }
    	     while(dec>0)
    	     {
    	         int r=dec%8;
    	         oc=r+oc;
    	         dec/=8;
    	     }
    	    System.out.print(oc);
    	 }
	}
}
