/*4.Write a program to Convert the Hexa Decimal number to Decimal number?

Input 1    :    A
Output  1  :    A -> 10

Input 2    :    56
Output  2  :    56 -> 86

*/
import java.util.*;
class Main
{
	public static void main(String[]args)
	{
		//write your code here.
		Scanner sc = new Scanner(System.in);
		String n = sc.next();
		int dec=0,p=0,f=0,s=0;
		
		if(n.charAt(0) == '-')
		    s++;
		    
		for(int i=n.length()-1; i>=s; i--)
		{
		    if(n.charAt(i)>='0' && n.charAt(i)<='9')
		        dec += (n.charAt(i)-48)*(int)Math.pow(16,p);
		        
		    else if(n.charAt(i)>='A' && n.charAt(i)<='F')
		        dec+= (n.charAt(i)-55)*(int)Math.pow(16,p);
		        
		    else if(n.charAt(i)>='a' && n.charAt(i)<='f')
		        dec+=(n.charAt(i)-87)*(int)Math.pow(16,p);
		        
		    else
		        f++;
		    p++;
		}
		if(f==0)
		{  
            if(dec==0)
                System.out.print("0 -> 0");
            else
                System.out.print(n+" -> "+dec);
		}
  }
}