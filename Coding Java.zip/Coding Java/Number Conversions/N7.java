/*7.Write a program to Convert the Octal number to Decimal number.
Input 1    :    11
Output  1 :    9

Input 2    :    -32
Output  2 :    26

*/

import java.util.*;
class Main
{
	public static void main(String[]args)
	{
		//write your code here.
		Scanner sc = new Scanner(System.in);
		String n = sc.next();
	
		int dec=0,p=0,f=0;
		
		if(n.charAt(0) == '-')
		    n=n.substring(1);
		    
		for(int i=n.length()-1; i>=0; i--)
		{
		    if(n.charAt(i)=='0')
		        dec += 0*(int)Math.pow(8,p);
		        
		    else if(n.charAt(i)=='1')
		        dec+= 1*(int)Math.pow(8,p);
		        
		    else if(n.charAt(i)=='2')
		        dec+=2*(int)Math.pow(8,p);
		        
		    else if(n.charAt(i)=='3')
		        dec+=3*(int)Math.pow(8,p);
		        
		    else if(n.charAt(i)=='4')
		        dec+=4*(int)Math.pow(8,p);
		        
		    else if(n.charAt(i)=='5')
		        dec+=5*(int)Math.pow(8,p);
		  
		    else if(n.charAt(i)=='6')
		        dec+=6*(int)Math.pow(8,p);
		    
		    else if(n.charAt(i)=='7')
		        dec+=7*(int)Math.pow(8,p);
		    
		    else
		        f++;
		    p++;
		}
		if(f>0)
		    System.out.print("Invalid Input");
		    
		else
		    System.out.print(dec);
  }
}
