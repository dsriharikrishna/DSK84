/*11.Write a program to Convert the Hexa Decimal number to Binary number

Input 1    :    AD
Output  1 :    10101101

Input 2    :    23
Output  2 :    100011
*/

import java.util.*;
class Main
{
	public static void main(String[]args)
	{
		Scanner sc  = new Scanner(System.in);
		String n = sc.next();
		String bin ="";
		int dec=0,p=0,f=0,s=0;
		
		for(int i=n.length()-1; i>=0;i--)
		{
		    if(n.charAt(i)>='0' && n.charAt(i)<='9')
		        dec +=(n.charAt(i)-48)*(int)Math.pow(16,p);

		    else if(n.charAt(i)>='A' && n.charAt(i)<='F')
		        dec+=(n.charAt(i)-55)*(int)Math.pow(16,p);

		    else if(n.charAt(i)>='a' && n.charAt(i)<='f')
		        dec+= (n.charAt(i)-87)*(int)Math.pow(16,p);

		    else if(n.charAt(i)>='F' && n.charAt(i)<='Z')
		    {
		        s++;
		        break;
		    }
		    else if(n.charAt(i)>='f' && n.charAt(i)<='z')
		    {
		        f++;
		        break;
		    }
		    p++;
		}
        if(f>0)
		        System.out.print("InvaliD Characters");
				
		else if(s>0)
		        System.out.print("InvaliD Characters");
		else
		{
		    if(dec==0)
		    {
		        System.out.print("0");
		    }
		    while(dec>0)
		    {
		        int r = dec%2;
		        bin=r+bin;
		        dec = dec/2;
		    }
		  System.out.print(bin);   
		}
	}
}