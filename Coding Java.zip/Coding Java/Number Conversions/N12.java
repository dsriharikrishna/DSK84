/*12.Write a program to Convert the Decimal number to Octal number?

Input 1    :    26
Output  1 :    32

Input 2    :    -15
Output  2 :    INVALID Input

*/

import java.util.*;
class Main
{
	public static void main(String[]args)
	{
		//write your code here.
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		String oct = "";
		
		if(a==0)
	        System.out.print("ZERO");
	    else
	    {
		if(a>0)
		{
		  while(a>0)
		  {
		      int r = a%8;
		      oct = r+oct;
		      a/=8;
		  }
		  System.out.print(oct);
		}
		else
	        System.out.print("INVALID Input");
	    }
	}
}
