/*3.Write a program to Convert the Dec number to Hexa Decimal number?

Input 1    :    152
Output  1  :    98

Input 2    :    253
Output  2  :    FD

*/

import java.util.*;
class Main
{
	public static void main(String[]args)
	{
		Scanner sc  = new Scanner(System.in);
		int d = sc.nextInt();
		String HD ="";
		int dec=0,p=0,f=0,s=0;


        if(d==0)
        {		 
		   System.out.print("0");		
	    }
		else
		{
			while(dec>0)
			{
				int r = dec%16;
				if(r<=9)
				{
					HD = r+HD;
				}
				else
				{
					HD = (char)(r+55)+HD;
			}
				dec = dec/16;
			}
			System.out.print(HD);
		}
	}
}